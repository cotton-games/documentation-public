# Attentes DB du code Hub — 09/09/2026

Référence : pack schéma séparé `../hub-prod-initial-schema-2026-09-08/schema-contract.json`. Copie documentaire des définitions, sans SQL exécutable. Les SHA applicatifs du `final_review` de ce pack correspondent aux huit branches auditées. État PROD actuel : non certifié par cette passe.

13 tables, 210 colonnes (181 Hub), 52 index, 27 PRIMARY/UNIQUE. InnoDB, utf8/utf8_general_ci. Aucune FOREIGN KEY déclarée ; cohérence des références portée par les writers et les contrôles de backfill. Les colonnes JSON restent TEXT/MEDIUMTEXT. Ne pas rejouer les anciennes migrations Games.

Les clés uniques protègent notamment contexte/token Hub, membership Hub/session, identité Hub/joueur, accès joueur/session, clé de commande Remote et idempotence Quick par client. Les index de présence/queue soutiennent les polls et les claims ; leur absence peut provoquer scans et contention.

Données initiales : racines Hub et memberships complets du lot courant validé par le backfill séparé ; sessions legacy, clients, événements et identités préservés. Pas de roster, exécution, présence, commande, podium, publication Hub ou lots artificiels à précréer. Publication héritée du compte ; lots legacy conservés. Les présences/access/commandes se créent au runtime. Aucun jeu de seed universel supplémentaire identifié.

Prérequis legacy : general_branding type 5, game_events (exécutions/readiness), championnats_sessions et ses runtimes jeux, opérations/client/joueurs/médias existants. Voir INVENTAIRE du pack pour la liste des références. blindtest_session_teams non requise tant que BLINDTEST_TEAMS_ENABLED=false et gardes Canvas conservées. Les ensures Bibliothèque Pro peuvent encore tenter DDL/normalisations legacy : réserve distincte.

## games_hubs

| Colonne | Définition / défaut / NULL | Source du contrat |
|---|---|---|
| `id` | `int(10) UNSIGNED NOT NULL AUTO_INCREMENT` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:185` |
| `id_securite` | `varchar(64) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:186` |
| `id_client` | `mediumint(9) UNSIGNED NOT NULL DEFAULT 0` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:187` |
| `hub_date` | `date NOT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:188` |
| `context_type` | `varchar(16) NOT NULL DEFAULT 'day'` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:189` |
| `id_operation_evenement` | `int(10) UNSIGNED NOT NULL DEFAULT 0` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:190` |
| `hub_label` | `varchar(255) DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:191` |
| `flag_active` | `tinyint(1) UNSIGNED NOT NULL DEFAULT 1` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:192` |
| `hub_status` | `varchar(32) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:193` |
| `active_session_id` | `int(10) UNSIGNED NOT NULL DEFAULT 0` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:194` |
| `active_session_activated_at` | `datetime DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:195` |
| `remote_routing_generation` | `bigint(20) UNSIGNED NOT NULL DEFAULT 0` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:196` |
| `remote_routing_intent_id` | `varchar(80) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:197` |
| `remote_transition_type` | `varchar(32) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:198` |
| `remote_transition_payload_json` | `text DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:199` |
| `remote_transition_started_at` | `datetime DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:200` |
| `presentation_session_id` | `int(10) UNSIGNED DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:201` |
| `presentation_mode` | `varchar(24) NOT NULL DEFAULT 'session'` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:202` |
| `presentation_updated_at` | `datetime DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:203` |
| `hub_master_instance_id` | `varchar(80) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:204` |
| `hub_master_instance_seen_at` | `datetime DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:205` |
| `hub_remote_instance_id` | `varchar(80) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:206` |
| `hub_remote_instance_seen_at` | `datetime DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:207` |
| `prizes_initialized_at` | `datetime DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:208` |
| `delete_operation_token` | `varchar(80) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:209` |
| `delete_step` | `varchar(48) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:210` |
| `delete_started_at` | `datetime DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:211` |
| `delete_error_at` | `datetime DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:212` |
| `date_ajout` | `datetime NOT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:213` |
| `date_maj` | `datetime DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:214` |
| `player_qr_display_mode` | `varchar(8) NULL DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hub_player_qr_functions.php:10` |
| `player_qr_display_revision` | `bigint(20) UNSIGNED NOT NULL DEFAULT 0` | `global/web/app/modules/jeux/hubs/app_games_hub_player_qr_functions.php:10` |
| `player_qr_display_confirmation_json` | `text NULL DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hub_player_qr_functions.php:10` |
| `player_qr_official_started_at` | `datetime NULL DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hub_player_qr_functions.php:10` |

Index et contraintes :

- `PRIMARY KEY (`id`)`
- `UNIQUE KEY `uniq_games_hubs_token` (`id_securite`)`
- `UNIQUE KEY `uniq_games_hubs_context` (`id_client`,`hub_date`,`context_type`,`id_operation_evenement`)`
- `KEY `idx_games_hubs_client_date` (`id_client`,`hub_date`)`
- `KEY `idx_games_hubs_active_session` (`active_session_id`)`
- `KEY `idx_games_hubs_presentation_session` (`presentation_session_id`)`
- `KEY `idx_games_hubs_operation` (`id_operation_evenement`)`

## games_hubs_sessions

| Colonne | Définition / défaut / NULL | Source du contrat |
|---|---|---|
| `id` | `int(10) UNSIGNED NOT NULL AUTO_INCREMENT` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:276` |
| `id_hub` | `int(10) UNSIGNED NOT NULL DEFAULT 0` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:277` |
| `id_session` | `int(10) UNSIGNED NOT NULL DEFAULT 0` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:278` |
| `membership_source` | `varchar(32) NOT NULL DEFAULT 'legacy_reconciled'` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:279` |
| `status` | `enum('active','inactive') NOT NULL DEFAULT 'active'` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:280` |
| `created_at` | `datetime NOT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:281` |
| `updated_at` | `datetime DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:282` |

Index et contraintes :

- `PRIMARY KEY (`id`)`
- `UNIQUE KEY `uniq_games_hubs_sessions_hub_session` (`id_hub`,`id_session`)`
- `KEY `idx_games_hubs_sessions_hub_status` (`id_hub`,`status`)`
- `KEY `idx_games_hubs_sessions_session` (`id_session`)`

## games_hubs_players

| Colonne | Définition / défaut / NULL | Source du contrat |
|---|---|---|
| `id` | `int(10) UNSIGNED NOT NULL AUTO_INCREMENT` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:293` |
| `id_hub` | `int(10) UNSIGNED NOT NULL DEFAULT 0` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:294` |
| `id_client` | `mediumint(9) UNSIGNED NOT NULL DEFAULT 0` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:295` |
| `id_operation_evenement` | `int(10) UNSIGNED NOT NULL DEFAULT 0` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:296` |
| `hub_token` | `varchar(64) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:297` |
| `player_token` | `varchar(96) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:298` |
| `auth_identity_key` | `varchar(128) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:299` |
| `id_ep_player` | `int(10) UNSIGNED NOT NULL DEFAULT 0` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:300` |
| `auth_type` | `enum('guest','ep') NOT NULL DEFAULT 'guest'` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:301` |
| `pseudo` | `varchar(80) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:302` |
| `pseudo_normalized` | `varchar(80) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:303` |
| `status` | `enum('active','left') NOT NULL DEFAULT 'active'` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:304` |
| `return_token` | `varchar(64) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:305` |
| `return_expires_at` | `datetime DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:306` |
| `created_at` | `datetime NOT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:307` |
| `updated_at` | `datetime DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:308` |
| `last_seen_at` | `datetime DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:309` |
| `last_ip` | `varchar(45) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:310` |
| `user_agent_hash` | `char(40) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:311` |
| `hub_photo_media_id` | `int(10) UNSIGNED NOT NULL DEFAULT 0` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:312` |
| `hub_photo_game_key` | `varchar(32) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:313` |
| `hub_photo_source` | `varchar(32) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:314` |
| `hub_photo_updated_at` | `datetime DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:315` |
| `stats_aggregate_score` | `int(10) UNSIGNED NOT NULL DEFAULT 0` | `games/web/includes/canvas/sql/2026-07-30_games_hubs_players_stats_projection.sql:60` |
| `stats_wins_count` | `int(10) UNSIGNED NOT NULL DEFAULT 0` | `games/web/includes/canvas/sql/2026-07-30_games_hubs_players_stats_projection.sql:76` |
| `stats_second_places_count` | `int(10) UNSIGNED NOT NULL DEFAULT 0` | `games/web/includes/canvas/sql/2026-07-30_games_hubs_players_stats_projection.sql:92` |
| `stats_third_places_count` | `int(10) UNSIGNED NOT NULL DEFAULT 0` | `games/web/includes/canvas/sql/2026-07-30_games_hubs_players_stats_projection.sql:108` |
| `stats_parties_count` | `int(10) UNSIGNED NOT NULL DEFAULT 0` | `games/web/includes/canvas/sql/2026-07-30_games_hubs_players_stats_projection.sql:124` |
| `stats_last_result_at` | `datetime DEFAULT NULL` | `games/web/includes/canvas/sql/2026-07-30_games_hubs_players_stats_projection.sql:140` |
| `stats_source_revision` | `char(40) DEFAULT NULL` | `games/web/includes/canvas/sql/2026-07-30_games_hubs_players_stats_projection.sql:156` |
| `stats_computed_at` | `datetime DEFAULT NULL` | `games/web/includes/canvas/sql/2026-07-30_games_hubs_players_stats_projection.sql:172` |
| `stats_dirty_at` | `datetime DEFAULT NULL` | `games/web/includes/canvas/sql/2026-07-30_games_hubs_players_stats_projection.sql:188` |
| `stats_error` | `varchar(255) DEFAULT NULL` | `games/web/includes/canvas/sql/2026-07-30_games_hubs_players_stats_projection.sql:204` |

Index et contraintes :

- `PRIMARY KEY (`id`)`
- `UNIQUE KEY `uniq_games_hubs_players_identity` (`id_hub`,`auth_identity_key`)`
- `KEY `idx_games_hubs_players_hub_status` (`id_hub`,`status`)`
- `KEY `idx_games_hubs_players_pseudo` (`id_hub`,`pseudo_normalized`)`
- `KEY `idx_games_hubs_players_return` (`return_token`)`

## games_hubs_participations_probables

| Colonne | Définition / défaut / NULL | Source du contrat |
|---|---|---|
| `id` | `int(10) UNSIGNED NOT NULL AUTO_INCREMENT` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:326` |
| `id_hub` | `int(10) UNSIGNED NOT NULL DEFAULT 0` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:327` |
| `id_client` | `mediumint(9) UNSIGNED NOT NULL DEFAULT 0` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:328` |
| `id_operation_evenement` | `int(10) UNSIGNED NOT NULL DEFAULT 0` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:329` |
| `hub_token` | `varchar(64) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:330` |
| `auth_identity_key` | `varchar(128) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:331` |
| `id_ep_player` | `int(10) UNSIGNED NOT NULL DEFAULT 0` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:332` |
| `source` | `varchar(32) NOT NULL DEFAULT 'hub_play'` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:333` |
| `status` | `enum('declared','cancelled','confirmed') NOT NULL DEFAULT 'declared'` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:334` |
| `date_ajout` | `datetime NOT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:335` |
| `date_maj` | `datetime DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:336` |
| `declared_at` | `datetime DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:337` |
| `cancelled_at` | `datetime DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:338` |
| `confirmed_at` | `datetime DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:339` |
| `ip` | `varchar(45) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:340` |
| `id_user_ajout` | `mediumint(9) UNSIGNED NOT NULL DEFAULT 0` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:341` |
| `id_user_maj` | `mediumint(9) UNSIGNED NOT NULL DEFAULT 0` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:342` |

Index et contraintes :

- `PRIMARY KEY (`id`)`
- `UNIQUE KEY `uniq_games_hubs_probables_identity` (`id_hub`,`auth_identity_key`)`
- `KEY `idx_games_hubs_probables_hub_status` (`id_hub`,`status`)`
- `KEY `idx_games_hubs_probables_ep` (`id_ep_player`)`

## games_hubs_players_sessions

| Colonne | Définition / défaut / NULL | Source du contrat |
|---|---|---|
| `id` | `int(10) UNSIGNED NOT NULL AUTO_INCREMENT` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:366` |
| `id_hub` | `int(10) UNSIGNED NOT NULL DEFAULT 0` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:367` |
| `id_hub_player` | `int(10) UNSIGNED NOT NULL DEFAULT 0` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:368` |
| `id_session` | `int(10) UNSIGNED NOT NULL DEFAULT 0` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:369` |
| `session_token` | `varchar(64) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:370` |
| `game_type` | `varchar(32) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:371` |
| `id_participation` | `int(10) UNSIGNED NOT NULL DEFAULT 0` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:372` |
| `participant_key` | `varchar(128) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:373` |
| `id_ep_player` | `int(10) UNSIGNED NOT NULL DEFAULT 0` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:374` |
| `status` | `enum('created','active','left','completed','failed') NOT NULL DEFAULT 'created'` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:375` |
| `auto_joined_at` | `datetime DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:376` |
| `manual_joined_at` | `datetime DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:377` |
| `last_joined_at` | `datetime DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:378` |
| `left_at` | `datetime DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:379` |
| `completed_at` | `datetime DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:380` |
| `join_count` | `int(10) UNSIGNED NOT NULL DEFAULT 0` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:381` |
| `last_action` | `varchar(32) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:382` |
| `created_at` | `datetime NOT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:383` |
| `updated_at` | `datetime DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:384` |
| `last_error` | `varchar(255) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:385` |

Index et contraintes :

- `PRIMARY KEY (`id`)`
- `UNIQUE KEY `uniq_games_hubs_players_sessions_player_session` (`id_hub_player`,`id_session`)`
- `KEY `idx_games_hubs_players_sessions_hub_session` (`id_hub`,`id_session`)`
- `KEY `idx_games_hubs_players_sessions_session` (`id_session`)`
- `KEY `idx_games_hubs_players_sessions_participant` (`game_type`,`participant_key`)`

## games_hubs_publication

| Colonne | Définition / défaut / NULL | Source du contrat |
|---|---|---|
| `id` | `int(10) UNSIGNED NOT NULL AUTO_INCREMENT` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:426` |
| `id_hub` | `int(10) UNSIGNED NOT NULL DEFAULT 0` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:427` |
| `title` | `varchar(150) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:428` |
| `tagline` | `varchar(255) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:429` |
| `description` | `text` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:430` |
| `location_name` | `varchar(150) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:431` |
| `address` | `varchar(180) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:432` |
| `postal_code` | `varchar(20) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:433` |
| `city` | `varchar(120) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:434` |
| `country` | `varchar(80) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:435` |
| `website_url` | `varchar(255) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:436` |
| `cta_label` | `varchar(150) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:437` |
| `publication_status` | `varchar(32) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:438` |
| `date_ajout` | `datetime NOT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:439` |
| `date_maj` | `datetime DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:440` |

Index et contraintes :

- `PRIMARY KEY (`id`)`
- `UNIQUE KEY `uniq_games_hubs_publication_hub` (`id_hub`)`

## games_hubs_prizes

| Colonne | Définition / défaut / NULL | Source du contrat |
|---|---|---|
| `id` | `int(10) UNSIGNED NOT NULL AUTO_INCREMENT` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:449` |
| `id_hub` | `int(10) UNSIGNED NOT NULL DEFAULT 0` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:450` |
| `rank` | `tinyint(3) UNSIGNED NOT NULL DEFAULT 0` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:451` |
| `label` | `varchar(120) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:452` |
| `description` | `varchar(255) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:453` |
| `date_ajout` | `datetime NOT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:454` |
| `date_maj` | `datetime DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:455` |

Index et contraintes :

- `PRIMARY KEY (`id`)`
- `UNIQUE KEY `uniq_games_hubs_prizes_hub_rank` (`id_hub`,`rank`)`
- `KEY `idx_games_hubs_prizes_hub` (`id_hub`)`

## games_hubs_remote_access

| Colonne | Définition / défaut / NULL | Source du contrat |
|---|---|---|
| `id` | `int(10) UNSIGNED NOT NULL AUTO_INCREMENT` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:465` |
| `id_hub` | `int(10) UNSIGNED NOT NULL DEFAULT 0` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:466` |
| `id_client` | `mediumint(9) UNSIGNED NOT NULL DEFAULT 0` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:467` |
| `remote_token` | `varchar(96) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:468` |
| `remote_token_hash` | `char(64) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:469` |
| `session_token_hash` | `char(64) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:470` |
| `status` | `enum('active','revoked') NOT NULL DEFAULT 'active'` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:471` |
| `label` | `varchar(80) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:472` |
| `created_at` | `datetime NOT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:473` |
| `revoked_at` | `datetime DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:474` |
| `last_seen_at` | `datetime DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:475` |
| `last_ip` | `varchar(45) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:476` |
| `user_agent_hash` | `char(40) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:477` |

Index et contraintes :

- `PRIMARY KEY (`id`)`
- `UNIQUE KEY `uniq_games_hubs_remote_token_hash` (`remote_token_hash`)`
- `KEY `idx_games_hubs_remote_hub_status` (`id_hub`,`status`)`
- `KEY `idx_games_hubs_remote_session_hash` (`session_token_hash`)`

## games_hubs_remote_master_presence

| Colonne | Définition / défaut / NULL | Source du contrat |
|---|---|---|
| `id` | `int(10) UNSIGNED NOT NULL AUTO_INCREMENT` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:488` |
| `id_hub` | `int(10) UNSIGNED NOT NULL DEFAULT 0` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:489` |
| `master_instance_id` | `varchar(80) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:490` |
| `last_seen_at` | `datetime NOT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:491` |
| `last_applied_preparation_revision` | `varchar(64) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:492` |
| `last_control_revision` | `varchar(64) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:493` |
| `visibility` | `varchar(16) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:494` |
| `user_agent_hash` | `char(40) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:495` |
| `created_at` | `datetime NOT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:496` |
| `updated_at` | `datetime DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:497` |

Index et contraintes :

- `PRIMARY KEY (`id`)`
- `UNIQUE KEY `uniq_games_hubs_remote_presence_master` (`id_hub`,`master_instance_id`)`
- `KEY `idx_games_hubs_remote_presence_seen` (`id_hub`,`last_seen_at`)`

## games_hubs_remote_runtime_presence

| Colonne | Définition / défaut / NULL | Source du contrat |
|---|---|---|
| `id` | `int(10) UNSIGNED NOT NULL AUTO_INCREMENT` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:507` |
| `id_hub` | `int(10) UNSIGNED NOT NULL DEFAULT 0` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:508` |
| `id_session` | `int(10) UNSIGNED NOT NULL DEFAULT 0` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:509` |
| `execution_id` | `varchar(80) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:510` |
| `master_instance_id` | `varchar(80) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:511` |
| `last_seen_at` | `datetime NOT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:512` |
| `visibility` | `varchar(16) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:513` |
| `user_agent_hash` | `char(40) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:514` |
| `created_at` | `datetime NOT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:515` |
| `updated_at` | `datetime DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:516` |

Index et contraintes :

- `PRIMARY KEY (`id`)`
- `UNIQUE KEY `uniq_games_hubs_remote_runtime_master` (`id_hub`,`id_session`,`execution_id`,`master_instance_id`)`
- `KEY `idx_games_hubs_remote_runtime_seen` (`id_hub`,`id_session`,`execution_id`,`last_seen_at`)`

## games_hubs_remote_commands

| Colonne | Définition / défaut / NULL | Source du contrat |
|---|---|---|
| `id` | `int(10) UNSIGNED NOT NULL AUTO_INCREMENT` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:526` |
| `id_hub` | `int(10) UNSIGNED NOT NULL DEFAULT 0` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:527` |
| `id_remote_access` | `int(10) UNSIGNED NOT NULL DEFAULT 0` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:528` |
| `command_type` | `varchar(32) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:529` |
| `payload_json` | `text` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:530` |
| `status` | `enum('pending','claimed','processing','completed','failed','expired','cancelled') NOT NULL DEFAULT 'pending'` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:531` |
| `remote_command_key` | `varchar(96) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:532` |
| `created_at` | `datetime NOT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:533` |
| `expires_at` | `datetime NOT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:534` |
| `claimed_by` | `varchar(80) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:535` |
| `claimed_at` | `datetime DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:536` |
| `completed_at` | `datetime DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:537` |
| `result_json` | `text` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:538` |
| `error_code` | `varchar(64) NOT NULL DEFAULT ''` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:539` |
| `date_maj` | `datetime DEFAULT NULL` | `global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:540` |

Index et contraintes :

- `PRIMARY KEY (`id`)`
- `UNIQUE KEY `uniq_games_hubs_remote_command_key` (`id_hub`,`remote_command_key`)`
- `KEY `idx_games_hubs_remote_commands_pending` (`id_hub`,`status`,`expires_at`,`id`)`
- `KEY `idx_games_hubs_remote_commands_access` (`id_remote_access`,`created_at`)`

## programming_quick_operations

| Colonne | Définition / défaut / NULL | Source du contrat |
|---|---|---|
| `id` | `int(10) UNSIGNED NOT NULL AUTO_INCREMENT` | `documentation/programming_quick_operations_phpmyadmin.sql:6` |
| `id_client` | `int(10) UNSIGNED NOT NULL DEFAULT 0` | `documentation/programming_quick_operations_phpmyadmin.sql:7` |
| `idempotency_key` | `varchar(80) NOT NULL DEFAULT ''` | `documentation/programming_quick_operations_phpmyadmin.sql:8` |
| `command_hash` | `char(64) NOT NULL DEFAULT ''` | `documentation/programming_quick_operations_phpmyadmin.sql:9` |
| `status` | `varchar(24) NOT NULL DEFAULT 'pending'` | `documentation/programming_quick_operations_phpmyadmin.sql:10` |
| `operation_step` | `varchar(32) NOT NULL DEFAULT 'pending'` | `documentation/programming_quick_operations_phpmyadmin.sql:11` |
| `session_ids_json` | `text` | `documentation/programming_quick_operations_phpmyadmin.sql:12` |
| `session_security_ids_json` | `text` | `documentation/programming_quick_operations_phpmyadmin.sql:13` |
| `hub_id` | `int(10) UNSIGNED NOT NULL DEFAULT 0` | `documentation/programming_quick_operations_phpmyadmin.sql:14` |
| `dashboard_url` | `varchar(255) NOT NULL DEFAULT ''` | `documentation/programming_quick_operations_phpmyadmin.sql:15` |
| `result_json` | `text` | `documentation/programming_quick_operations_phpmyadmin.sql:16` |
| `error_code` | `varchar(80) NOT NULL DEFAULT ''` | `documentation/programming_quick_operations_phpmyadmin.sql:17` |
| `created_at` | `datetime NOT NULL` | `documentation/programming_quick_operations_phpmyadmin.sql:18` |
| `updated_at` | `datetime NOT NULL` | `documentation/programming_quick_operations_phpmyadmin.sql:19` |
| `expires_at` | `datetime NOT NULL` | `documentation/programming_quick_operations_phpmyadmin.sql:20` |

Index et contraintes :

- `PRIMARY KEY (`id`)`
- `UNIQUE KEY `uniq_programming_quick_client_key` (`id_client`,`idempotency_key`)`
- `KEY `idx_programming_quick_expires_at` (`expires_at`)`
- `KEY `idx_programming_quick_client_status` (`id_client`,`status`)`

## programming_quick_series_operations

| Colonne | Définition / défaut / NULL | Source du contrat |
|---|---|---|
| `id` | `int(10) UNSIGNED NOT NULL AUTO_INCREMENT` | `documentation/programming_quick_series_operations_phpmyadmin.sql:6` |
| `id_client` | `int(10) UNSIGNED NOT NULL DEFAULT 0` | `documentation/programming_quick_series_operations_phpmyadmin.sql:7` |
| `idempotency_key` | `varchar(80) NOT NULL DEFAULT ''` | `documentation/programming_quick_series_operations_phpmyadmin.sql:8` |
| `command_hash` | `char(64) NOT NULL DEFAULT ''` | `documentation/programming_quick_series_operations_phpmyadmin.sql:9` |
| `status` | `varchar(24) NOT NULL DEFAULT 'pending'` | `documentation/programming_quick_series_operations_phpmyadmin.sql:10` |
| `operation_step` | `varchar(32) NOT NULL DEFAULT 'pending'` | `documentation/programming_quick_series_operations_phpmyadmin.sql:11` |
| `template_json` | `mediumtext` | `documentation/programming_quick_series_operations_phpmyadmin.sql:12` |
| `recurrence_json` | `mediumtext` | `documentation/programming_quick_series_operations_phpmyadmin.sql:13` |
| `occurrences_json` | `mediumtext` | `documentation/programming_quick_series_operations_phpmyadmin.sql:14` |
| `themes_json` | `mediumtext` | `documentation/programming_quick_series_operations_phpmyadmin.sql:15` |
| `result_json` | `mediumtext` | `documentation/programming_quick_series_operations_phpmyadmin.sql:16` |
| `created_at` | `datetime NOT NULL` | `documentation/programming_quick_series_operations_phpmyadmin.sql:17` |
| `updated_at` | `datetime NOT NULL` | `documentation/programming_quick_series_operations_phpmyadmin.sql:18` |
| `expires_at` | `datetime NOT NULL` | `documentation/programming_quick_series_operations_phpmyadmin.sql:19` |

Index et contraintes :

- `PRIMARY KEY (`id`)`
- `UNIQUE KEY `uniq_programming_quick_series_client_key` (`id_client`,`idempotency_key`)`
- `KEY `idx_programming_quick_series_expires_at` (`expires_at`)`
- `KEY `idx_programming_quick_series_client_status` (`id_client`,`status`)`

