# A. Inventaire des branches et divergences — 09/09/2026

Neuf dépôts Git trouvés parmi les répertoires immédiats de `/home/romain/Cotton`. Huit portent `hub_soiree`. `documentation` : develop, pas de hub_soiree, modifications préexistantes conservées. `git ls-remote --heads origin main hub_soiree` confirme les SHA locaux pour les huit dépôts ; aucun fetch/push.

Les listes main...hub_soiree utilisent la base commune ; le delta de livraison simulé est main → arbre de merge, ce qui conserve les changements main-only. Les séquences Git sont inspectées séparément du statut porcelain.

## bingo.game

- Source locale : `/home/romain/Cotton/bingo.game` ; branche : `hub_soiree` ; main : `1038c05539bffa285567d75ffa2d023292311c77` ; hub_soiree : `42b829e63fc79675841b069ada2ceb293abef786`.
- Fichiers de travail propres. Séquence cherry-pick préexistante non terminée (sequencer, sans CHERRY_PICK_HEAD).
- Git : simulation de merge sans conflit.

### Commits Hub absents de main

```text
42b829e63fc79675841b069ada2ceb293abef786 hub_soiree
71746ed0519c88980214b012db82eb40993b1a60 hub_soiree
eab082dff738bedec55622bf6988a84d469418d1 hub_soiree
cf40ea8e787e0496d39243f6af7f5fd7a10966be hub_soiree
9fe5e625346212a635fb01d0cc0750ed4347665b hub_soiree
7e44ee200ad550c128defec637b871f9a91e77da hub_soiree
1ec830f88a74f43d38923f7a59ee39b82815dca3 hub_soiree
```

### Commits main absents de Hub

```text
(aucun)
```

### Fichiers main...hub_soiree

```text
M	version.txt
A	ws/bingo_phase_progress.js
A	ws/bingo_quit_guard.js
M	ws/bingo_server.js
A	ws/bingo_terminal_delivery.js
M	ws/envUtils.js
A	ws/tests/bingo_phase_progress.test.js
A	ws/tests/bingo_quit_guard.test.js
A	ws/tests/bingo_terminal_delivery.test.js
```

### Fichiers modifiés parallèlement par main

```text
(aucun)
```

### Delta simulé de livraison depuis main

```text
M	version.txt
A	ws/bingo_phase_progress.js
A	ws/bingo_quit_guard.js
M	ws/bingo_server.js
A	ws/bingo_terminal_delivery.js
M	ws/envUtils.js
A	ws/tests/bingo_phase_progress.test.js
A	ws/tests/bingo_quit_guard.test.js
A	ws/tests/bingo_terminal_delivery.test.js
```

## blindtest

- Source locale : `/home/romain/Cotton/blindtest` ; branche : `hub_soiree` ; main : `2823bc817ffa7e049999fd5dad981bac1ae50cb2` ; hub_soiree : `67f6cb0e3aac44832e9743cb83ed6dac87ab1e10`.
- Fichiers de travail propres. Aucune opération Git en cours détectée.
- Git : simulation de merge sans conflit.

### Commits Hub absents de main

```text
67f6cb0e3aac44832e9743cb83ed6dac87ab1e10 hub_soiree
bbba0de40be6da030e681ce9270d56e73af3aa38 hub_soiree
748d00841e720cde7f1a3c1689f9149669607253 hub_soiree
6c606a8e053b3440f44e05ec86ddff2a7adb35ed hub_soiree
ed043d8d73c76bc50d0887ac296075527edbfafb hub_soiree
2159964a4d0fda89a32f8240e6d37f400fd96f45 equipe_runtime
f414cc274e51644453277defc9fcafbb5de2bd2d equipe_runtime
b78f685f947b22996198f80de136e3390e14dc4b equipe_runtime
4f087d884298f3e616cf3a9bbbde4ac72cd401d9 equipe_runtime
0d8d742760bb8ba4f96279691bb7007b64172be6 equipe_runtime
```

### Commits main absents de Hub

```text
(aucun)
```

### Fichiers main...hub_soiree

```text
A	tests/teams-disabled.test.cjs
M	web/server/actions/audioControl.js
M	web/server/actions/connection.js
M	web/server/actions/envUtils.js
M	web/server/actions/gameplay.js
M	web/server/actions/registration.js
A	web/server/actions/teams.js
M	web/server/actions/wsHandler.js
A	web/server/features.js
M	web/server/messaging.js
M	web/server/restart_serveur.txt
```

### Fichiers modifiés parallèlement par main

```text
(aucun)
```

### Delta simulé de livraison depuis main

```text
A	tests/teams-disabled.test.cjs
M	web/server/actions/audioControl.js
M	web/server/actions/connection.js
M	web/server/actions/envUtils.js
M	web/server/actions/gameplay.js
M	web/server/actions/registration.js
A	web/server/actions/teams.js
M	web/server/actions/wsHandler.js
A	web/server/features.js
M	web/server/messaging.js
M	web/server/restart_serveur.txt
```

## games

- Source locale : `/home/romain/Cotton/games` ; branche : `hub_soiree` ; main : `786480de1ebc7854989ac61fcd01715331f3e651` ; hub_soiree : `71eb3c713e395aff269e5ebb73976362d8d5381b`.
- Fichiers de travail propres. Aucune opération Git en cours détectée.
- Git : simulation de merge sans conflit.

### Commits Hub absents de main

```text
71eb3c713e395aff269e5ebb73976362d8d5381b hub_soiree
1c58c3b3d827d50d8663c9e661d5f7af8c1d14eb hub_soiree
dcd045b602fe201480eae39ae1638c0a00f39f89 hub_soiree
b7801a303163de8fa46ab5c0310535fed8113ca9 hub_soiree
7503848535072104371528ed39523d81f6bbaa00 hub_soiree
d99ca5541691cb9dd019422915cc26668c187ae3 hub_soiree
c8c306b254198e88a3152376ccd5417d55e6d173 hub_soiree
4746ccfbdb29df65dfaa3bb9f75d576f841d4bc3 hub_soiree
d0155a84df1b0d9fdbb0bb203e3f6e6871a6c7aa hub_soiree
aa80a6b48f4d3804365c5efa3b4ed76d09f2ccc6 hub_soiree
6aab58cf5921618cb8461b1b0ea4b627f7004d05 hub_soiree
e34d406cd2d97383363da4aba3018aafa02251d2 hub_soiree
eb41a753e0dd704d90921cc2394231e8d4a88ffd hub_soiree
b189f098561a39df21195c7091b453a3b1237cfe hub_soiree
72b638fcc3c30ba0532f13d724ab63f1a6d2b8a7 hub_soiree
60d37a04f71fc19068f6ab11a91b5622350ee235 hub_soirée
bfe45428e07af17bdb935ec9b94a36a860144807 hub_soiree
247b1f98437cc775455842e6d5a502498484b64a hub_soiree
16e79bef203b8bc8117021986b65d47bf17f1b68 hub_soiree
31b5d9ceb75bb606530c3c8f1037b4ed1c9d26fc hub_soiree
1bd47af28d576abc4526241f93810f22492ef6f4 hub_soiree
652d03f78de2d3b691a551333a21b197daa09536 hub_soiree
2eef14e31b89ceb4800875f8717dbe96ef85efcf hub_soiree
4568340ba896358f5a115b92a5064a33efe24b6f hub_soiree
d0a4708bc717df3fb4633238170867651a34b7b9 hub_soirée
b8089e5a73eab290c6db9349f2e121f72215e1b3 hub_soiree
033f957dcff3133e1b5e56e7f3cb6fe5cf8d3736 hub_soiree
fc82fecb1fc4ba89cd616440a573448e662ef554 hub_soiree
21ffecf79f5804b4cc1ad0849ea2f3637b0e8cad hub_soiree
fb8e741a5c63cbe9629804d6f3a43dd15560359a hub_soiree
3af2d7015f19c55546f3b1002cbf2ac646414ea8 hub_soiree
7f560db33263640c5d18e2c47ac99f042678969a hub_soiree
9546149b72b21bc7bfeb99ab1d74faebd1c06600 hub_soiree
de938ed4ad9a27575257cdfae03eb47b2660af3b hub_soiree
1c566c3c14f496b64eb672a9d0107274a2b81e3f hub_soiree
c99db44b229765447f5977b00c1b1a19471951a5 hub_remote
504276b964c49958079beb4a76b083c59251ac9b hub_soirée
9e19063536d1c8dc8738ba1f77baf203945a9fef hub_soiree
b9577505c22a9652bfd2af98b8e0d73e7ada7d2a hub_soiree
d39ba0ce5f653490dc842fc7f5b6763cc0ddbb89 hub_soiree
8ae6de4ee79d7998521a632f8719db1ae88d2da9 hub_soiree
2fff51a8008de17c4d91d454d673b1938d23f2fc hub_soiree
581b9e5ef46d82821a22853e45edd4fb613b237c hub_soiree
69bb448eb00c1ac1f93074d6875c1094267df7f4 hub_soiree
bd4e4a78123ca739c6b9c321ca210b479c1329f5 hub_soiree
99f45529f6844219d860692223c2e94837090df1 hub_soiree
ca771b2896ef20cfd661e6711449f52100bc1570 hub_soiree
ee0730925b4a83d6e55a8f6d1c8fe5f11fe9ae7f hub_soiree
cbf249bd8b7b7640c9bde2d46693f9c87d7afab8 hub_soiree
8613b349bd9add0d7261366c42957df94d46bbf9 hub_soiree
b38c6c867d3b17885d544ba19a65b1c52b551ada hub_soiree
9c47a21cb21574d7f8ea7ef036cd0c33001d2596 hub_soiree
4dc215a0dd0bc4779adc63fef486688a6d35b418 hub_soiree
394cc22ae7550f1a5a829b52df2ba967b760bf67 hub_soiree
de01ee9cece1f00a33f00e73955c08743c4a929e hub_soiree
653e5ad5bf07470df1ec226f075b5af34042cb8d hub_soiree
e05904438517e2e3d837238e723af4357c961903 hub_soiree
7801a966f95f8dfeee90a8d7aad28b962995632f hub_soiree
0660d713ea1f6b10d39da671128a90a3f115ff7f hub_soiree
40e5844c437e7215d50a9ff879cd6c37952ca57b hub_soiree
a9e8d10f47b7fc8ac675c286bbff78dcc11fc624 hub_soiree
f28b57d11848225a797ccb4af643edc4c8e1d6d3 hub_soiree
fd3e5ecbef7487f665d3b3353a06de1b0f164f63 hub_soiree
6e7ef67c06852457ccc7f12260cde475e41a46c3 hub_soiree
50324c91f0ab45066d533e1b1692b62170ec76e0 hub_soiree
7f21159ab0d3e18713d2ceee20070c3927418986 hub_soiree
875a3ac721eec752bf86bb1600974a02f02372ff hub_soiree
5fa5a986ef414246a41e5750449fea086cacb700 hub_soiree
8256a8d444558f6cfd677f0d5bfb7a7eb163c04a hub_soiree
551863670772c532ffa9cd6833a9dd1563734232 hub_soiree
9befb6119bc97e55ab5e31336ed82b4b20d0c510 hub_soiree
fe077c10f215dadbdee0b82fc00bd3abd31ef59e hub_soiree
9d544766efbc9ad1c872b5f26c270153e5294054 hub_soiree
2b03de977fab100db9d3e053a2722f7f23c2acb5 hub_soiree
aebc477f9d53086b72cd1523d9ac1f2b8ccec280 hub_soiree
ee21bf54103dcddaf9f5f0f3e119b72e44b3dffd hub_soiree
470827696e9665556c5487d51de8ca11d8fd80fa hub_soiree
23dc03b31cf9fb6b3ebbc9bedec17043b78613e7 hub_soiree
7aae4bd1495d8d9ea9a0709b60d48d0d77c0c1e3 hub_soiree
1cf30d6d1b342a0b157ce16ebb690769084dfd41 hub_soiree
d5ee29ad49036099fcbafdc765f4334bef879edd hub_soiree
42fa54d266efd55774c1923380e1b067eea36fba hub_soiree
23b7d6e9eae421bed21815c0f2447af50c977864 hub_soiree
7e508cb4db0b6bdf6bed9f75664ae9ac67077ff4 hub_soiree
5ac212c1a9a92bca97e3910f5bc06af5ef2b3dd8 hub_soiree
ef4059c2e92866931164eab6cb7f8fd3050a20d4 hub_soiree
f913fbf5bd821b5f9ada0b8530d2575b91b4b3fc hub_soiree
d64fc6c565a10ef7b25ffbab8c8fa47dd6fb7c5f hub_soiree
6cf540ed30149353fd31673d383d40200352d8e8 hub_soiree
2b34398bcd82ac6487aa21c12919608368e9d8d8 hub_soiree
375daa197fcb8369632cf3e8465594eaaca5c9f7 hub_soiree
e5ca900c66e56820e31532835e4082fbe4f7d13e hub_soiree
56a55dfdefbc0b93a815b7a0e93451ad00c80556 hub_soiree
d06eb4e856f19a03119f98ad4b20518e280fab39 hub_soiree
47de394aa87ee58b6049082b3b8dffcba6dcb946 hub_soiree
b58b2bac17e2e0504c300145c08634614632c312 hub_soiree
d0f34b99fa64562e52c38a476f2e46833601f6e6 hub_soiree
4eb652b55f07b6919858b106ae4af4f49cb930e1 hub_soiree
4d8d00b30b9aa4b564e9714910fa6a55781e5100 hub_soiree
358f9374d273dc0aa7545ed16e791f49451908eb hub_soiree
85182adda233b3e60f8b37aec70cf04af2b65b14 equipe_runtime
1bf8287280e70b076bc715a9a834d0585327093b equipe_runtime
bee59f256b456a436973a1fd15c25a0f7b5adf09 equipe_runtime
24e2d55c8152012074a00a23d1a521e8e3e1f680 equipe_runtime
f2265de2e4c7e01ec09aae0b82a07a4ffbbb2cae equipe_runtime
```

### Commits main absents de Hub

```text
(aucun)
```

### Fichiers main...hub_soiree

```text
M	web/.htaccess
M	web/games_ajax.php
M	web/includes/canvas/core/api/api_client.js
M	web/includes/canvas/core/api_provider.js
M	web/includes/canvas/core/boot_organizer.js
M	web/includes/canvas/core/canvas_display.js
M	web/includes/canvas/core/end_game.js
M	web/includes/canvas/core/games/bingo_ui.js
A	web/includes/canvas/core/hub_player_qr.js
A	web/includes/canvas/core/hub_runtime_authority.js
A	web/includes/canvas/core/hub_transition.js
A	web/includes/canvas/core/launch_confirmation.js
M	web/includes/canvas/core/logger.global.js
M	web/includes/canvas/core/prelaunch_check.js
M	web/includes/canvas/core/qrcode-svg.js
M	web/includes/canvas/core/score_store.js
M	web/includes/canvas/core/session_modals.js
M	web/includes/canvas/core/session_sync.js
M	web/includes/canvas/core/ws_connector.js
M	web/includes/canvas/core/ws_effects.js
M	web/includes/canvas/css/canvas_styles.css
A	web/includes/canvas/css/hub_launch_confirmation.css
M	web/includes/canvas/css/player_styles.css
M	web/includes/canvas/css/remote_styles.css
A	web/includes/canvas/images/hub/podium-evening-3w-normalized.png
A	web/includes/canvas/images/hub/podium-evening-3w-source.png
A	web/includes/canvas/images/hub/podium-evening-3w.webp
M	web/includes/canvas/php/bingo_adapter_glue.php
M	web/includes/canvas/php/blindtest_adapter_glue.php
M	web/includes/canvas/php/boot_lib.php
M	web/includes/canvas/php/quiz_adapter_glue.php
A	web/includes/canvas/php/session_options_form.php
M	web/includes/canvas/play/play-ui.js
M	web/includes/canvas/play/play-ws.js
M	web/includes/canvas/play/register.js
M	web/includes/canvas/remote/remote-ui.js
M	web/includes/canvas/remote/remote-ws.js
A	web/includes/canvas/sql/2026-07-06_blindtest_session_teams.sql
A	web/includes/canvas/sql/2026-07-08_games_hubs_players.sql
A	web/includes/canvas/sql/2026-07-08_games_hubs_players_sessions.sql
A	web/includes/canvas/sql/2026-07-09_games_hubs_active_session_focus.sql
A	web/includes/canvas/sql/2026-07-09_games_hubs_players_sessions_access_state.sql
A	web/includes/canvas/sql/2026-07-17_games_hubs_prizes_initialization_state.sql
A	web/includes/canvas/sql/2026-07-17_games_hubs_publication_prizes.sql
A	web/includes/canvas/sql/2026-07-30_games_hubs_players_stats_projection.sql
A	web/includes/canvas/sql/2026-07-31_games_hubs_participations_probables.sql
A	web/includes/canvas/sql/2026-07-31_games_hubs_players_active_podium_photo.sql
A	web/includes/canvas/sql/2026-08-25_games_hubs_presentation_session.sql
A	web/modules/app_hub_master_ajax.php
A	web/modules/app_hub_play_ajax.php
A	web/modules/app_hub_remote_ajax.php
A	web/modules/app_hub_view_helpers.php
M	web/modules/app_orga_ajax.php
M	web/modules/app_play_ajax.php
M	web/organizer_canvas.php
M	web/player_canvas.php
M	web/remote_canvas.php
A	web/tests/bingo_paper_correction_test.mjs
A	web/tests/bingo_phase_winner_contract_test.php
A	web/tests/blindtest_teams_disabled_ui_test.mjs
A	web/tests/blindtest_teams_history_test.php
A	web/tests/hub_branding_sync_test.mjs
A	web/tests/hub_branding_sync_test.php
A	web/tests/hub_compact_aggregate_test.php
A	web/tests/hub_context_fast_path_test.php
A	web/tests/hub_demo_player_presentation_test.mjs
A	web/tests/hub_demo_qr_reentry_contract_test.php
A	web/tests/hub_demo_readiness_flow_test.php
A	web/tests/hub_demo_reentry_runtime_test.mjs
A	web/tests/hub_demo_runtime_surfaces_test.php
A	web/tests/hub_individual_terminal_master_test.php
A	web/tests/hub_launch_confirmation_contract_test.php
A	web/tests/hub_launch_confirmation_test.mjs
A	web/tests/hub_legacy_entry_routes_test.php
A	web/tests/hub_legacy_session_prizes_test.php
A	web/tests/hub_master_renewal_eligibility_model_test.php
A	web/tests/hub_natural_end_stats_rebuild_test.php
A	web/tests/hub_paper_historical_session_ensure_test.php
A	web/tests/hub_photo_replace_test.mjs
A	web/tests/hub_player_qr_test.mjs
A	web/tests/hub_presentation_runtime_separation_test.php
A	web/tests/hub_probable_play_contract_test.php
A	web/tests/hub_prospect_card_action_test.php
A	web/tests/hub_remote_contract_test.php
A	web/tests/hub_remote_master_ux_test.php
A	web/tests/hub_remote_polling_test.mjs
A	web/tests/hub_remote_return_execution_test.mjs
A	web/tests/hub_remote_ws_retry_test.mjs
A	web/tests/hub_session_settings_dom_test.mjs
A	web/tests/hub_session_settings_test.php
A	web/tests/hub_transition_remote_test.mjs
```

### Fichiers modifiés parallèlement par main

```text
(aucun)
```

### Delta simulé de livraison depuis main

```text
M	web/.htaccess
M	web/games_ajax.php
M	web/includes/canvas/core/api/api_client.js
M	web/includes/canvas/core/api_provider.js
M	web/includes/canvas/core/boot_organizer.js
M	web/includes/canvas/core/canvas_display.js
M	web/includes/canvas/core/end_game.js
M	web/includes/canvas/core/games/bingo_ui.js
A	web/includes/canvas/core/hub_player_qr.js
A	web/includes/canvas/core/hub_runtime_authority.js
A	web/includes/canvas/core/hub_transition.js
A	web/includes/canvas/core/launch_confirmation.js
M	web/includes/canvas/core/logger.global.js
M	web/includes/canvas/core/prelaunch_check.js
M	web/includes/canvas/core/qrcode-svg.js
M	web/includes/canvas/core/score_store.js
M	web/includes/canvas/core/session_modals.js
M	web/includes/canvas/core/session_sync.js
M	web/includes/canvas/core/ws_connector.js
M	web/includes/canvas/core/ws_effects.js
M	web/includes/canvas/css/canvas_styles.css
A	web/includes/canvas/css/hub_launch_confirmation.css
M	web/includes/canvas/css/player_styles.css
M	web/includes/canvas/css/remote_styles.css
A	web/includes/canvas/images/hub/podium-evening-3w-normalized.png
A	web/includes/canvas/images/hub/podium-evening-3w-source.png
A	web/includes/canvas/images/hub/podium-evening-3w.webp
M	web/includes/canvas/php/bingo_adapter_glue.php
M	web/includes/canvas/php/blindtest_adapter_glue.php
M	web/includes/canvas/php/boot_lib.php
M	web/includes/canvas/php/quiz_adapter_glue.php
A	web/includes/canvas/php/session_options_form.php
M	web/includes/canvas/play/play-ui.js
M	web/includes/canvas/play/play-ws.js
M	web/includes/canvas/play/register.js
M	web/includes/canvas/remote/remote-ui.js
M	web/includes/canvas/remote/remote-ws.js
A	web/includes/canvas/sql/2026-07-06_blindtest_session_teams.sql
A	web/includes/canvas/sql/2026-07-08_games_hubs_players.sql
A	web/includes/canvas/sql/2026-07-08_games_hubs_players_sessions.sql
A	web/includes/canvas/sql/2026-07-09_games_hubs_active_session_focus.sql
A	web/includes/canvas/sql/2026-07-09_games_hubs_players_sessions_access_state.sql
A	web/includes/canvas/sql/2026-07-17_games_hubs_prizes_initialization_state.sql
A	web/includes/canvas/sql/2026-07-17_games_hubs_publication_prizes.sql
A	web/includes/canvas/sql/2026-07-30_games_hubs_players_stats_projection.sql
A	web/includes/canvas/sql/2026-07-31_games_hubs_participations_probables.sql
A	web/includes/canvas/sql/2026-07-31_games_hubs_players_active_podium_photo.sql
A	web/includes/canvas/sql/2026-08-25_games_hubs_presentation_session.sql
A	web/modules/app_hub_master_ajax.php
A	web/modules/app_hub_play_ajax.php
A	web/modules/app_hub_remote_ajax.php
A	web/modules/app_hub_view_helpers.php
M	web/modules/app_orga_ajax.php
M	web/modules/app_play_ajax.php
M	web/organizer_canvas.php
M	web/player_canvas.php
M	web/remote_canvas.php
A	web/tests/bingo_paper_correction_test.mjs
A	web/tests/bingo_phase_winner_contract_test.php
A	web/tests/blindtest_teams_disabled_ui_test.mjs
A	web/tests/blindtest_teams_history_test.php
A	web/tests/hub_branding_sync_test.mjs
A	web/tests/hub_branding_sync_test.php
A	web/tests/hub_compact_aggregate_test.php
A	web/tests/hub_context_fast_path_test.php
A	web/tests/hub_demo_player_presentation_test.mjs
A	web/tests/hub_demo_qr_reentry_contract_test.php
A	web/tests/hub_demo_readiness_flow_test.php
A	web/tests/hub_demo_reentry_runtime_test.mjs
A	web/tests/hub_demo_runtime_surfaces_test.php
A	web/tests/hub_individual_terminal_master_test.php
A	web/tests/hub_launch_confirmation_contract_test.php
A	web/tests/hub_launch_confirmation_test.mjs
A	web/tests/hub_legacy_entry_routes_test.php
A	web/tests/hub_legacy_session_prizes_test.php
A	web/tests/hub_master_renewal_eligibility_model_test.php
A	web/tests/hub_natural_end_stats_rebuild_test.php
A	web/tests/hub_paper_historical_session_ensure_test.php
A	web/tests/hub_photo_replace_test.mjs
A	web/tests/hub_player_qr_test.mjs
A	web/tests/hub_presentation_runtime_separation_test.php
A	web/tests/hub_probable_play_contract_test.php
A	web/tests/hub_prospect_card_action_test.php
A	web/tests/hub_remote_contract_test.php
A	web/tests/hub_remote_master_ux_test.php
A	web/tests/hub_remote_polling_test.mjs
A	web/tests/hub_remote_return_execution_test.mjs
A	web/tests/hub_remote_ws_retry_test.mjs
A	web/tests/hub_session_settings_dom_test.mjs
A	web/tests/hub_session_settings_test.php
A	web/tests/hub_transition_remote_test.mjs
```

## global

- Source locale : `/home/romain/Cotton/global` ; branche : `hub_soiree` ; main : `5ec94b28a99830e4ccfb7e85b9e0d27234d6a344` ; hub_soiree : `626a76bfcd8b39bb192040bc21609b3f15fbfa1c`.
- Fichiers de travail propres. Aucune opération Git en cours détectée.
- Git : simulation de merge sans conflit.

### Commits Hub absents de main

```text
626a76bfcd8b39bb192040bc21609b3f15fbfa1c hub_soiree
1b7b4e452ba6ee9b5bdedfc5943071322b9c5f49 hub_soiree
9b41cbd0cf6c0abde96309ed683f3b17b91b0ada hub_soiree
80c5851de2c83faf1017ca6b8b9f16a97d7de71b hub_soiree
4651c59466d636d8394469f414c0c9e54d4bf1b3 hub_soiree
3b123b10371703014b2bf86e2fa5e127f3e6e463 hub_soiree
84703140dd56adef3e95cf8c42935abc117cbfce hub_soiree
e61a2de86e8b8aeb0aeda64059024e6050df5ce5 hub_soiree
365c8542eed4653597c15346f029881dea9b9346 hub_soiree
6a09b08a5f5bc34cd4d2a4e74daa514a20359579 hub_soiree
d31032d829f50feae04812bf52293fff3b7ef595 hub_soiree
0af24441671454915ee290b3bc206def6916cbf3 hub_soiree
516c072d863e8da781ee7541caa42011abff0604 periode
bf8daac2c33484da106a1e3a33a29d372115a750 renew_hors_cadre
df5584e3a1b4f6794202306ceb1465a649270834 renew_hors_cadre
ebc152873461f882563da3645254ae6a999d9f8f hub_soiree
24cc6ffb6914151f03202b870d244a241b6f2e90 hub_soiree
da63bdb7092f8fa61172c924b63a35354a295d41 hub_soiree
10edc694adbeac80ea75f2c5374e09f1de06fd2e hub_soiree
33156ed73656f3f8f1929090d4c770ccd3e01dac hub_soiree
96a42813157798b5748c7a87f593a8246c5bc8fa hub_soiree
14b0598e65e4f60e76a72a8a45fa86eeec711506 hub_soiree
fe9baa552410141c7d722b5077d6300b18a9d568 hub_soiree
e78825485b5c5d1789de61a37428ed842bfec40f hub_soiree
3508b175d1b396fa1e4ce39014eeda8645b260c8 hub_soiree
af8af3bc0860f346275cc998aae51ad59b9058c7 hub_soiree
16ad1791d6cdaf24e3e324cae21bfd0c1825b1a0 hub_soiree
e975958a17e8d00c135a1eb5762845d07f1694d7 hub_soiree
022140cd1c0868b5bc0e8f7ecc48382cceb719fc hub_soiree
780d7dbb23c59557378a4fb03657f2fa7fe1c88a hub_soiree
3da65b92b3b77af320e7a9d8f09f9e7f278ce179 hub_soiree
509345840e1c17fec72957b72b6ba2d7fb56104b hub_soiree
4fd6c0a340a11e77be81726df431ec53643c514b hub_soiree
c33fa9e0be0190ce846f6258666ba8fad6db549c hub_soiree
1ac37dea82d60bc86257e6b473ace9a51536b26b hub_soiree
fa139c9d2333dc3d8aa8fd885f303bedc54be087 hub_soiree
3094b42f06d0d566188771a97e3c2e9b02fc333e hub_soiree
636cb883a5d41347f2b55ee0789f7309b5281133 hub_soiree
f5b23dbc02001c6fd21a18232aae891767fef72e hub_soiree
a527c61bc9ec96b40d3e813cc63d1c38200dc97d hub_soiree
fd935b94f3a21fd833c26d17a48661ab1fb9527f hub_soiree
154137f813b66f9af1c69c11334bd9e300c4e535 hub_soiree
e98db4def46217cb52000ac353b6b9ae614010e4 hub_soiree
683f61a10b094464309b545c4680b3545ab503a8 hub_soiree
77f3c3592aaf3ea2dc54f5b5e96957d238c2581f hub_soiree
e6a82e589cfa012c5339548928ce2fab658b7526 hub_soiree
ca807573f12bc00c5531912f3e5273d6b3e4e9e5 hub-soiree
8c64ac2b14f81a9feea8474f3d0750bc9cd27aee hub_soiree
5be9042d032fed97d78043cd2a5c1983f2251674 hub_soiree
8943cbf58b661b6075fb2be0c01832b69680e693 hub_soiree
9f2f405a7427e58e82d956191f554b24dfe6f06b hub_soiree
2a8ae615dac1edea5a6e6fc742c6c7e03cb069da hub_soiree
3b4c1d736208fb2dc59622cbb12923e4ae898bbb hub_soiree
639764b561b45216011d282d15a8672ae5603640 hub_soiree
bce6e133447f6bdfd000ecdaf991282a89590972 hub_soiree
9a5e6e1bdf309ecf6bfb7881540a535a0205cea9 hub_soiree
4f8b86a7de79713ff2d451a4a0f6b6501d3e2b55 hub_soiree
fb174b241696eeee138bc7f40c708031a23d03c8 hub_soiree
6130860c1b13cae1c2bda63dd8e4a4a24962eedf hub_soiree
936d63193bfefffc3a725a6bbcf420394870d9ac hub_soiree
2cce4c68d7cd02011928df7275c7cd22c7d6d3c5 hub_soiree
3a99726a344ecb54f9201fc84fb6320096ab625e hub_soiree
db9a7791e12ef0f9d6661815c748b9567a4eb84b hub_soiree
8bc9b592a77e44a44520c38a73e9d900814aaac3 hub_soiree
2819baabcdc55fda7f5616d378275b9dd499b89f hub_soiree
03ab69f701d98ce06ca50cb32c2a297e5fda3ba6 hub_soiree
f3a8390ac030bb63c95d13e26de56ba15b0f529c hub_soiree
d5efc73e21a20edb62753ab344cc9d39bc641daf hub_soiree
03f6f1bff2020d969a340dd04136d6304212a7ad hub_soiree
79f38aaf541fc89252c57ecf307706eaa00ea3c7 hub_soiree
327cf6d3a3389c3b048e97f1243c7543bdac740f hub_soiree
7be4e13743b3b0047994fdff70433869685a8929 hub_soiree
9e2e8deb8093281f778063b4bc840ccd3e6bfb7e hub_soiree
598850cb7fe574fdfbfa93ef7bca5b5adce605ff hub_soiree
c8dea188901effc961b05c5021982b71279ca299 hub_soiree
e71fed8800c3a0494691b5d3144240ec126281fb hub_soiree
3fa16129a1db9d55e48caedeb07957a36374a12b hub_soiree
25a64030af767e4b7c89eeb6e8b99c000a8419db hub_soiree
37760025553db030f33c5970fc156a064eac817f hub_soiree
eaa36d27d3398021dcd25960bc3fabb10b58e720 hub_soiree
c486098d95c60aa869c4b6b520eb32a10c4a718d hub_soiree
32a29d99681ac372344c2bbc5f8d4b3b0f6ca537 hub_soiree
4497d2f3841dd214de74a1179bba84944e70bbcf hub_soiree
a78a994aafc9ef34d608b210c06ff8cca233cf6b hub_soiree
797840de717a1de571252f86cc36fa4ba42726e7 hub_soiree
1bad4daa3bd18a0ca65f2169ecf003030cbe248e hub_soiree
d87a01d984813592e5bba484b96af39a54f05dbe hub_soiree
d53b6fc35e54c8dcfc401fd781a956527d8ca4f5 equipe_runtime
fb86170a75572c24f386c1d9d9eebc99576b5e63 equipe_runtime
2a360679f7c18ce39f87217073113088cf203fec equipe_runtime
a43882b119cefa0221ae494dc4c3bcba9644544f equipe_runtime
```

### Commits main absents de Hub

```text
5ec94b28a99830e4ccfb7e85b9e0d27234d6a344 supp backfill périodes fact offres
2aa944e446191899915e68f413ed950bbb6b17eb periode
89a7dffa95739c6886a94a372eb5ff12efe264fd fix renouvellement Stripe offre déléguée hors cadre
98ca99c4f2bbc3353d06269efd276c0b7b6a0f88 Merge branch 'develop'
d5c06678fdfc59dca3f7f4345700fce5298bb014 Merge branch 'develop'
8f7707e209b46da31ae1d9d350b048c261e43387 Merge branch 'develop'
c942324608fcab8ec22034ce5fd16b6a7ec5447c Merge branch 'develop'
358c14dcd8472d2e2b289a3a32e779de79365d48 Merge branch 'develop'
08eed326fee43a8e007df46c07fdd0f4b06200b0 Merge branch 'develop'
f6cfb5b83c33eea31bacd780c8ba1284fdf05657 Merge branch 'develop'
a70ed93c32e422aed1cb2d99cd9fbf8420d3cb57 Merge branch 'develop'
7a49c13adc6a2c51771cdfff9b2e8fcc3892b673 Merge branch 'develop'
b57edc30b8a8fa140c2afd44836ea6d29f378847 Merge branch 'develop'
207b9d5ad8f1a4333fa14fdef0cacb863d41cc47 Merge branch 'develop'
5d5c6c005eef6f710bf620547efefde8c82df830 Merge branch 'develop'
02d4ed84a71a6ca9ecf0a3c63217c8526b60069f Merge branch 'develop'
0804a395113440642d73ae3da4723a3109369ace Merge branch 'develop'
524f27fef89004f2edb4e47a6244b032ebff6574 Merge branch 'develop'
7ab8558c8acd3a714a14c03f73abf63bd8a8ac69 Merge branch 'develop'
a8c55653ef826c22a90c1173969944bdb6587c13 Merge branch 'develop'
608b1eb36a6c9ab5640cb2921795beb208e9be31 Merge branch 'develop'
765bdb64b4d906f8afa615d53151f2161a2aa3f6 Merge branch 'develop'
9371afbb85877ed1197b978e57df5d304784e46f Merge branch 'develop'
e5ddd10e6fe97218a41042f7b00925fc58562431 Merge branch 'develop'
ed3813a5963dc41def36fa64f8c12dae89e6106d Merge branch 'develop'
7fcf89c33d3f6b0d745135e4f6d8cbfcd4e47293 Merge branch 'develop'
666a870e0751798cc3765296dc5da4ca26dcb4f7 Merge branch 'develop'
5ab39a83e223d31c5d98f809d163d86918690137 Merge branch 'develop'
808e4a91310d7b01e02794fab9fc638941854db0 gitignore
d1f84e0703baf490d028682065fd52bbfb4a03b4 Merge branch 'develop'
71fd36a9fbb13dafcc6453fe3864b87752920ab9 Merge branch 'develop'
9555966c01a44bee1d7b56a0a1ffa3abb0561ab5 Merge branch 'develop'
4f40e48096adcdeb173afd1895a52f8995180cdd Merge branch 'develop'
8bc60b8740bb5fd8e9eae202f4cc25b13f367ec1 Merge branch 'develop'
397f08d9f6c397c7d200509a1c2b5a278b67ae0b Merge branch 'develop'
d28f1e93463a129fdfb53ff4dd562115099e5c4a Merge branch 'develop'
04674baa1f7f137572fc64babac5a4381ef2de8b Merge branch 'develop'
a480594b5f4a665b3b3b166d46c7a22e3d5e9ec1 Merge branch 'develop'
7aa00c91999c181a9a34f440b2d15eaaae8729e1 Merge branch 'develop'
864053db7ba78c9bdc347ee2898cb0ccf09c1e9b Merge branch 'develop'
96cacd55738720b0b21f1ea7d49c7730b3d6e7d2 Merge branch 'develop'
17a87b65fc8a7b56e12db946e0619dbe07f1d630 Merge branch 'develop'
3db946f5f7b8ca4bd64adda3f2b7abd13981abd8 Merge branch 'develop'
23cacb284d17be9a0d33fe6b7e8bec7d00e12456 mise à niveau portail Stripe standard en prod
edabbf4ed1950ab053fce47fc41182b57d27e0ee ignore conf
6b2cc8874a972442cebe88f06e777d53fdfac780 Merge branch 'develop'
e184267109b21dd1dd7d088b52c668587283c8e6 config stripe prod
ed773ea3b9ba074ce120ccf90ce54c6cf8876b81 Merge branch 'develop'
80a4e49a35b79ed145fb7f760a67390fdd694642 Merge branch 'develop'
b43158e4030170fb8d5caeb541bb389b8b5ef449 Merge branch 'develop'
b8ec62a2a1bf926e26624d85907208825bc3dd02 Merge branch 'develop'
c7f38a2e80c276fb23bea8bed7d01419e6fa83f4 Merge branch 'develop'
21d6a4259912e0e8ea4fb258e973c758b538c662 Merge branch 'develop'
c3a512a9b71f157a50a33d08f2e9915b1f4de9ab Merge branch 'develop'
ee96e445fb094bcc1058695f59c86e871344aeae Merge branch 'develop'
4a3d6eedc23c895dbbc23cfae5a05147c0f7a19f Merge branch 'develop'
2cf4aa0e9ed31c50530f0dd702c3a4502193ed47 Merge branch 'develop'
26161d939c96f1fa10bdd5235370c906b3edc4b4 Merge branch 'develop'
f3cb76100b221b280a999f43017a2d3324afb837 Merge branch 'develop'
adcf8372b4b4ae020eb6139717d54c83be8053e0 Merge branch 'develop'
523058fa8e52c812b515434be4cb24491526f51f Merge branch 'develop'
069b2887fd2ae2482897529c6d1433b6b0b8c00b Merge branch 'develop'
6354c3967eda1c0812fe80f087feeb1b3eeadc7c Merge branch 'develop'
9b06da24a99f60870881afed7f17359989172a09 Merge branch 'develop'
e3a95d92596a3aa07728c27d929f0fb153100689 Merge branch 'develop'
18bd29f2995ec3bc09e95e1830672c2782e99277 Merge branch 'develop'
2fcf38a4793939bd510bae1568d3d8b83081592d Merge branch 'develop'
681df66c2db7ac2d4da4a0033e5f370fce48bbc9 Merge branch 'develop'
f101db6f576aeb53830dfd27917cf9e6615b6dfb Merge branch 'develop'
73086a98d2156f7ef74f348e42fd8f500125f663 Merge branch 'develop'
2d2bd70ae69b7337fea49812c489e63dc5f65196 Merge branch 'develop'
1648918c8d7140c767a2aeb9d7b4a8ac228cce79 Merge branch 'develop'
090d2d0b76be5d147a310c8e0091dbce388af314 Merge branch 'develop'
1ce865dab424ac3e220137d2623aa5006cb98748 Merge branch 'develop'
55d91fb92162dbc06380c717d2b70ee5e64ecf0c Merge branch 'develop'
961987ac67b4e4ee5eab5b9c44976ffd86700b8f Merge branch 'develop'
dd625be0d9c81536267214ced71573cc0320c324 Merge branch 'develop'
3112a716f0766d0a3d3e9394c6726008e707382e Merge branch 'develop'
4ce7afba6df7cc347dc06ffb424bdd9adc30efd8 compat serveur
```

### Fichiers main...hub_soiree

```text
M	web/app/modules/ecommerce/app_ecommerce_functions.php
A	web/app/modules/ecommerce/app_ecommerce_network_delegated_contract_support_test.php
M	web/app/modules/entites/clients/app_clients_functions.php
M	web/app/modules/entites/joueurs/app_joueurs_functions.php
M	web/app/modules/general/branding/app_branding_ajax.php
M	web/app/modules/general/branding/app_branding_functions.php
M	web/app/modules/jeux/bingo_musical/app_bingo_musical_functions.php
M	web/app/modules/jeux/blind_test/app_blind_test_functions.php
M	web/app/modules/jeux/cotton_quiz/app_cotton_quiz_functions.php
A	web/app/modules/jeux/hubs/app_games_hub_player_qr_functions.php
A	web/app/modules/jeux/hubs/app_games_hubs_functions.php
A	web/app/modules/jeux/programmation/app_programming_recommendations_functions.php
M	web/app/modules/jeux/sessions/app_sessions_functions.php
M	web/app/modules/jeux/sessions_branding/app_sessions_branding_functions.php
M	web/app/modules/operations/evenements/app_evenements_functions.php
A	web/assets/branding/hubs/cotton-hub-default-logo.png
A	web/assets/branding/hubs/cotton-hub-default-visual.jpg
M	web/global_ajax.php
M	web/global_librairies.php
A	web/tests/client_joueurs_dashboard_aggregate_ranking_test.php
A	web/tests/client_photo_src_test.php
A	web/tests/ecommerce_network_delegated_contract_renewal_test.php
A	web/tests/ecommerce_stripe_invoice_period_test.php
A	web/tests/ecommerce_stripe_subscription_period_test.php
A	web/tests/hub_aggregate_photo_fallback_test.php
A	web/tests/hub_client_routing_canonical_test.php
A	web/tests/hub_delete_service_contract_test.php
A	web/tests/hub_demo_mode_contract_test.php
A	web/tests/hub_ep_return_intent_test.php
A	web/tests/hub_guest_rejoin_test.php
A	web/tests/hub_identity_stability_contract_test.php
A	web/tests/hub_instance_exclusivity_contract_test.php
A	web/tests/hub_legacy_runtime_compatibility_test.php
A	web/tests/hub_operation_branding_cascade_test.php
A	web/tests/hub_paper_cold_runtime_bootstrap_contract_test.php
A	web/tests/hub_participation_counters_contract_test.php
A	web/tests/hub_photo_replace_test.php
A	web/tests/hub_player_qr_continuation_test.php
A	web/tests/hub_player_qr_master_command_test.php
A	web/tests/hub_player_qr_storage_test.php
A	web/tests/hub_player_qr_storage_test.py
A	web/tests/hub_player_qr_temporal_test.php
A	web/tests/hub_player_roster_registration_state_test.php
A	web/tests/hub_players_stats_projection_contract_test.php
A	web/tests/hub_players_stats_rebuild_cli_env_test.php
A	web/tests/hub_presentation_mode_contract_test.php
A	web/tests/hub_prizes_test.php
A	web/tests/hub_probable_participations_contract_test.php
A	web/tests/hub_publication_prizes_contract_test.php
A	web/tests/hub_remote_control_contract_test.php
A	web/tests/hub_session_membership_dev_diagnostic.php
A	web/tests/hub_stats_pending_session_test.php
A	web/tests/hub_terminal_provenance_test.php
A	web/tests/programming_quick_hub_service_contract_test.php
A	web/tests/programming_quick_idempotency_contract_test.php
A	web/tests/programming_quick_recommendation_test.php
A	web/tests/programming_quick_recurrence_test.php
A	web/tests/quiz_auto_history_label_contract_test.php
A	web/tests/schedule_plan_commit_behavior_test.php
A	web/tests/schedule_plan_commit_contract_test.php
A	web/tests/session_results_bingo_membership_contract_test.php
A	web/tests/session_results_podium_contract_test.php
A	web/tests/session_theme_renewal_apply_test.php
A	web/tests/session_theme_renewal_planner_test.php
A	web/tests/temporal_window_state_test.php
A	web/tools/hub_players_stats_rebuild.php
```

### Fichiers modifiés parallèlement par main

```text
M	web/app/modules/ecommerce/app_ecommerce_functions.php
A	web/app/modules/ecommerce/app_ecommerce_network_delegated_contract_support_test.php
A	web/assets/phpqrcode/cache/.gitkeep
A	web/assets/phpqrcode/cache/frame_1.dat
A	web/assets/phpqrcode/cache/frame_1.png
A	web/assets/phpqrcode/cache/frame_10.dat
A	web/assets/phpqrcode/cache/frame_10.png
A	web/assets/phpqrcode/cache/frame_11.dat
A	web/assets/phpqrcode/cache/frame_11.png
A	web/assets/phpqrcode/cache/frame_12.dat
A	web/assets/phpqrcode/cache/frame_12.png
A	web/assets/phpqrcode/cache/frame_13.dat
A	web/assets/phpqrcode/cache/frame_13.png
A	web/assets/phpqrcode/cache/frame_14.dat
A	web/assets/phpqrcode/cache/frame_14.png
A	web/assets/phpqrcode/cache/frame_15.dat
A	web/assets/phpqrcode/cache/frame_15.png
A	web/assets/phpqrcode/cache/frame_16.dat
A	web/assets/phpqrcode/cache/frame_16.png
A	web/assets/phpqrcode/cache/frame_17.dat
A	web/assets/phpqrcode/cache/frame_17.png
A	web/assets/phpqrcode/cache/frame_18.dat
A	web/assets/phpqrcode/cache/frame_18.png
A	web/assets/phpqrcode/cache/frame_19.dat
A	web/assets/phpqrcode/cache/frame_19.png
A	web/assets/phpqrcode/cache/frame_2.dat
A	web/assets/phpqrcode/cache/frame_2.png
A	web/assets/phpqrcode/cache/frame_20.dat
A	web/assets/phpqrcode/cache/frame_20.png
A	web/assets/phpqrcode/cache/frame_21.dat
A	web/assets/phpqrcode/cache/frame_21.png
A	web/assets/phpqrcode/cache/frame_22.dat
A	web/assets/phpqrcode/cache/frame_22.png
A	web/assets/phpqrcode/cache/frame_23.dat
A	web/assets/phpqrcode/cache/frame_23.png
A	web/assets/phpqrcode/cache/frame_24.dat
A	web/assets/phpqrcode/cache/frame_24.png
A	web/assets/phpqrcode/cache/frame_25.dat
A	web/assets/phpqrcode/cache/frame_25.png
A	web/assets/phpqrcode/cache/frame_26.dat
A	web/assets/phpqrcode/cache/frame_26.png
A	web/assets/phpqrcode/cache/frame_27.dat
A	web/assets/phpqrcode/cache/frame_27.png
A	web/assets/phpqrcode/cache/frame_28.dat
A	web/assets/phpqrcode/cache/frame_28.png
A	web/assets/phpqrcode/cache/frame_29.dat
A	web/assets/phpqrcode/cache/frame_29.png
A	web/assets/phpqrcode/cache/frame_3.dat
A	web/assets/phpqrcode/cache/frame_3.png
A	web/assets/phpqrcode/cache/frame_30.dat
A	web/assets/phpqrcode/cache/frame_30.png
A	web/assets/phpqrcode/cache/frame_31.dat
A	web/assets/phpqrcode/cache/frame_31.png
A	web/assets/phpqrcode/cache/frame_32.dat
A	web/assets/phpqrcode/cache/frame_32.png
A	web/assets/phpqrcode/cache/frame_33.dat
A	web/assets/phpqrcode/cache/frame_33.png
A	web/assets/phpqrcode/cache/frame_34.dat
A	web/assets/phpqrcode/cache/frame_34.png
A	web/assets/phpqrcode/cache/frame_35.dat
A	web/assets/phpqrcode/cache/frame_35.png
A	web/assets/phpqrcode/cache/frame_36.dat
A	web/assets/phpqrcode/cache/frame_36.png
A	web/assets/phpqrcode/cache/frame_37.dat
A	web/assets/phpqrcode/cache/frame_37.png
A	web/assets/phpqrcode/cache/frame_38.dat
A	web/assets/phpqrcode/cache/frame_38.png
A	web/assets/phpqrcode/cache/frame_39.dat
A	web/assets/phpqrcode/cache/frame_39.png
A	web/assets/phpqrcode/cache/frame_4.dat
A	web/assets/phpqrcode/cache/frame_4.png
A	web/assets/phpqrcode/cache/frame_40.dat
A	web/assets/phpqrcode/cache/frame_40.png
A	web/assets/phpqrcode/cache/frame_5.dat
A	web/assets/phpqrcode/cache/frame_5.png
A	web/assets/phpqrcode/cache/frame_6.dat
A	web/assets/phpqrcode/cache/frame_6.png
A	web/assets/phpqrcode/cache/frame_7.dat
A	web/assets/phpqrcode/cache/frame_7.png
A	web/assets/phpqrcode/cache/frame_8.dat
A	web/assets/phpqrcode/cache/frame_8.png
A	web/assets/phpqrcode/cache/frame_9.dat
A	web/assets/phpqrcode/cache/frame_9.png
A	web/assets/phpqrcode/cache/mask_0/mask_101_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_105_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_109_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_113_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_117_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_121_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_125_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_129_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_133_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_137_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_141_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_145_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_149_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_153_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_157_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_161_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_165_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_169_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_173_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_177_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_21_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_25_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_29_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_33_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_37_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_41_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_45_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_49_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_53_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_57_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_61_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_65_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_69_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_73_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_77_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_81_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_85_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_89_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_93_0.dat
A	web/assets/phpqrcode/cache/mask_0/mask_97_0.dat
A	web/assets/phpqrcode/cache/mask_1/mask_101_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_105_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_109_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_113_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_117_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_121_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_125_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_129_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_133_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_137_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_141_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_145_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_149_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_153_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_157_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_161_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_165_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_169_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_173_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_177_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_21_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_25_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_29_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_33_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_37_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_41_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_45_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_49_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_53_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_57_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_61_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_65_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_69_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_73_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_77_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_81_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_85_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_89_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_93_1.dat
A	web/assets/phpqrcode/cache/mask_1/mask_97_1.dat
A	web/assets/phpqrcode/cache/mask_2/mask_101_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_105_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_109_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_113_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_117_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_121_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_125_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_129_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_133_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_137_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_141_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_145_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_149_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_153_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_157_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_161_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_165_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_169_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_173_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_177_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_21_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_25_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_29_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_33_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_37_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_41_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_45_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_49_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_53_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_57_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_61_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_65_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_69_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_73_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_77_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_81_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_85_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_89_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_93_2.dat
A	web/assets/phpqrcode/cache/mask_2/mask_97_2.dat
A	web/assets/phpqrcode/cache/mask_3/mask_101_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_105_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_109_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_113_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_117_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_121_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_125_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_129_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_133_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_137_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_141_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_145_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_149_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_153_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_157_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_161_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_165_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_169_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_173_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_177_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_21_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_25_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_29_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_33_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_37_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_41_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_45_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_49_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_53_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_57_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_61_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_65_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_69_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_73_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_77_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_81_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_85_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_89_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_93_3.dat
A	web/assets/phpqrcode/cache/mask_3/mask_97_3.dat
A	web/assets/phpqrcode/cache/mask_4/mask_101_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_105_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_109_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_113_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_117_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_121_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_125_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_129_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_133_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_137_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_141_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_145_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_149_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_153_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_157_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_161_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_165_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_169_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_173_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_177_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_21_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_25_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_29_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_33_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_37_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_41_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_45_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_49_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_53_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_57_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_61_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_65_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_69_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_73_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_77_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_81_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_85_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_89_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_93_4.dat
A	web/assets/phpqrcode/cache/mask_4/mask_97_4.dat
A	web/assets/phpqrcode/cache/mask_5/mask_101_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_105_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_109_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_113_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_117_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_121_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_125_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_129_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_133_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_137_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_141_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_145_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_149_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_153_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_157_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_161_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_165_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_169_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_173_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_177_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_21_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_25_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_29_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_33_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_37_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_41_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_45_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_49_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_53_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_57_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_61_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_65_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_69_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_73_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_77_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_81_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_85_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_89_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_93_5.dat
A	web/assets/phpqrcode/cache/mask_5/mask_97_5.dat
A	web/assets/phpqrcode/cache/mask_6/mask_101_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_105_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_109_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_113_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_117_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_121_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_125_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_129_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_133_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_137_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_141_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_145_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_149_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_153_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_157_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_161_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_165_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_169_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_173_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_177_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_21_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_25_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_29_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_33_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_37_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_41_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_45_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_49_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_53_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_57_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_61_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_65_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_69_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_73_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_77_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_81_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_85_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_89_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_93_6.dat
A	web/assets/phpqrcode/cache/mask_6/mask_97_6.dat
A	web/assets/phpqrcode/cache/mask_7/mask_101_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_105_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_109_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_113_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_117_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_121_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_125_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_129_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_133_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_137_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_141_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_145_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_149_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_153_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_157_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_161_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_165_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_169_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_173_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_177_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_21_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_25_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_29_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_33_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_37_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_41_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_45_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_49_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_53_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_57_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_61_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_65_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_69_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_73_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_77_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_81_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_85_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_89_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_93_7.dat
A	web/assets/phpqrcode/cache/mask_7/mask_97_7.dat
A	web/tests/ecommerce_network_delegated_contract_renewal_test.php
A	web/tests/ecommerce_stripe_invoice_period_test.php
A	web/tests/ecommerce_stripe_subscription_period_test.php
```

### Delta simulé de livraison depuis main

```text
M	web/app/modules/entites/clients/app_clients_functions.php
M	web/app/modules/entites/joueurs/app_joueurs_functions.php
M	web/app/modules/general/branding/app_branding_ajax.php
M	web/app/modules/general/branding/app_branding_functions.php
M	web/app/modules/jeux/bingo_musical/app_bingo_musical_functions.php
M	web/app/modules/jeux/blind_test/app_blind_test_functions.php
M	web/app/modules/jeux/cotton_quiz/app_cotton_quiz_functions.php
A	web/app/modules/jeux/hubs/app_games_hub_player_qr_functions.php
A	web/app/modules/jeux/hubs/app_games_hubs_functions.php
A	web/app/modules/jeux/programmation/app_programming_recommendations_functions.php
M	web/app/modules/jeux/sessions/app_sessions_functions.php
M	web/app/modules/jeux/sessions_branding/app_sessions_branding_functions.php
M	web/app/modules/operations/evenements/app_evenements_functions.php
A	web/assets/branding/hubs/cotton-hub-default-logo.png
A	web/assets/branding/hubs/cotton-hub-default-visual.jpg
M	web/global_ajax.php
M	web/global_librairies.php
A	web/tests/client_joueurs_dashboard_aggregate_ranking_test.php
A	web/tests/client_photo_src_test.php
A	web/tests/hub_aggregate_photo_fallback_test.php
A	web/tests/hub_client_routing_canonical_test.php
A	web/tests/hub_delete_service_contract_test.php
A	web/tests/hub_demo_mode_contract_test.php
A	web/tests/hub_ep_return_intent_test.php
A	web/tests/hub_guest_rejoin_test.php
A	web/tests/hub_identity_stability_contract_test.php
A	web/tests/hub_instance_exclusivity_contract_test.php
A	web/tests/hub_legacy_runtime_compatibility_test.php
A	web/tests/hub_operation_branding_cascade_test.php
A	web/tests/hub_paper_cold_runtime_bootstrap_contract_test.php
A	web/tests/hub_participation_counters_contract_test.php
A	web/tests/hub_photo_replace_test.php
A	web/tests/hub_player_qr_continuation_test.php
A	web/tests/hub_player_qr_master_command_test.php
A	web/tests/hub_player_qr_storage_test.php
A	web/tests/hub_player_qr_storage_test.py
A	web/tests/hub_player_qr_temporal_test.php
A	web/tests/hub_player_roster_registration_state_test.php
A	web/tests/hub_players_stats_projection_contract_test.php
A	web/tests/hub_players_stats_rebuild_cli_env_test.php
A	web/tests/hub_presentation_mode_contract_test.php
A	web/tests/hub_prizes_test.php
A	web/tests/hub_probable_participations_contract_test.php
A	web/tests/hub_publication_prizes_contract_test.php
A	web/tests/hub_remote_control_contract_test.php
A	web/tests/hub_session_membership_dev_diagnostic.php
A	web/tests/hub_stats_pending_session_test.php
A	web/tests/hub_terminal_provenance_test.php
A	web/tests/programming_quick_hub_service_contract_test.php
A	web/tests/programming_quick_idempotency_contract_test.php
A	web/tests/programming_quick_recommendation_test.php
A	web/tests/programming_quick_recurrence_test.php
A	web/tests/quiz_auto_history_label_contract_test.php
A	web/tests/schedule_plan_commit_behavior_test.php
A	web/tests/schedule_plan_commit_contract_test.php
A	web/tests/session_results_bingo_membership_contract_test.php
A	web/tests/session_results_podium_contract_test.php
A	web/tests/session_theme_renewal_apply_test.php
A	web/tests/session_theme_renewal_planner_test.php
A	web/tests/temporal_window_state_test.php
A	web/tools/hub_players_stats_rebuild.php
```

## play

- Source locale : `/home/romain/Cotton/play` ; branche : `hub_soiree` ; main : `39d99115516c32de48cda157038f1222419dfa2c` ; hub_soiree : `4a7c22623ca2e8f0eef6dc176c51a4ed1876e733`.
- Fichiers de travail propres. Aucune opération Git en cours détectée.
- Git : simulation de merge sans conflit.

### Commits Hub absents de main

```text
4a7c22623ca2e8f0eef6dc176c51a4ed1876e733 hub_soiree
bc11023b3ee6093c66362ec4824437b983c0fc6b hub_soiree
103908df334ce89e2cdad805981d42373b2f4a45 hub_soiree
6a5c48df05c1de02029a426fccb03712b97209bf hub_soiree
480d106b73fa8d4d8bfd77707dc9470467b8f9cf hub_soiree
6f965d32c034fd66d4ede0101c6a516215be205b equipe_runtime
29adfb621f250bd83436a86c963aea03163c2c7f equipe_runtime
```

### Commits main absents de Hub

```text
(aucun)
```

### Fichiers main...hub_soiree

```text
M	web/.htaccess
M	web/ep/ep_signin.php
M	web/ep/ep_signup.php
M	web/ep/ep_signup_private.php
M	web/ep/modules/communication/home/ep_home_leaderboards_shared.php
M	web/ep/modules/compte/authentification/ep_authentification_script.php
M	web/ep/modules/compte/joueur/ep_joueur_script.php
A	web/ep/modules/jeux/hubs/ep_hubs_detail.php
M	web/ep/modules/jeux/sessions/ep_sessions_inscription_form.php
A	web/tests/ep_hub_detail_contract_test.php
```

### Fichiers modifiés parallèlement par main

```text
(aucun)
```

### Delta simulé de livraison depuis main

```text
M	web/.htaccess
M	web/ep/ep_signin.php
M	web/ep/ep_signup.php
M	web/ep/ep_signup_private.php
M	web/ep/modules/communication/home/ep_home_leaderboards_shared.php
M	web/ep/modules/compte/authentification/ep_authentification_script.php
M	web/ep/modules/compte/joueur/ep_joueur_script.php
A	web/ep/modules/jeux/hubs/ep_hubs_detail.php
M	web/ep/modules/jeux/sessions/ep_sessions_inscription_form.php
A	web/tests/ep_hub_detail_contract_test.php
```

## pro

- Source locale : `/home/romain/Cotton/pro` ; branche : `hub_soiree` ; main : `f5af07280eed17210353956060b52f11c9b68dd8` ; hub_soiree : `eaca08277ecf46ad884955798b7b8264bfd93b2f`.
- Fichiers de travail propres. Aucune opération Git en cours détectée.
- Git : conflit ec_offres_script.php ; simulation conservée sans résolution.

### Commits Hub absents de main

```text
eaca08277ecf46ad884955798b7b8264bfd93b2f hub_soiree
7a4449ada69800ee47e1a296a214be5ec581d889 hub_soiree
92a666f98c2c19359b33e2423503735bc6a0978b hub_soiree
df501a007973f4dffa75ab33e41e2e486f07a018 periode
57125d7edfd3dfb5da89a15af409b3e7916578a4 renew_hors_cadre
0c7bcc7dbccd9af06ac2ed126b4f2e1ed4b74e95 renew_hors_cadre
bf106d7e74307a589ec5e0759912abf4ed56a3c3 hub_soiree
7fb26a6a242b67dea89c2528535b25c4a55bfd3d hub_soiree
22ced5c9a15e58d58882f8ad427a79be55a7e082 hub_soiree
b801571b3bd3980125f486ccb31f7ae37eebe953 hub_soiree
6709310f377ca283ec203104d8dd3f3fcc0fcbc4 hub_soiree
0dd4e17a5f83b9d2b377182458b4ff21618e6a64 hub_soiree
bc9735380d918485dc25c00986fa54b2ea05dbc1 hub_soiree
269622536a630374075cda1570c3d2abc2d24cb9 hub_soiree
3b357a9cedeff8126c273b435b2eb15af8d603c4 hub_soiree
121942c23afe46edae0fcdc8605466d1e9b2ff58 hub_soiree
f942dbd38a05a6ccae2629eb9e4d840ab4296c47 hub_soiree
f6ac3f9a50a56b748007bbe070059810ba953073 hub_soiree
44ccbf83808482541864406cca704589145b6f18 hub_soiree
32f7c21665169357cc8c1f73f85992714ef60055 hub_soiree
ba230d7d60fd61d3e32369a2ab159ce9d30638b5 hub_soiree
38ff47d35cf451c282113eea8b0dee1683ae1654 hub_soiree
50a60ce97594b93df2ece87105732faaaede7219 hub_soiree
8dd7ee82347599bc7dc654d2d78dce35f5a91079 hub_soiree
565aa0bb8fe891d49c5c21f1a26a6b29d449ce7a hub_soiree
d9a0d75c43f1f2eed831f7fb8430244e9114922c hub_soiree
019cb3ee22374514241603e7798c1452d9037c62 hub_soiree
1c74c84e177fdeebf8991bc861c95dc193da29b7 hub_soiree
530502227c0ee45ef397ef220a1559d5ddfe83f5 hub_soiree
1a4d61f4f378b66f8ebb1d73ab537c2091cbd608 hub_soiree
511be10422b9164940a5a38ad9f78ecfcb3cb07b hub_soiree
89c963b2758495d0b64d14af3978510a54b92e32 hub_soiree
61fac184a612e3160a6baed010aa0257ed97305e hub_soiree
a2ac79c0a7854b485d5fe1cb530c9c897c50f45d hub_soiree
cca38110c92acaf60bb92ac0ee439f5ab3705880 hub_soiree
1a5e7f36a2cc50edbec5f5e3aba6b57f5d8b3942 hub_soiree
ae83e053c7dd0412b274efb18e59da29d030c2bd hub_soiree
993bd957fc2177b4c178d7365e8244d821604585 hub_soiree
a5bdfd0a3a22f66322397296ab29fdb5b258de3d hub_soiree
300e17a10b02e60b5f4103be2bbb6a45388e7446 hub_soiree
77e3ea21b3f01ddfcbc7a7cac8f982962c74f360 hub_soiree
e121aacde4f62bc16a538c9a2e30cbc66aa39200 hub_soiree
57d10a05b47b439eb147b613a081545a47b40513 hub_soiree
387840bb922414ceabde541bacd46cf10266faa3 hub_soiree
442929ae51dfd6c82d17ffd372389fea2f31f3c9 hub_soiree
6f7f089c1a0428f5a09953e372109062a920523a hub_soiree
a539255d1e550d699fa0444502f698555b1444e1 hub_soiree
b5cdfa18382026d3d1b8e191463191c3fcd8a68e hub_soiree
647d5e6a2166ebe0a5701e97510c3c12fa9de136 hub_soiree
103bbea670afeb8abb0eff288907121f408e070a hub_soiree
31fecfd582002caf8189f58563882d084f9a4c74 hub_soiree
067797fe7ab7262f15ed99b1c4d6d6723d76c84f hub_soiree
20b919277f9abcd62f8d160c7db3dd91f4a64947 hub_soiree
1f46ef2337885cc41a0a7f8752cd8f0e25cbb2f5 hub_soiree
b93da27ae2a40f686e14ddfc6eadfe260e98c530 hub_soiree
b064ed3ed8f21fd110897584ff308bf9cd22b006 hub_soiree
e99457afabfd1932313b22588dc03cf48a7b0426 hub_soiree
d609b7468581376b22b713607072239ca3f96c7d hub_soiree
fa6498cc36d01316a1ed2632ff61588f965bac48 hub_soiree
1dda190085107cf1ca58cf1a9992d2c7a45a134d hub_soiree
3ee3636d7551e7b4761ac587d9144494832f8b4d hub_soiree
b49589d7431ac8136df5c7e7f9482cc60e7bf7da hub_soiree
59118d7b3ea67491d0e71b22c1d3a20562ea5a75 hub_soiree
2ed25a99fc9633a57b24f606765a002c329399db hub_soiree
8f1701420bd982ecce069ab8b2485af3e85ac2a2 hub_soiree
0a49d7f46205786320045aca16276513a0539406 hub_soiree
32a36e66da1831be6f681029cca3563259748124 hub_soiree
52c5c033e1f72a39b8a1e525afe59c8374d60e45 hub_soiree
de87ccd903bea265d1a7cbeb942a38ae67dfae4e hub_soiree
6031ffdef2973db72921f433fc08deebdadc87d7 hub_soiree
7ac632474490dc66ce0ce87e586d6ca3af608ea0 hub_soiree
1c82f86042f9fa70f0c86c1040b8d48d1187edc2 hub_soiree
dd2e560a9f25f7f1ec73135a48b5439ac7c53cbe hub_soiree
2b1d9cd70cbf8ae16adb0ee00f6b5ee54d25691e hub_soiree
3b09d7ee7458609ad33cab34d4a050194c4f75f2 hub_soiree
4199fe6737053b84ccd38999892614afc7d8e68e hub_soiree
ccf1d1a90df368baf9be47dfd9aa701d552d2161 hub_soiree
23720b1267935953901a294544b9d207ae4f356f hub_soiree
3c0b92065d5dd96031918c8c2e1b75cd0484b82e hub_soirée
498717b922011b30cdb83f5690f728209e18fd68 hub_soiree
2d2637f00968c1b61d235a4f7eefb5d12fad08ff equipe_runtime
9f525d27a714c002d9e7c41caca5fbe71a071b36 equipe_runtime
```

### Commits main absents de Hub

```text
f5af07280eed17210353956060b52f11c9b68dd8 periode
a5f5d045651f1b6ea989dc5f6a3ac0b0069e2b2d fix renouvellement Stripe offre déléguée hors cadre
cc4b945c98b8720b05c2e3d0777db71896e31337 Merge branch 'develop'
c7de90f1d34dff8c90d3bab7f9fab64fd809c209 Merge branch 'develop'
b3b955174019473019176ca04dc0aeaa060bdc07 Merge branch 'develop'
041a80a096aa94aade458f1d90b882d6c74d41a4 Merge branch 'develop'
cf2df4ec264556aae077b5a3b8db358ab670eb45 Merge branch 'develop'
600440c769b25d4032c7ab7d6468e504a3b2a7ea Merge branch 'develop'
8e55c07709c773b699e03ded070d2000d0220474 Merge branch 'develop'
a770ba4911dbbc4d2ecd65da99d31e2f6a10615d Merge branch 'develop'
b7e7d802536faa2593af6e37dca4a3ea3b35c959 Merge branch 'develop'
321cc5071e673dc913cb2beb9b0ad297c7c4c127 Merge branch 'develop'
04f8c3e96d30676c4b53b2927e21f7c3fb6ae7f3 Merge branch 'develop'
3b4a050e0fd4857645d3690ba37f3f3bd252af35 Merge branch 'develop'
01acf073656efddcabca9b0c12ef959d62cfb5a1 Merge branch 'develop'
de8ea1127885ec41dfb3c8cecb952b318f22b835 Merge branch 'develop'
7b88ecfae9da712b2e1924039bd1b93c26901409 Merge branch 'develop'
86788de1d44e02fd20b5ed7685b0165c94ca0800 Merge branch 'develop'
d83433cef339044fcaadcbe04de44fe43b468216 Merge branch 'develop'
4a565a4f77281c2fe5fcecda7bcae279ecd7aaf1 Merge branch 'develop'
5ac046be60d13aa952e6ad8f4b297ee1078ae71e Merge branch 'develop'
0231191ef01664e61a663ab78c2c0761877e6526 Merge branch 'develop'
a1f1351849070ab6f7bee3ca270648547e621edb Merge branch 'develop'
280af6cb4fc2524ba529bfa3b7132f82b1a39c2d Merge branch 'develop'
ee07cce6602ef5324e511f540f9095ace1c56fc0 Merge branch 'develop'
3588429959846b2195e2cab7dbb0f8affd981091 Merge branch 'develop'
c3880aa9128009c3546cc1318d9ed85677cdf55d Merge branch 'develop'
29bd441c2fb097bf7fa32fc03afa0c569612bb0d Merge branch 'develop'
97b6dbf1d7ee41df5b76f471539c45f7322e0d8f Merge branch 'develop'
9c0c27309eef5fc96a99714ac964b1d90453fd2f Merge branch 'develop'
0ba3c379b2fcc1a0deba34517ead1bdf490ff743 Merge branch 'develop'
30ba8a518588ac1ca009a95d2f56ddeb782133f0 Merge branch 'develop'
2bc2cd9a63d763bbc508b753d03159505a1d9bd8 Merge branch 'develop'
863213a834737fdec9e14ce5c7aa24b62adf4cd0 Merge branch 'develop'
03deab0fc4f8b5de5b2cd23952790aabab561590 Merge branch 'develop'
19708a1d6faaacce0a29ef57faac2bdb90f906be Merge branch 'develop'
5e05c8ea70f4e2b96364a098dd5c42bbd9eeaa11 Merge branch 'develop'
403a4098d11b4380dd40b04ec407003e8539d430 Merge branch 'develop'
9125f087aad33c609006c36308281176ee949e8f Merge branch 'develop'
f17cc7976285f4f28abbdb711603248438c42b74 Merge branch 'develop'
f9d56d0c89bf3fd4a0ebe0a80ee23b4f9fac2ff9 Merge branch 'develop'
f0c965d362c965c20f84c426d6657c2aa9812330 Merge branch 'develop'
db8edd42a7f67e7c28ce757c7ba81833143c1036 Merge branch 'develop'
56fd65ddf5b213b87108caf62ffc8f1a45bdbfff Merge branch 'develop'
3f6aca19e832d6a857aad7768f176339275f81a8 Merge branch 'develop'
211dbc2333041634edd9d5e2386d869c3ec1578e Merge branch 'develop'
5f3c964186fc64901d9f7ef770f56a7c3953f83e Merge branch 'develop'
82759be1a1466e1f6272d0c54b15dc1ec81e3d34 Merge branch 'develop'
127871e0c9c3fd7390606572d1e599622e7b671d Merge branch 'develop'
0a510262915f1976eda47df95b508499eb7c888b Merge branch 'develop'
9b5347801af32d8494af691539e6cbab818d8b24 Merge branch 'develop'
c6ac61791e0fb805245fcb9d0e4f4212676eea39 Merge branch 'develop'
4caa852c736368e2a254c4cbd8d56b02013e42d7 Merge branch 'develop'
9eb1e20b518c73dad17ad09c12e69813201610fd Merge branch 'develop'
8e034044e11006a2894c7eacfdb5a7ac8ef8216e Merge branch 'develop'
20033f226901604e7b5b88bffc1ffbee822d3481 Merge branch 'develop'
7d80f186fae42dcff49495993488b6bb7582da8a Merge branch 'develop'
0a620608af8066c561a1ed9d7dcc22682eaadfb1 Merge branch 'develop'
70ec34708506f65c6ef08e05ea14400dd2ba29dc Merge branch 'develop'
df68884d8986c4185248727c774f6b7974a1dc09 Merge branch 'develop'
9f7d99cf14906f130c06a90acf1d2245714f1348 Merge branch 'develop'
3837ad4f86982fdde6b532270dd32efa615a1407 Merge branch 'develop'
9ff314746e0fc0aa7955d8f1630a5c24d705544d Merge branch 'develop'
49f8f7d94041d035b76c70ca15fd412606362ba5 Merge branch 'develop'
6c2b3a4204241571fbf116d89bfccccef09e1c3e Merge branch 'develop'
84c7a4f27bb0b0ec28d66272fc2e92c2db61d59d Merge branch 'develop'
7a75778d71775171e7aebf3d9119cb2f18130104 Merge branch 'develop'
bb4a72f4286831bb4c79282b99fe2569ef920354 Merge branch 'develop'
c33f0cb6e42b78e79e6cc03ccc8d3cbf219b48ec Merge branch 'develop'
13ae7697ef7e04523c63691b06700004439d9b62 Merge branch 'develop'
ae11523dcb1778bd262fce3585ea68a98b6b4109 Merge branch 'develop'
104cc6c23e6f9445b9c6045f5d5e24b4c91ed429 Merge branch 'develop'
8cd7167791f9b3b153a6f99e5c6390913aa3e3e1 Merge branch 'develop'
2176b9d99dd76a8d2e8e0adde58df56dfcbe3243 Merge branch 'develop'
96706a014298d9cf585e15ae44d243f6e28dab98 Merge branch 'develop'
1954efab9e8769534f6f0c957b68b66084d2136b Merge branch 'develop'
bfca80c42d7efba079a284c8255a6a56f84c6794 Merge branch 'develop'
bd9a8d40569946eebea6d7631ee1977fe133137b Merge branch 'develop'
f4ef05eb0642153329579d1e7dc67329e8b277e5 Merge branch 'develop'
bb5fa2c2dc8b6618421432731dc8844ee62fec73 Merge branch 'develop'
fd72a6de34ceff7a1c40aea0bafa64331bf58c11 Merge branch 'develop'
add056ac53211cf21e1f61e7706b41020b96f1e1 Merge branch 'develop'
8c83f2560e9ed3137f0786d57e8f4995e6ab73f8 Merge branch 'develop'
ca6a0b6d1d748ef50cc1ea2313906a78a748dd89 Merge branch 'develop'
c87fef3e82f192731fbbf606af16ee9db0d4d30f Merge branch 'develop'
0eb1fc11f91cdf33f265bba3cffa9a9de7a8e2db Merge branch 'develop'
aff214d5f06edbdb52ac13826dc02333b9ed7513 Merge branch 'develop'
0f3bb1cd2cbdccb5107baff524897edb9287d633 Merge branch 'develop'
90f9f3582b29f8aaa57349fbee59c91b62a18eb7 Merge branch 'develop'
547560edc38f36b459a6578ff5c600961ef02c77 Merge branch 'develop'
ea883f7860e9fa51e088cbe6b4d6232eac5e56c7 Merge branch 'develop'
1a5a6f17742b9ca9de0dd9d0b5ba94907b62b95c Merge branch 'develop'
b276284a941da91922af3b96040d1b658b5bbc67 Merge branch 'develop'
e1a3d9fedd14b678a233593407a9adeb2c3ed4d4 Merge branch 'develop'
7803ccea55b12363f69daccc923046af8e5c3e15 Merge branch 'develop'
fe6fc12103037f13f7facaa136afd3210f1cb998 Merge branch 'develop'
00ca6323d4b1f3317ede10b5adb73bdfb56c4063 fix pagination de la bibliothèque + controle submit à la création des sessions pour éviter les doublons
```

### Fichiers main...hub_soiree

```text
M	web/.htaccess
M	web/ec/ec.php
A	web/ec/ec_legacy_events_navigation_test.php
A	web/ec/ec_stripe_network_delegated_renewal_contract_test.php
A	web/ec/ec_stripe_subscription_period_contract_test.php
M	web/ec/ec_webhook_stripe_handler.php
A	web/ec/modules/communication/home/ec_home_hub_branding_visual_test.php
M	web/ec/modules/communication/home/ec_home_index.php
A	web/ec/modules/communication/home/ec_home_standard_composition_test.php
M	web/ec/modules/compte/authentification/ec_authentification_script.php
M	web/ec/modules/compte/client/ec_client_script.php
M	web/ec/modules/compte/client/ec_client_view.php
M	web/ec/modules/compte/client_contacts/ec_client_contacts_script.php
M	web/ec/modules/compte/joueurs/ec_joueurs_shared.php
M	web/ec/modules/compte/joueurs/ec_joueurs_view.php
M	web/ec/modules/compte/offres/ec_offres_include_detail.php
M	web/ec/modules/ecommerce/offres/ec_offres_form_step_3.php
M	web/ec/modules/ecommerce/offres/ec_offres_script.php
M	web/ec/modules/jeux/bibliotheque/ec_bibliotheque_lib.php
M	web/ec/modules/jeux/bibliotheque/ec_bibliotheque_list.php
M	web/ec/modules/jeux/bibliotheque/ec_bibliotheque_script.php
M	web/ec/modules/jeux/bibliotheque/ec_bibliotheque_view.php
M	web/ec/modules/jeux/bibliotheque/sources/playlists.php
M	web/ec/modules/tracking/clients_logs/ec_clients_logs_session_cta_ajax.php
M	web/ec/modules/tunnel/start/ec_first_party_helpers.php
M	web/ec/modules/tunnel/start/ec_start_agenda_mode.php
A	web/ec/modules/tunnel/start/ec_start_dashboard_program_helpers.php
A	web/ec/modules/tunnel/start/ec_start_dashboard_program_helpers_test.php
A	web/ec/modules/tunnel/start/ec_start_dashboard_quick_parameters_test.php
M	web/ec/modules/tunnel/start/ec_start_first_party_onboarding.php
A	web/ec/modules/tunnel/start/ec_start_hub_demo_dashboard_test.php
M	web/ec/modules/tunnel/start/ec_start_include_header.php
A	web/ec/modules/tunnel/start/ec_start_legacy_offer_visibility_test.php
A	web/ec/modules/tunnel/start/ec_start_library_hub_add_flow_test.php
A	web/ec/modules/tunnel/start/ec_start_library_hub_membership_helpers.php
A	web/ec/modules/tunnel/start/ec_start_quick_schedule.php
A	web/ec/modules/tunnel/start/ec_start_quick_schedule_ui_test.php
M	web/ec/modules/tunnel/start/ec_start_script.php
A	web/ec/modules/tunnel/start/ec_start_session_theme_renewal_ajax_test.php
M	web/ec/modules/tunnel/start/ec_start_sessions_day.php
A	web/ec/modules/tunnel/start/ec_start_sessions_day_dashboard.php
A	web/ec/modules/tunnel/start/ec_start_sessions_day_dashboard_test.php
A	web/ec/modules/tunnel/start/ec_start_sessions_day_dashboard_v2_style.php
A	web/ec/modules/tunnel/start/ec_start_sessions_day_dashboard_view.php
M	web/ec/modules/tunnel/start/ec_start_sessions_day_event_helpers.php
M	web/ec/modules/tunnel/start/ec_start_sessions_day_event_modal.php
M	web/ec/modules/tunnel/start/ec_start_sessions_day_event_script.php
M	web/ec/modules/tunnel/start/ec_start_sessions_day_helpers.php
A	web/ec/modules/tunnel/start/ec_start_sessions_day_hub_debug.php
A	web/ec/modules/tunnel/start/ec_start_sessions_day_personalization_helpers.php
M	web/ec/modules/tunnel/start/ec_start_sessions_list.php
A	web/ec/modules/tunnel/start/ec_start_sessions_list_agenda_test.php
M	web/ec/modules/tunnel/start/ec_start_sessions_play_classic.php
M	web/ec/modules/tunnel/start/ec_start_sessions_view.php
M	web/ec/modules/tunnel/start/ec_start_step_2_setting.php
M	web/ec/modules/tunnel/start/ec_start_step_4_resume.php
M	web/ec/modules/tunnel/start/ec_start_step_4_resume_batch.php
M	web/ec/modules/widget/ec_widget_client_lieu_sessions_agenda.php
M	web/ec/modules/widget/ec_widget_client_network_affiliate_home.php
M	web/ec/modules/widget/ec_widget_ecommerce_offre_client_bloc.php
M	web/ec/modules/widget/ec_widget_home_first_party_onboarding.php
M	web/ec/modules/widget/ec_widget_jeux_discover_library.php
M	web/ec/modules/widget/ec_widget_jeux_sessions_cta.php
M	web/ec/modules/widget/ec_widget_operation_evenement_agenda.php
```

### Fichiers modifiés parallèlement par main

```text
A	web/ec/ec_stripe_network_delegated_renewal_contract_test.php
A	web/ec/ec_stripe_subscription_period_contract_test.php
M	web/ec/ec_webhook_stripe_handler.php
M	web/ec/modules/compte/offres/ec_offres_include_detail.php
M	web/ec/modules/ecommerce/offres/ec_offres_script.php
M	web/ec/modules/jeux/bibliotheque/ec_bibliotheque_list.php
M	web/ec/modules/widget/ec_widget_ecommerce_offre_client_bloc.php
M	web/ec/modules/widget/ec_widget_jeux_sessions_form_mode_calendrier_V3.php
```

### Delta simulé de livraison depuis main

```text
M	web/.htaccess
M	web/ec/ec.php
A	web/ec/ec_legacy_events_navigation_test.php
A	web/ec/modules/communication/home/ec_home_hub_branding_visual_test.php
M	web/ec/modules/communication/home/ec_home_index.php
A	web/ec/modules/communication/home/ec_home_standard_composition_test.php
M	web/ec/modules/compte/authentification/ec_authentification_script.php
M	web/ec/modules/compte/client/ec_client_script.php
M	web/ec/modules/compte/client/ec_client_view.php
M	web/ec/modules/compte/client_contacts/ec_client_contacts_script.php
M	web/ec/modules/compte/joueurs/ec_joueurs_shared.php
M	web/ec/modules/compte/joueurs/ec_joueurs_view.php
M	web/ec/modules/ecommerce/offres/ec_offres_form_step_3.php
M	web/ec/modules/ecommerce/offres/ec_offres_script.php
M	web/ec/modules/jeux/bibliotheque/ec_bibliotheque_lib.php
M	web/ec/modules/jeux/bibliotheque/ec_bibliotheque_list.php
M	web/ec/modules/jeux/bibliotheque/ec_bibliotheque_script.php
M	web/ec/modules/jeux/bibliotheque/ec_bibliotheque_view.php
M	web/ec/modules/jeux/bibliotheque/sources/playlists.php
M	web/ec/modules/tracking/clients_logs/ec_clients_logs_session_cta_ajax.php
M	web/ec/modules/tunnel/start/ec_first_party_helpers.php
M	web/ec/modules/tunnel/start/ec_start_agenda_mode.php
A	web/ec/modules/tunnel/start/ec_start_dashboard_program_helpers.php
A	web/ec/modules/tunnel/start/ec_start_dashboard_program_helpers_test.php
A	web/ec/modules/tunnel/start/ec_start_dashboard_quick_parameters_test.php
M	web/ec/modules/tunnel/start/ec_start_first_party_onboarding.php
A	web/ec/modules/tunnel/start/ec_start_hub_demo_dashboard_test.php
M	web/ec/modules/tunnel/start/ec_start_include_header.php
A	web/ec/modules/tunnel/start/ec_start_legacy_offer_visibility_test.php
A	web/ec/modules/tunnel/start/ec_start_library_hub_add_flow_test.php
A	web/ec/modules/tunnel/start/ec_start_library_hub_membership_helpers.php
A	web/ec/modules/tunnel/start/ec_start_quick_schedule.php
A	web/ec/modules/tunnel/start/ec_start_quick_schedule_ui_test.php
M	web/ec/modules/tunnel/start/ec_start_script.php
A	web/ec/modules/tunnel/start/ec_start_session_theme_renewal_ajax_test.php
M	web/ec/modules/tunnel/start/ec_start_sessions_day.php
A	web/ec/modules/tunnel/start/ec_start_sessions_day_dashboard.php
A	web/ec/modules/tunnel/start/ec_start_sessions_day_dashboard_test.php
A	web/ec/modules/tunnel/start/ec_start_sessions_day_dashboard_v2_style.php
A	web/ec/modules/tunnel/start/ec_start_sessions_day_dashboard_view.php
M	web/ec/modules/tunnel/start/ec_start_sessions_day_event_helpers.php
M	web/ec/modules/tunnel/start/ec_start_sessions_day_event_modal.php
M	web/ec/modules/tunnel/start/ec_start_sessions_day_event_script.php
M	web/ec/modules/tunnel/start/ec_start_sessions_day_helpers.php
A	web/ec/modules/tunnel/start/ec_start_sessions_day_hub_debug.php
A	web/ec/modules/tunnel/start/ec_start_sessions_day_personalization_helpers.php
M	web/ec/modules/tunnel/start/ec_start_sessions_list.php
A	web/ec/modules/tunnel/start/ec_start_sessions_list_agenda_test.php
M	web/ec/modules/tunnel/start/ec_start_sessions_play_classic.php
M	web/ec/modules/tunnel/start/ec_start_sessions_view.php
M	web/ec/modules/tunnel/start/ec_start_step_2_setting.php
M	web/ec/modules/tunnel/start/ec_start_step_4_resume.php
M	web/ec/modules/tunnel/start/ec_start_step_4_resume_batch.php
M	web/ec/modules/widget/ec_widget_client_lieu_sessions_agenda.php
M	web/ec/modules/widget/ec_widget_client_network_affiliate_home.php
M	web/ec/modules/widget/ec_widget_ecommerce_offre_client_bloc.php
M	web/ec/modules/widget/ec_widget_home_first_party_onboarding.php
M	web/ec/modules/widget/ec_widget_jeux_discover_library.php
M	web/ec/modules/widget/ec_widget_jeux_sessions_cta.php
M	web/ec/modules/widget/ec_widget_operation_evenement_agenda.php
```

## quiz

- Source locale : `/home/romain/Cotton/quiz` ; branche : `hub_soiree` ; main : `3ddc167a6c1132d70d58f38f8fb0b02c0b8a719e` ; hub_soiree : `cabfdb16fe31ed9b34dde5b7832a2d751a838111`.
- Fichiers de travail propres. Aucune opération Git en cours détectée.
- Git : simulation de merge sans conflit.

### Commits Hub absents de main

```text
cabfdb16fe31ed9b34dde5b7832a2d751a838111 hub_soiree
95f30a6dadc417138f2d1d3ac5160b54cadf0b34 hub_soiree
6ade8b3fee68f68c338a04f757f8ba32bb773ea7 hub_soiree
144db16e2fb3cf4b7fe6ac50a9775fff5357eec4 hub_soiree
```

### Commits main absents de Hub

```text
(aucun)
```

### Fichiers main...hub_soiree

```text
M	web/server/actions/audioControl.js
M	web/server/actions/connection.js
M	web/server/actions/envUtils.js
M	web/server/actions/gameplay.js
M	web/server/actions/registration.js
M	web/server/actions/wsHandler.js
M	web/server/messaging.js
M	web/server/restart_serveur.txt
```

### Fichiers modifiés parallèlement par main

```text
(aucun)
```

### Delta simulé de livraison depuis main

```text
M	web/server/actions/audioControl.js
M	web/server/actions/connection.js
M	web/server/actions/envUtils.js
M	web/server/actions/gameplay.js
M	web/server/actions/registration.js
M	web/server/actions/wsHandler.js
M	web/server/messaging.js
M	web/server/restart_serveur.txt
```

## www

- Source locale : `/home/romain/Cotton/www` ; branche : `hub_soiree` ; main : `24704ea08c7e242307861e18f70fa592a2ef40f6` ; hub_soiree : `56b31c84566ea88f3a2a2e6750d96164eaa88ea6`.
- Fichiers de travail propres. Aucune opération Git en cours détectée.
- Git : simulation de merge sans conflit.

### Commits Hub absents de main

```text
56b31c84566ea88f3a2a2e6750d96164eaa88ea6 hub_soiree
a7f570c7eaf1f70982df68fc8b4bd776d827936a periode
5850fe10036842c13dd18011a225ba33bcec87e6 hub_soiree
aafbcfcdb19a39b97cfca8644a972162f1acdbec hub_soiree
e41885659fab1cdd45b380e482edd825ec5a13e6 hub_soiree
0853a0de24c0f40d48d33df7eb1be38754145304 equipe_runtime
bbda913ebaab194c70b24b6e60c3ee361c9e00d7 equipe_runtime
```

### Commits main absents de Hub

```text
24704ea08c7e242307861e18f70fa592a2ef40f6 supp backfill périodes fact offres
962dae18a006d4927d90a8d0f5d8815079f87053 periode
dbaa082439228c225257aa4f7d351ddfebd9fbea Merge branch 'develop'
5bc8c5c861b5c11d5fb8e335c370a1177baf363b Merge branch 'develop'
e3fca9bd89f68763443ba2b5d8bef94a57b4e5ce Merge branch 'develop'
19c88f3a047a4f804ebdf51c7578bb8e43e91663 Merge branch 'develop'
c0ae21274555720b4cfd99ca77de725f2036e2bd Merge branch 'develop'
51838250ac0c9067c8c8bb67e3f6efa4469a7e48 Merge branch 'develop'
e240e63ac3e8fa32fba6199b6e621c172b19fdbd Merge branch 'develop'
ce15a75a1832bc3290277c693586c3ec0f097486 Merge branch 'develop'
ab1a4e7ed14b0062a05b682e7a4938534d9ad573 Merge branch 'develop'
03fe3d2a7b94854df79682bc645ee14f9f1079c0 Merge branch 'develop'
6ae48b940f5bd37dd80d07ed6b5d2260df4b0d96 Merge branch 'develop'
098d19514b73e42dbc4120167c9f7c89b1f337fb Merge branch 'develop'
c9fb2ed5bdc5dc0d515f45731bc9ba88685c84c0 Merge branch 'develop'
76a7610bf469554c33dab8c7824d3e41b5e4a0e2 Merge branch 'develop'
383f1aa699bcbd3fd168fdabf64d521e1b739c2f Merge branch 'develop'
afdefa30b4e8e0868e50e377702c6ae1f70a6063 Merge branch 'develop'
81b4361590a8275988f26157a14b4f527c9e73e9 Merge branch 'develop'
5dd4f3cd6316fa44f636075c55555683deeceb15 Merge branch 'develop'
10d8eaea4e73ff9cfaad0ac6aeb1d5ae9c4b3c3a Merge branch 'develop'
49398d281316c0e02d62106130f55c61a0cc154a Merge branch 'develop'
c6bf22bb2f1d1fa14a7cbb94737ace0e3abe2a4a Merge branch 'develop'
c85d2ca331fa6d0daafcb01c0f6897ed1658c102 Merge branch 'develop'
bc7d44bdfa72138d69cf94508efe0ebf7b7e7a5d Merge branch 'develop'
ec9a34173fabb4aabe0861ea0ab2796b812f3033 Merge branch 'develop'
822740e69a368f2b7742254d13167cd03a15e9ea Merge branch 'develop'
09a750ad5dfeca085c40776e9c66c7a660c3f090 Merge branch 'develop'
afad99e859efeb0e4fd401601f58f78a4624656d Merge branch 'develop'
588de43710bf2083b85138f3f4dbc751e4b612bb Merge branch 'develop'
f0295f7b92f61a9aa08f8ad345a894a05a69af76 Merge branch 'develop'
528827bb3c1b92b1d186df72f8f7abe56527708e Merge branch 'develop'
80f4d368a7b9a2611d48df45f41400e30332138d Merge branch 'develop'
f7336fb8cb841145cf32b165e9c652a978479ea9 Merge branch 'develop'
5039843c65c0bdabf5947e505cb1e723d66b1497 Merge branch 'develop'
4303d4bafe84818165056d6b67aa7563616f090b Merge branch 'develop'
15588839902b099e15bfe428084214e479084f83 Merge branch 'develop'
97802b6a1ad42823bde2dc341f456023291c360f Merge branch 'develop'
d74e7ef5111b6ede686b219f91d2dd1717c8f890 Merge branch 'develop'
c15d029f5e49ca74f10bc268ac49756b13ff8cc1 Merge branch 'develop'
3b3e8d2ba18e1ae449bf3e14a7d827c6ce289436 Merge branch 'develop'
251a3a7300ba4a63c37f49574534d166d880937f Merge branch 'develop'
bcd5d9be9ee8234d551b8152a6bbd96b4737a2ed Merge branch 'develop'
77a742a9169aa6bbb74ca7788c96a3faa83d99e7 Merge branch 'develop'
14ebc8002825e83d2f2f59795872885cd8aaeb6c Merge branch 'develop'
56dc0ef40ac497a03935f5fd032a7c9b6527992c Merge branch 'develop'
44a2f7aeb1097c693d6756bafc6121e5a21dea49 Merge branch 'develop'
4906ca123df2419c60eff11e68d78f428533e36f Merge branch 'develop'
666382ad44daa57b795dd6508362d312817053d9 Merge branch 'develop'
48a9410df94b3f38ce0a05389954b19e5bd8620f Merge branch 'develop'
1cf6539dacc9f2ef608b9b09b7b2cdd5db1a9495 Merge branch 'develop'
ae16e68d8e2e638425b77b22714bf3cad43e0c58 Merge branch 'develop'
1a818cf4dfa780f535bd3ffe85cc52cb065488bd Merge branch 'develop'
66fcf6728e264e58b103a22b396a46c8ebe67610 Merge branch 'develop'
d22d716836f85bb5b18b608b7f4990eed2df65ac Merge branch 'develop'
19555dafe8f3b46eb65c3edc2972436e48e1f051 Merge branch 'develop'
20a2a67ca119a305b11c853322b447e4c5ff4c93 Merge branch 'develop'
e27465b3df2969512e54923274122cb5220f4cd8 Merge branch 'develop'
9be1753d9f8428dbd68f2f5dc88d70f204995bf2 Merge branch 'develop'
1b59bde9623555499cec844ef20997a9f6e4deeb Merge branch 'develop'
83199526a675861ff0d10b657a1c8df12b52efbc Merge branch 'develop'
00690f94af90c7d353789adcf4a3e1e1562e59a5 Merge branch 'develop'
35dc79ed176a284e1e9bed6fe7141f6e4318f1ae Merge branch 'develop'
466ed37b577c4cc57a695c5f0e564d5fc8c70973 Merge branch 'develop'
f86e2962658b55566c8d976e7253d2c52b5536c9 Merge branch 'develop'
562b63543fa334aaede7be6dc4c56cc56d1531b0 Merge branch 'develop'
d1c91ce5c6450859e45b7ecd48c41c523fdbbe5e Merge branch 'develop'
c8504d542b60a60b57c73f04e13854d1dd07f9b0 Merge branch 'develop'
4e2f3afd27d4f2006753e35cbfabc4c72ed5188e Merge branch 'develop'
f4839a08f6aaa08b5e253dbea7aae42509a6dd6a Merge branch 'develop'
2ade596647a92952399b752b030ab8af7226b271 Merge branch 'develop'
f4b9a9b0dbda088ee13fed3bd1e14b2b97127b4a Merge branch 'develop'
b27eb8361f82d71c910e96e184964b6ac5c63c13 Merge branch 'develop'
2b10c92047f26fa258ec953c4eba3b16559dc107 Merge branch 'develop'
9e8a5029271ead05a4f4e7303504d746eff58ae5 Merge branch 'develop'
a0edf40e4ac2b9ace8a8c40cd245aa1e373243ef Merge branch 'develop'
e27cf4c5d6a2ee102d8d42ae60cabadc84b5e4a8 maj serveur
bd4739ffdc2dc67ec02bab47f0b8ac255c63a722 Merge branch 'develop'
dd30e25bfc62473b3c26f5b56894c29fb1f19c1b Merge branch 'develop'
ac724b21b3ecdaf455c610cd5606765952b99f23 Merge branch 'develop'
122b714df953dc27faa2d22b65a01ca1789e5979 Merge branch 'develop'
d26dd291bb93f3bc435d3da75705ccd90494bf01 Merge branch 'develop'
4547b0312a87ac5a7eab685fd796e12e307c4085 Merge branch 'develop'
fe922107c1d3a4ccdbdba643c0f555acd3228068 Merge branch 'develop'
82aa7fcd8d439546cc9d7b8893750ac8a211e923 Merge branch 'develop'
3a9259b2dec19c59dbbc8a6560b7896495661b60 Merge branch 'develop'
f852187bd1b563d107a50246d255cc9064cef097 Merge branch 'develop'
28e46e1565f9b97efbfbcaebdfdeec0e6178d6e9 Merge branch 'develop'
791e881769f6c23066647f9b5dcda877caf60432 Merge branch 'develop'
798a8c351e1cfcd628387c785542fcd87516ef99 Merge branch 'develop'
26448ad0cbf436949244e5758dd6f5410b1a7039 Merge branch 'develop'
117085a00a0aac8a53a40e4a1cd562a020034ae3 séparation cron + lecture données reporting
91b66915ade499f4c72cd552f63290a2965e7ff2 Amélioration chargement reporting
```

### Fichiers main...hub_soiree

```text
M	web/.htaccess
M	web/bo/www/modules/ecommerce/offres_clients/bo_module_view_top.php
M	web/bo/www/modules/ecommerce/offres_clients/bo_offres_clients_functions.php
A	web/bo/www/modules/ecommerce/reseau_contrats/bo_reseau_contract_lifecycle_test.php
M	web/bo/www/modules/ecommerce/reseau_contrats/bo_reseau_contrats_list.php
M	web/bo/www/modules/ecommerce/reseau_contrats/bo_reseau_contrats_script.php
M	web/fo/modules/entites/clients/fr/fo_clients_view_shared.php
M	web/fo/modules/jeux/sessions/fr/fo_sessions_seo.php
M	web/fo/modules/jeux/sessions/fr/fo_sessions_view.php
M	web/fo/modules/operations/evenements/fr/fo_evenements_seo.php
M	web/fo/modules/operations/evenements/fr/fo_evenements_view.php
A	web/fo/modules/operations/hubs/fr/fo_hubs_seo.php
A	web/fo/modules/operations/hubs/fr/fo_hubs_view.php
A	web/fo/modules/operations/hubs/fr/fo_hubs_view_shared.php
```

### Fichiers modifiés parallèlement par main

```text
M	web/bo/www/modules/ecommerce/offres_clients/bo_module_view_top.php
M	web/bo/www/modules/ecommerce/offres_clients/bo_offres_clients_functions.php
A	web/bo/www/modules/ecommerce/reseau_contrats/bo_reseau_contract_lifecycle_test.php
M	web/bo/www/modules/ecommerce/reseau_contrats/bo_reseau_contrats_list.php
M	web/bo/www/modules/ecommerce/reseau_contrats/bo_reseau_contrats_script.php
M	web/bo/www/modules/syntheses/facturation_pivot/bo_facturation_pivot_saas.php
A	web/fo/includes/header/fo_header_main_20260114.php
```

### Delta simulé de livraison depuis main

```text
M	web/.htaccess
M	web/fo/modules/entites/clients/fr/fo_clients_view_shared.php
M	web/fo/modules/jeux/sessions/fr/fo_sessions_seo.php
M	web/fo/modules/jeux/sessions/fr/fo_sessions_view.php
M	web/fo/modules/operations/evenements/fr/fo_evenements_seo.php
M	web/fo/modules/operations/evenements/fr/fo_evenements_view.php
A	web/fo/modules/operations/hubs/fr/fo_hubs_seo.php
A	web/fo/modules/operations/hubs/fr/fo_hubs_view.php
A	web/fo/modules/operations/hubs/fr/fo_hubs_view_shared.php
```

## Suppressions et renommages

Aucun statut D ou R dans les deltas Hub ou les deltas de merge simulés. Les fichiers main-only (dont le cache QR Global, le calendrier V3 Pro et les fichiers WWW) restent présents. Ne pas copier le snapshot complet de hub_soiree sur main : cela pourrait retirer des évolutions main-only. Les écarts directs main↔hub sont aussi fournis dans evidence/<repo>/endpoints.txt.
