# E. Liste exhaustive candidate des fichiers PROD

**AUCUN MERGE EFFECTUÉ — liste non libérée pour déploiement.** Delta main → merge simulé pour sept dépôts ; delta de simulation conflictuelle pour Pro. Les fichiers restent sur hub_soiree dans les repos réels. Les deux fichiers Pro combinant main et Hub doivent être reconstruits depuis le futur merge ; leur empreinte actuelle est celle de Hub seulement. Tous les autres fichiers listés sont identiques à la projection candidate de leur merge.

153 chemins applicatifs recensés, dont deux PNG source optionnels (seul le WebP est référencé directement). Aucune suppression ni renommage. Tests, diagnostics, docs et CLI DEV exclus ; SQL seulement en référence. Les chemins cibles physiques PROD ne sont pas attestés par les pages RAW consultées : **chemin PROD non trouvé** pour chaque dépôt. Le chemin relatif après le dossier web ne permet pas d’inventer la racine physique. Le CSV comporte source absolue, cible, SHA-256, statut et étape.

La colonne Ordre est un ordre de transfert **sous maintenance**, pas une promesse de compatibilité pendant une copie en trafic. Les étapes globales figurent dans le rapport. Les fichiers existants JS/CSS et PHP d’une étape forment un lot ; les markers WS viennent après leurs modules.

| Ordre | Repo | Fichier | Type | Dépend de | Pourquoi |
| ----: | ---- | ------- | ---- | --------- | -------- |
| 1 (étape 2) | global | `web/assets/branding/hubs/cotton-hub-default-logo.png` | Nouveau / image | Répertoire assets Global accessible | Fallback visuel/logo Cotton Hub |
| 2 (étape 2) | global | `web/assets/branding/hubs/cotton-hub-default-visual.jpg` | Nouveau / image | Répertoire assets Global accessible | Fallback visuel/logo Cotton Hub |
| 3 (étape 3) | global | `web/app/modules/jeux/hubs/app_games_hub_player_qr_functions.php` | Nouveau / PHP | Schéma Hub/Quick conforme + données initiales validées | Stockage et commandes QR requis par le helper Hub |
| 4 (étape 3) | global | `web/app/modules/jeux/hubs/app_games_hubs_functions.php` | Nouveau / PHP | app_games_hub_player_qr_functions.php + schéma complet | Autorité Hub, membership, exécutions, routing, Remote, joueurs et stats |
| 5 (étape 3) | global | `web/app/modules/jeux/programmation/app_programming_recommendations_functions.php` | Nouveau / PHP | Schéma Hub/Quick conforme + données initiales validées | SchedulePlan/Quick Schedule, recommandations et idempotence |
| 6 (étape 3) | global | `web/app/modules/entites/clients/app_clients_functions.php` | Modifié / PHP | Schéma Hub/Quick conforme + données initiales validées | Fonctions partagées Hub, sessions, identités, classement ou branding |
| 7 (étape 3) | global | `web/app/modules/entites/joueurs/app_joueurs_functions.php` | Modifié / PHP | Schéma Hub/Quick conforme + données initiales validées | Fonctions partagées Hub, sessions, identités, classement ou branding |
| 8 (étape 3) | global | `web/app/modules/general/branding/app_branding_ajax.php` | Modifié / PHP | Schéma Hub/Quick conforme + données initiales validées | Fonctions partagées Hub, sessions, identités, classement ou branding |
| 9 (étape 3) | global | `web/app/modules/general/branding/app_branding_functions.php` | Modifié / PHP | Schéma Hub/Quick conforme + données initiales validées | Fonctions partagées Hub, sessions, identités, classement ou branding |
| 10 (étape 3) | global | `web/app/modules/jeux/bingo_musical/app_bingo_musical_functions.php` | Modifié / PHP | Schéma Hub/Quick conforme + données initiales validées | Fonctions partagées Hub, sessions, identités, classement ou branding |
| 11 (étape 3) | global | `web/app/modules/jeux/blind_test/app_blind_test_functions.php` | Modifié / PHP | Schéma Hub/Quick conforme + données initiales validées | Fonctions partagées Hub, sessions, identités, classement ou branding |
| 12 (étape 3) | global | `web/app/modules/jeux/cotton_quiz/app_cotton_quiz_functions.php` | Modifié / PHP | Schéma Hub/Quick conforme + données initiales validées | Fonctions partagées Hub, sessions, identités, classement ou branding |
| 13 (étape 3) | global | `web/app/modules/jeux/sessions/app_sessions_functions.php` | Modifié / PHP | Schéma Hub/Quick conforme + données initiales validées | Fonctions partagées Hub, sessions, identités, classement ou branding |
| 14 (étape 3) | global | `web/app/modules/jeux/sessions_branding/app_sessions_branding_functions.php` | Modifié / PHP | Schéma Hub/Quick conforme + données initiales validées | Fonctions partagées Hub, sessions, identités, classement ou branding |
| 15 (étape 3) | global | `web/app/modules/operations/evenements/app_evenements_functions.php` | Modifié / PHP | Schéma Hub/Quick conforme + données initiales validées | Fonctions partagées Hub, sessions, identités, classement ou branding |
| 16 (étape 3) | global | `web/global_ajax.php` | Modifié / PHP | Tous les helpers Global nouveaux/modifiés de cette liste | Charge et expose les nouveaux helpers ; à remplacer après leurs dépendances |
| 17 (étape 3) | global | `web/global_librairies.php` | Modifié / PHP | Tous les helpers Global nouveaux/modifiés de cette liste | Charge et expose les nouveaux helpers ; à remplacer après leurs dépendances |
| 18 (étape 4) | games | `web/includes/canvas/images/hub/podium-evening-3w-normalized.png` | Nouveau / image | Répertoire assets Games | Illustration podium Hub ; variante source non appelée directement, optionnelle |
| 19 (étape 4) | games | `web/includes/canvas/images/hub/podium-evening-3w-source.png` | Nouveau / image | Répertoire assets Games | Illustration podium Hub ; variante source non appelée directement, optionnelle |
| 20 (étape 4) | games | `web/includes/canvas/images/hub/podium-evening-3w.webp` | Nouveau / image | Répertoire assets Games | Illustration podium Hub utilisée par le renderer |
| 21 (étape 4) | games | `web/includes/canvas/php/session_options_form.php` | Nouveau / PHP | Global étape 3 ; sous-modules Games du même lot | Partial requis par boot_lib.php et app_hub_view_helpers.php |
| 22 (étape 4) | games | `web/includes/canvas/core/hub_player_qr.js` | Nouveau / JS | Global étape 3 ; sous-modules Games du même lot | Module/asset navigateur ; requis avant publication des templates/import maps |
| 23 (étape 4) | games | `web/includes/canvas/core/hub_runtime_authority.js` | Nouveau / JS | Global étape 3 ; sous-modules Games du même lot | Module/asset navigateur ; requis avant publication des templates/import maps |
| 24 (étape 4) | games | `web/includes/canvas/core/hub_transition.js` | Nouveau / JS | Global étape 3 ; sous-modules Games du même lot | Module/asset navigateur ; requis avant publication des templates/import maps |
| 25 (étape 4) | games | `web/includes/canvas/core/launch_confirmation.js` | Nouveau / JS | Global étape 3 ; sous-modules Games du même lot | Module/asset navigateur ; requis avant publication des templates/import maps |
| 26 (étape 4) | games | `web/includes/canvas/css/hub_launch_confirmation.css` | Nouveau / CSS | Global étape 3 ; sous-modules Games du même lot | Module/asset navigateur ; requis avant publication des templates/import maps |
| 27 (étape 4) | games | `web/includes/canvas/core/api/api_client.js` | Modifié / JS | Global étape 3 ; sous-modules Games du même lot | Module/asset navigateur ; requis avant publication des templates/import maps |
| 28 (étape 4) | games | `web/includes/canvas/core/api_provider.js` | Modifié / JS | Global étape 3 ; sous-modules Games du même lot | Module/asset navigateur ; requis avant publication des templates/import maps |
| 29 (étape 4) | games | `web/includes/canvas/core/boot_organizer.js` | Modifié / JS | Global étape 3 ; sous-modules Games du même lot | Module/asset navigateur ; requis avant publication des templates/import maps |
| 30 (étape 4) | games | `web/includes/canvas/core/canvas_display.js` | Modifié / JS | Global étape 3 ; sous-modules Games du même lot | Module/asset navigateur ; requis avant publication des templates/import maps |
| 31 (étape 4) | games | `web/includes/canvas/core/end_game.js` | Modifié / JS | Global étape 3 ; sous-modules Games du même lot | Module/asset navigateur ; requis avant publication des templates/import maps |
| 32 (étape 4) | games | `web/includes/canvas/core/games/bingo_ui.js` | Modifié / JS | Global étape 3 ; sous-modules Games du même lot | Module/asset navigateur ; requis avant publication des templates/import maps |
| 33 (étape 4) | games | `web/includes/canvas/core/logger.global.js` | Modifié / JS | Global étape 3 ; sous-modules Games du même lot | Module/asset navigateur ; requis avant publication des templates/import maps |
| 34 (étape 4) | games | `web/includes/canvas/core/prelaunch_check.js` | Modifié / JS | Global étape 3 ; sous-modules Games du même lot | Module/asset navigateur ; requis avant publication des templates/import maps |
| 35 (étape 4) | games | `web/includes/canvas/core/qrcode-svg.js` | Modifié / JS | Global étape 3 ; sous-modules Games du même lot | Module/asset navigateur ; requis avant publication des templates/import maps |
| 36 (étape 4) | games | `web/includes/canvas/core/score_store.js` | Modifié / JS | Global étape 3 ; sous-modules Games du même lot | Module/asset navigateur ; requis avant publication des templates/import maps |
| 37 (étape 4) | games | `web/includes/canvas/core/session_modals.js` | Modifié / JS | Global étape 3 ; sous-modules Games du même lot | Module/asset navigateur ; requis avant publication des templates/import maps |
| 38 (étape 4) | games | `web/includes/canvas/core/session_sync.js` | Modifié / JS | Global étape 3 ; sous-modules Games du même lot | Module/asset navigateur ; requis avant publication des templates/import maps |
| 39 (étape 4) | games | `web/includes/canvas/core/ws_connector.js` | Modifié / JS | Global étape 3 ; sous-modules Games du même lot | Module/asset navigateur ; requis avant publication des templates/import maps |
| 40 (étape 4) | games | `web/includes/canvas/core/ws_effects.js` | Modifié / JS | Global étape 3 ; sous-modules Games du même lot | Module/asset navigateur ; requis avant publication des templates/import maps |
| 41 (étape 4) | games | `web/includes/canvas/css/canvas_styles.css` | Modifié / CSS | Global étape 3 ; sous-modules Games du même lot | Module/asset navigateur ; requis avant publication des templates/import maps |
| 42 (étape 4) | games | `web/includes/canvas/css/player_styles.css` | Modifié / CSS | Global étape 3 ; sous-modules Games du même lot | Module/asset navigateur ; requis avant publication des templates/import maps |
| 43 (étape 4) | games | `web/includes/canvas/css/remote_styles.css` | Modifié / CSS | Global étape 3 ; sous-modules Games du même lot | Module/asset navigateur ; requis avant publication des templates/import maps |
| 44 (étape 4) | games | `web/includes/canvas/play/play-ui.js` | Modifié / JS | Global étape 3 ; sous-modules Games du même lot | Module/asset navigateur ; requis avant publication des templates/import maps |
| 45 (étape 4) | games | `web/includes/canvas/play/play-ws.js` | Modifié / JS | Global étape 3 ; sous-modules Games du même lot | Module/asset navigateur ; requis avant publication des templates/import maps |
| 46 (étape 4) | games | `web/includes/canvas/play/register.js` | Modifié / JS | Global étape 3 ; sous-modules Games du même lot | Module/asset navigateur ; requis avant publication des templates/import maps |
| 47 (étape 4) | games | `web/includes/canvas/remote/remote-ui.js` | Modifié / JS | Global étape 3 ; sous-modules Games du même lot | Module/asset navigateur ; requis avant publication des templates/import maps |
| 48 (étape 4) | games | `web/includes/canvas/remote/remote-ws.js` | Modifié / JS | Global étape 3 ; sous-modules Games du même lot | Module/asset navigateur ; requis avant publication des templates/import maps |
| 49 (étape 4) | games | `web/includes/canvas/php/bingo_adapter_glue.php` | Modifié / PHP | Global étape 3 ; sous-modules Games du même lot | Contrat Canvas/Hub partagé Master, Remote et Player |
| 50 (étape 4) | games | `web/includes/canvas/php/blindtest_adapter_glue.php` | Modifié / PHP | Global étape 3 ; sous-modules Games du même lot | Contrat Canvas/Hub partagé Master, Remote et Player |
| 51 (étape 4) | games | `web/includes/canvas/php/quiz_adapter_glue.php` | Modifié / PHP | Global étape 3 ; sous-modules Games du même lot | Contrat Canvas/Hub partagé Master, Remote et Player |
| 52 (étape 4) | games | `web/modules/app_orga_ajax.php` | Modifié / PHP | Global étape 3 ; sous-modules Games du même lot | Contrat Canvas/Hub partagé Master, Remote et Player |
| 53 (étape 4) | games | `web/modules/app_play_ajax.php` | Modifié / PHP | Global étape 3 ; sous-modules Games du même lot | Contrat Canvas/Hub partagé Master, Remote et Player |
| 54 (étape 4) | games | `web/modules/app_hub_view_helpers.php` | Nouveau / PHP | Global étape 3 ; sous-modules Games du même lot | Handlers et projections Hub ; après helpers Global et session_options_form.php |
| 55 (étape 4) | games | `web/includes/canvas/php/boot_lib.php` | Modifié / PHP | Global étape 3 ; sous-modules Games du même lot | Callbacks fin/grâce Hub et bridge des runtimes ; après session_options_form.php |
| 56 (étape 4) | games | `web/modules/app_hub_master_ajax.php` | Nouveau / PHP | Global étape 3 ; sous-modules Games du même lot | Handlers et projections Hub ; après helpers Global et session_options_form.php |
| 57 (étape 4) | games | `web/modules/app_hub_play_ajax.php` | Nouveau / PHP | Global étape 3 ; sous-modules Games du même lot | Handlers et projections Hub ; après helpers Global et session_options_form.php |
| 58 (étape 4) | games | `web/modules/app_hub_remote_ajax.php` | Nouveau / PHP | Global étape 3 ; sous-modules Games du même lot | Handlers et projections Hub ; après helpers Global et session_options_form.php |
| 59 (étape 4) | games | `web/games_ajax.php` | Modifié / PHP | Global étape 3 ; sous-modules Games du même lot | Dispatch Hub et bridge authentifié pour les nouveaux callbacks WS |
| 60 (étape 4) | games | `web/organizer_canvas.php` | Modifié / PHP | Global étape 3 ; sous-modules Games du même lot | Bootstrap, import maps, contexte exécution et retours Hub |
| 61 (étape 4) | games | `web/player_canvas.php` | Modifié / PHP | Global étape 3 ; sous-modules Games du même lot | Bootstrap, import maps, contexte exécution et retours Hub |
| 62 (étape 4) | games | `web/remote_canvas.php` | Modifié / PHP | Global étape 3 ; sous-modules Games du même lot | Bootstrap, import maps, contexte exécution et retours Hub |
| 63 (étape 4) | games | `web/.htaccess` | Modifié / routage Nginx | Global étape 3 ; sous-modules Games du même lot | Expose routes Hub et alias Master après installation des handlers |
| 64 (étape 5) | bingo.game | `ws/bingo_phase_progress.js` | Nouveau / JS | Games étape 4 et Global étape 3 ; dépendances Node existantes | Nouveau module requis par les handlers WS |
| 65 (étape 5) | bingo.game | `ws/bingo_quit_guard.js` | Nouveau / JS | Games étape 4 et Global étape 3 ; dépendances Node existantes | Nouveau module requis par les handlers WS |
| 66 (étape 5) | bingo.game | `ws/bingo_terminal_delivery.js` | Nouveau / JS | Games étape 4 et Global étape 3 ; dépendances Node existantes | Nouveau module requis par les handlers WS |
| 67 (étape 5) | bingo.game | `ws/bingo_server.js` | Modifié / JS | Games étape 4 et Global étape 3 ; dépendances Node existantes | Fin persistée, retour Hub, grâce/reconnexion et pilotage papier |
| 68 (étape 5) | bingo.game | `ws/envUtils.js` | Modifié / JS | Games étape 4 et Global étape 3 ; dépendances Node existantes | Fin persistée, retour Hub, grâce/reconnexion et pilotage papier |
| 69 (étape 5) | bingo.game | `version.txt` | Modifié / marker WS | Games étape 4 et Global étape 3 ; dépendances Node existantes | Marker de restart à transférer en dernier, puis redémarrage contrôlé du service |
| 70 (étape 5) | blindtest | `web/server/actions/teams.js` | Nouveau / JS | Games étape 4 et Global étape 3 ; dépendances Node existantes | Nouveau module requis par les handlers WS |
| 71 (étape 5) | blindtest | `web/server/features.js` | Nouveau / JS | Games étape 4 et Global étape 3 ; dépendances Node existantes | Nouveau module requis par les handlers WS ; BLINDTEST_TEAMS_ENABLED=false |
| 72 (étape 5) | blindtest | `web/server/actions/audioControl.js` | Modifié / JS | Games étape 4 et Global étape 3 ; dépendances Node existantes | Fin persistée, retour Hub, grâce/reconnexion et pilotage papier |
| 73 (étape 5) | blindtest | `web/server/actions/connection.js` | Modifié / JS | Games étape 4 et Global étape 3 ; dépendances Node existantes | Fin persistée, retour Hub, grâce/reconnexion et pilotage papier |
| 74 (étape 5) | blindtest | `web/server/actions/envUtils.js` | Modifié / JS | Games étape 4 et Global étape 3 ; dépendances Node existantes | Fin persistée, retour Hub, grâce/reconnexion et pilotage papier |
| 75 (étape 5) | blindtest | `web/server/actions/gameplay.js` | Modifié / JS | Games étape 4 et Global étape 3 ; dépendances Node existantes | Fin persistée, retour Hub, grâce/reconnexion et pilotage papier |
| 76 (étape 5) | blindtest | `web/server/actions/registration.js` | Modifié / JS | Games étape 4 et Global étape 3 ; dépendances Node existantes | Fin persistée, retour Hub, grâce/reconnexion et pilotage papier |
| 77 (étape 5) | blindtest | `web/server/actions/wsHandler.js` | Modifié / JS | Games étape 4 et Global étape 3 ; dépendances Node existantes | Fin persistée, retour Hub, grâce/reconnexion et pilotage papier |
| 78 (étape 5) | blindtest | `web/server/messaging.js` | Modifié / JS | Games étape 4 et Global étape 3 ; dépendances Node existantes | Fin persistée, retour Hub, grâce/reconnexion et pilotage papier |
| 79 (étape 5) | blindtest | `web/server/restart_serveur.txt` | Modifié / marker WS | Games étape 4 et Global étape 3 ; dépendances Node existantes | Marker de restart à transférer en dernier, puis redémarrage contrôlé du service |
| 80 (étape 5) | quiz | `web/server/actions/audioControl.js` | Modifié / JS | Games étape 4 et Global étape 3 ; dépendances Node existantes | Fin persistée, retour Hub, grâce/reconnexion et pilotage papier |
| 81 (étape 5) | quiz | `web/server/actions/connection.js` | Modifié / JS | Games étape 4 et Global étape 3 ; dépendances Node existantes | Fin persistée, retour Hub, grâce/reconnexion et pilotage papier |
| 82 (étape 5) | quiz | `web/server/actions/envUtils.js` | Modifié / JS | Games étape 4 et Global étape 3 ; dépendances Node existantes | Fin persistée, retour Hub, grâce/reconnexion et pilotage papier |
| 83 (étape 5) | quiz | `web/server/actions/gameplay.js` | Modifié / JS | Games étape 4 et Global étape 3 ; dépendances Node existantes | Fin persistée, retour Hub, grâce/reconnexion et pilotage papier |
| 84 (étape 5) | quiz | `web/server/actions/registration.js` | Modifié / JS | Games étape 4 et Global étape 3 ; dépendances Node existantes | Fin persistée, retour Hub, grâce/reconnexion et pilotage papier |
| 85 (étape 5) | quiz | `web/server/actions/wsHandler.js` | Modifié / JS | Games étape 4 et Global étape 3 ; dépendances Node existantes | Fin persistée, retour Hub, grâce/reconnexion et pilotage papier |
| 86 (étape 5) | quiz | `web/server/messaging.js` | Modifié / JS | Games étape 4 et Global étape 3 ; dépendances Node existantes | Fin persistée, retour Hub, grâce/reconnexion et pilotage papier |
| 87 (étape 5) | quiz | `web/server/restart_serveur.txt` | Modifié / marker WS | Games étape 4 et Global étape 3 ; dépendances Node existantes | Marker de restart à transférer en dernier, puis redémarrage contrôlé du service |
| 88 (étape 6) | play | `web/ep/modules/jeux/hubs/ep_hubs_detail.php` | Nouveau / PHP | Global étape 3 + Games étape 4 | Retour authentifié Hub/probable et restitution des classements |
| 89 (étape 6) | play | `web/ep/ep_signin.php` | Modifié / PHP | Global étape 3 + Games étape 4 | Retour authentifié Hub/probable et restitution des classements |
| 90 (étape 6) | play | `web/ep/ep_signup.php` | Modifié / PHP | Global étape 3 + Games étape 4 | Retour authentifié Hub/probable et restitution des classements |
| 91 (étape 6) | play | `web/ep/ep_signup_private.php` | Modifié / PHP | Global étape 3 + Games étape 4 | Retour authentifié Hub/probable et restitution des classements |
| 92 (étape 6) | play | `web/ep/modules/communication/home/ep_home_leaderboards_shared.php` | Modifié / PHP | Global étape 3 + Games étape 4 | Retour authentifié Hub/probable et restitution des classements |
| 93 (étape 6) | play | `web/ep/modules/compte/authentification/ep_authentification_script.php` | Modifié / PHP | Global étape 3 + Games étape 4 | Retour authentifié Hub/probable et restitution des classements |
| 94 (étape 6) | play | `web/ep/modules/compte/joueur/ep_joueur_script.php` | Modifié / PHP | Global étape 3 + Games étape 4 | Retour authentifié Hub/probable et restitution des classements |
| 95 (étape 6) | play | `web/ep/modules/jeux/sessions/ep_sessions_inscription_form.php` | Modifié / PHP | Global étape 3 + Games étape 4 | Retour authentifié Hub/probable et restitution des classements |
| 96 (étape 6) | play | `web/.htaccess` | Modifié / routage Nginx | Global étape 3 + Games étape 4 | Route EP Hub après ep_hubs_detail.php |
| 97 (étape 7) | www | `web/fo/modules/operations/hubs/fr/fo_hubs_seo.php` | Nouveau / PHP | Global étape 3 + Games étape 4 + Play étape 6 | Page publique Hub, relais session/événement ou agrégat lieu |
| 98 (étape 7) | www | `web/fo/modules/operations/hubs/fr/fo_hubs_view.php` | Nouveau / PHP | Global étape 3 + Games étape 4 + Play étape 6 | Page publique Hub, relais session/événement ou agrégat lieu |
| 99 (étape 7) | www | `web/fo/modules/operations/hubs/fr/fo_hubs_view_shared.php` | Nouveau / PHP | Global étape 3 + Games étape 4 + Play étape 6 | Page publique Hub, relais session/événement ou agrégat lieu |
| 100 (étape 7) | www | `web/fo/modules/entites/clients/fr/fo_clients_view_shared.php` | Modifié / PHP | Global étape 3 + Games étape 4 + Play étape 6 | Page publique Hub, relais session/événement ou agrégat lieu |
| 101 (étape 7) | www | `web/fo/modules/jeux/sessions/fr/fo_sessions_seo.php` | Modifié / PHP | Global étape 3 + Games étape 4 + Play étape 6 | Page publique Hub, relais session/événement ou agrégat lieu |
| 102 (étape 7) | www | `web/fo/modules/jeux/sessions/fr/fo_sessions_view.php` | Modifié / PHP | Global étape 3 + Games étape 4 + Play étape 6 | Page publique Hub, relais session/événement ou agrégat lieu |
| 103 (étape 7) | www | `web/fo/modules/operations/evenements/fr/fo_evenements_seo.php` | Modifié / PHP | Global étape 3 + Games étape 4 + Play étape 6 | Page publique Hub, relais session/événement ou agrégat lieu |
| 104 (étape 7) | www | `web/fo/modules/operations/evenements/fr/fo_evenements_view.php` | Modifié / PHP | Global étape 3 + Games étape 4 + Play étape 6 | Page publique Hub, relais session/événement ou agrégat lieu |
| 105 (étape 7) | www | `web/.htaccess` | Modifié / routage Nginx | Global étape 3 + Games étape 4 + Play étape 6 | Route publique /fr/soirees après nouveaux handlers FO |
| 106 (étape 8) | pro | `web/ec/modules/jeux/bibliotheque/ec_bibliotheque_lib.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Helper/partial requis par les vues et actions Pro |
| 107 (étape 8) | pro | `web/ec/modules/tunnel/start/ec_first_party_helpers.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Helper/partial requis par les vues et actions Pro |
| 108 (étape 8) | pro | `web/ec/modules/tunnel/start/ec_start_dashboard_program_helpers.php` | Nouveau / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Helper/partial requis par les vues et actions Pro |
| 109 (étape 8) | pro | `web/ec/modules/tunnel/start/ec_start_library_hub_membership_helpers.php` | Nouveau / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Helper/partial requis par les vues et actions Pro |
| 110 (étape 8) | pro | `web/ec/modules/tunnel/start/ec_start_sessions_day_dashboard_v2_style.php` | Nouveau / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Helper/partial requis par les vues et actions Pro |
| 111 (étape 8) | pro | `web/ec/modules/tunnel/start/ec_start_sessions_day_event_helpers.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Helper/partial requis par les vues et actions Pro |
| 112 (étape 8) | pro | `web/ec/modules/tunnel/start/ec_start_sessions_day_helpers.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Helper/partial requis par les vues et actions Pro |
| 113 (étape 8) | pro | `web/ec/modules/tunnel/start/ec_start_sessions_day_personalization_helpers.php` | Nouveau / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Helper/partial requis par les vues et actions Pro |
| 114 (étape 8) | pro | `web/ec/modules/tunnel/start/ec_start_quick_schedule.php` | Nouveau / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Dashboard Hub, programmation, branding ou navigation organisateur |
| 115 (étape 8) | pro | `web/ec/modules/tunnel/start/ec_start_sessions_day_dashboard.php` | Nouveau / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Dashboard Hub, programmation, branding ou navigation organisateur |
| 116 (étape 8) | pro | `web/ec/modules/tunnel/start/ec_start_sessions_day_hub_debug.php` | Nouveau / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Dashboard Hub, programmation, branding ou navigation organisateur |
| 117 (étape 8) | pro | `web/ec/modules/communication/home/ec_home_index.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Dashboard Hub, programmation, branding ou navigation organisateur |
| 118 (étape 8) | pro | `web/ec/modules/compte/authentification/ec_authentification_script.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Chargement sûr AI Studio transactionnel ; source serveur à comparer avant publication |
| 119 (étape 8) | pro | `web/ec/modules/compte/client/ec_client_script.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Dashboard Hub, programmation, branding ou navigation organisateur |
| 120 (étape 8) | pro | `web/ec/modules/compte/client/ec_client_view.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Dashboard Hub, programmation, branding ou navigation organisateur |
| 121 (étape 8) | pro | `web/ec/modules/compte/client_contacts/ec_client_contacts_script.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Chargement sûr AI Studio transactionnel ; source serveur à comparer avant publication |
| 122 (étape 8) | pro | `web/ec/modules/compte/joueurs/ec_joueurs_shared.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Dashboard Hub, programmation, branding ou navigation organisateur |
| 123 (étape 8) | pro | `web/ec/modules/compte/joueurs/ec_joueurs_view.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Dashboard Hub, programmation, branding ou navigation organisateur |
| 124 (étape 8) | pro | `web/ec/modules/ecommerce/offres/ec_offres_form_step_3.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Dashboard Hub, programmation, branding ou navigation organisateur |
| 125 (étape 8) | pro | `web/ec/modules/ecommerce/offres/ec_offres_script.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Dashboard Hub, programmation, branding ou navigation organisateur |
| 126 (étape 8) | pro | `web/ec/modules/jeux/bibliotheque/ec_bibliotheque_list.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Dashboard Hub, programmation, branding ou navigation organisateur |
| 127 (étape 8) | pro | `web/ec/modules/jeux/bibliotheque/ec_bibliotheque_script.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Dashboard Hub, programmation, branding ou navigation organisateur |
| 128 (étape 8) | pro | `web/ec/modules/jeux/bibliotheque/ec_bibliotheque_view.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Dashboard Hub, programmation, branding ou navigation organisateur |
| 129 (étape 8) | pro | `web/ec/modules/jeux/bibliotheque/sources/playlists.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Dashboard Hub, programmation, branding ou navigation organisateur |
| 130 (étape 8) | pro | `web/ec/modules/tracking/clients_logs/ec_clients_logs_session_cta_ajax.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Dashboard Hub, programmation, branding ou navigation organisateur |
| 131 (étape 8) | pro | `web/ec/modules/tunnel/start/ec_start_agenda_mode.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Dashboard Hub, programmation, branding ou navigation organisateur |
| 132 (étape 8) | pro | `web/ec/modules/tunnel/start/ec_start_first_party_onboarding.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Dashboard Hub, programmation, branding ou navigation organisateur |
| 133 (étape 8) | pro | `web/ec/modules/tunnel/start/ec_start_include_header.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Dashboard Hub, programmation, branding ou navigation organisateur |
| 134 (étape 8) | pro | `web/ec/modules/tunnel/start/ec_start_sessions_day.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Dashboard Hub, programmation, branding ou navigation organisateur |
| 135 (étape 8) | pro | `web/ec/modules/tunnel/start/ec_start_sessions_day_event_modal.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Dashboard Hub, programmation, branding ou navigation organisateur |
| 136 (étape 8) | pro | `web/ec/modules/tunnel/start/ec_start_sessions_day_event_script.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Dashboard Hub, programmation, branding ou navigation organisateur |
| 137 (étape 8) | pro | `web/ec/modules/tunnel/start/ec_start_sessions_list.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Dashboard Hub, programmation, branding ou navigation organisateur |
| 138 (étape 8) | pro | `web/ec/modules/tunnel/start/ec_start_sessions_play_classic.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Dashboard Hub, programmation, branding ou navigation organisateur |
| 139 (étape 8) | pro | `web/ec/modules/tunnel/start/ec_start_sessions_view.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Dashboard Hub, programmation, branding ou navigation organisateur |
| 140 (étape 8) | pro | `web/ec/modules/tunnel/start/ec_start_step_2_setting.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Dashboard Hub, programmation, branding ou navigation organisateur |
| 141 (étape 8) | pro | `web/ec/modules/tunnel/start/ec_start_step_4_resume.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Dashboard Hub, programmation, branding ou navigation organisateur |
| 142 (étape 8) | pro | `web/ec/modules/tunnel/start/ec_start_step_4_resume_batch.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Dashboard Hub, programmation, branding ou navigation organisateur |
| 143 (étape 8) | pro | `web/ec/modules/widget/ec_widget_client_lieu_sessions_agenda.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Dashboard Hub, programmation, branding ou navigation organisateur |
| 144 (étape 8) | pro | `web/ec/modules/widget/ec_widget_client_network_affiliate_home.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Dashboard Hub, programmation, branding ou navigation organisateur |
| 145 (étape 8) | pro | `web/ec/modules/widget/ec_widget_ecommerce_offre_client_bloc.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Dashboard Hub, programmation, branding ou navigation organisateur |
| 146 (étape 8) | pro | `web/ec/modules/widget/ec_widget_home_first_party_onboarding.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Dashboard Hub, programmation, branding ou navigation organisateur |
| 147 (étape 8) | pro | `web/ec/modules/widget/ec_widget_jeux_discover_library.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Dashboard Hub, programmation, branding ou navigation organisateur |
| 148 (étape 8) | pro | `web/ec/modules/widget/ec_widget_jeux_sessions_cta.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Dashboard Hub, programmation, branding ou navigation organisateur |
| 149 (étape 8) | pro | `web/ec/modules/widget/ec_widget_operation_evenement_agenda.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Dashboard Hub, programmation, branding ou navigation organisateur |
| 150 (étape 8) | pro | `web/ec/modules/tunnel/start/ec_start_script.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Dashboard Hub, programmation, branding ou navigation organisateur |
| 151 (étape 8) | pro | `web/ec/modules/tunnel/start/ec_start_sessions_day_dashboard_view.php` | Nouveau / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Dashboard Hub, programmation, branding ou navigation organisateur |
| 152 (étape 8) | pro | `web/ec/ec.php` | Modifié / PHP | Résolution Pro + Global/Games/WS/Play/WWW validés | Navigation et points d’entrée organisateur après toutes les dépendances Pro |
| 153 (étape 8) | pro | `web/.htaccess` | Modifié / routage Nginx | Résolution Pro + Global/Games/WS/Play/WWW validés | Routage Pro après handlers, dont diagnostic gardé DEV |

## Sources locales et cibles

| Repo | Source locale | Cible PROD |
|---|---|---|
| bingo.game | `/home/romain/Cotton/bingo.game/` + fichier ci-dessus | chemin PROD non trouvé |
| blindtest | `/home/romain/Cotton/blindtest/` + fichier ci-dessus | chemin PROD non trouvé |
| games | `/home/romain/Cotton/games/` + fichier ci-dessus | chemin PROD non trouvé |
| global | `/home/romain/Cotton/global/` + fichier ci-dessus | chemin PROD non trouvé |
| play | `/home/romain/Cotton/play/` + fichier ci-dessus | chemin PROD non trouvé |
| pro | `/home/romain/Cotton/pro/` + fichier ci-dessus | chemin PROD non trouvé |
| quiz | `/home/romain/Cotton/quiz/` + fichier ci-dessus | chemin PROD non trouvé |
| www | `/home/romain/Cotton/www/` + fichier ci-dessus | chemin PROD non trouvé |

## Exclus et références SQL

| Repo | Statut | Fichier | Motif |
|---|---|---|
| bingo.game | A | `ws/tests/bingo_phase_progress.test.js` | Test/diagnostic local ; hors déploiement applicatif |
| bingo.game | A | `ws/tests/bingo_quit_guard.test.js` | Test/diagnostic local ; hors déploiement applicatif |
| bingo.game | A | `ws/tests/bingo_terminal_delivery.test.js` | Test/diagnostic local ; hors déploiement applicatif |
| blindtest | A | `tests/teams-disabled.test.cjs` | Test/diagnostic local ; hors déploiement applicatif |
| games | A | `web/includes/canvas/sql/2026-07-06_blindtest_session_teams.sql` | Migration historique : référence seulement ; couverte/remplacée par le pack schéma séparé |
| games | A | `web/includes/canvas/sql/2026-07-08_games_hubs_players.sql` | Migration historique : référence seulement ; couverte/remplacée par le pack schéma séparé |
| games | A | `web/includes/canvas/sql/2026-07-08_games_hubs_players_sessions.sql` | Migration historique : référence seulement ; couverte/remplacée par le pack schéma séparé |
| games | A | `web/includes/canvas/sql/2026-07-09_games_hubs_active_session_focus.sql` | Migration historique : référence seulement ; couverte/remplacée par le pack schéma séparé |
| games | A | `web/includes/canvas/sql/2026-07-09_games_hubs_players_sessions_access_state.sql` | Migration historique : référence seulement ; couverte/remplacée par le pack schéma séparé |
| games | A | `web/includes/canvas/sql/2026-07-17_games_hubs_prizes_initialization_state.sql` | Migration historique : référence seulement ; couverte/remplacée par le pack schéma séparé |
| games | A | `web/includes/canvas/sql/2026-07-17_games_hubs_publication_prizes.sql` | Migration historique : référence seulement ; couverte/remplacée par le pack schéma séparé |
| games | A | `web/includes/canvas/sql/2026-07-30_games_hubs_players_stats_projection.sql` | Migration historique : référence seulement ; couverte/remplacée par le pack schéma séparé |
| games | A | `web/includes/canvas/sql/2026-07-31_games_hubs_participations_probables.sql` | Migration historique : référence seulement ; couverte/remplacée par le pack schéma séparé |
| games | A | `web/includes/canvas/sql/2026-07-31_games_hubs_players_active_podium_photo.sql` | Migration historique : référence seulement ; couverte/remplacée par le pack schéma séparé |
| games | A | `web/includes/canvas/sql/2026-08-25_games_hubs_presentation_session.sql` | Migration historique : référence seulement ; couverte/remplacée par le pack schéma séparé |
| games | A | `web/tests/bingo_paper_correction_test.mjs` | Test/diagnostic local ; hors déploiement applicatif |
| games | A | `web/tests/bingo_phase_winner_contract_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| games | A | `web/tests/blindtest_teams_disabled_ui_test.mjs` | Test/diagnostic local ; hors déploiement applicatif |
| games | A | `web/tests/blindtest_teams_history_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| games | A | `web/tests/hub_branding_sync_test.mjs` | Test/diagnostic local ; hors déploiement applicatif |
| games | A | `web/tests/hub_branding_sync_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| games | A | `web/tests/hub_compact_aggregate_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| games | A | `web/tests/hub_context_fast_path_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| games | A | `web/tests/hub_demo_player_presentation_test.mjs` | Test/diagnostic local ; hors déploiement applicatif |
| games | A | `web/tests/hub_demo_qr_reentry_contract_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| games | A | `web/tests/hub_demo_readiness_flow_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| games | A | `web/tests/hub_demo_reentry_runtime_test.mjs` | Test/diagnostic local ; hors déploiement applicatif |
| games | A | `web/tests/hub_demo_runtime_surfaces_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| games | A | `web/tests/hub_individual_terminal_master_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| games | A | `web/tests/hub_launch_confirmation_contract_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| games | A | `web/tests/hub_launch_confirmation_test.mjs` | Test/diagnostic local ; hors déploiement applicatif |
| games | A | `web/tests/hub_legacy_entry_routes_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| games | A | `web/tests/hub_legacy_session_prizes_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| games | A | `web/tests/hub_master_renewal_eligibility_model_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| games | A | `web/tests/hub_natural_end_stats_rebuild_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| games | A | `web/tests/hub_paper_historical_session_ensure_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| games | A | `web/tests/hub_photo_replace_test.mjs` | Test/diagnostic local ; hors déploiement applicatif |
| games | A | `web/tests/hub_player_qr_test.mjs` | Test/diagnostic local ; hors déploiement applicatif |
| games | A | `web/tests/hub_presentation_runtime_separation_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| games | A | `web/tests/hub_probable_play_contract_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| games | A | `web/tests/hub_prospect_card_action_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| games | A | `web/tests/hub_remote_contract_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| games | A | `web/tests/hub_remote_master_ux_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| games | A | `web/tests/hub_remote_polling_test.mjs` | Test/diagnostic local ; hors déploiement applicatif |
| games | A | `web/tests/hub_remote_return_execution_test.mjs` | Test/diagnostic local ; hors déploiement applicatif |
| games | A | `web/tests/hub_remote_ws_retry_test.mjs` | Test/diagnostic local ; hors déploiement applicatif |
| games | A | `web/tests/hub_session_settings_dom_test.mjs` | Test/diagnostic local ; hors déploiement applicatif |
| games | A | `web/tests/hub_session_settings_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| games | A | `web/tests/hub_transition_remote_test.mjs` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/client_joueurs_dashboard_aggregate_ranking_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/client_photo_src_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/hub_aggregate_photo_fallback_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/hub_client_routing_canonical_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/hub_delete_service_contract_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/hub_demo_mode_contract_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/hub_ep_return_intent_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/hub_guest_rejoin_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/hub_identity_stability_contract_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/hub_instance_exclusivity_contract_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/hub_legacy_runtime_compatibility_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/hub_operation_branding_cascade_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/hub_paper_cold_runtime_bootstrap_contract_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/hub_participation_counters_contract_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/hub_photo_replace_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/hub_player_qr_continuation_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/hub_player_qr_master_command_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/hub_player_qr_storage_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/hub_player_qr_storage_test.py` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/hub_player_qr_temporal_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/hub_player_roster_registration_state_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/hub_players_stats_projection_contract_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/hub_players_stats_rebuild_cli_env_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/hub_presentation_mode_contract_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/hub_prizes_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/hub_probable_participations_contract_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/hub_publication_prizes_contract_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/hub_remote_control_contract_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/hub_session_membership_dev_diagnostic.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/hub_stats_pending_session_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/hub_terminal_provenance_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/programming_quick_hub_service_contract_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/programming_quick_idempotency_contract_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/programming_quick_recommendation_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/programming_quick_recurrence_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/quiz_auto_history_label_contract_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/schedule_plan_commit_behavior_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/schedule_plan_commit_contract_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/session_results_bingo_membership_contract_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/session_results_podium_contract_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/session_theme_renewal_apply_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/session_theme_renewal_planner_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tests/temporal_window_state_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| global | A | `web/tools/hub_players_stats_rebuild.php` | CLI de reconstruction refuse PROD (PROD_DISABLED) ; outil DEV hors livraison |
| play | A | `web/tests/ep_hub_detail_contract_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| pro | A | `web/ec/ec_legacy_events_navigation_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| pro | A | `web/ec/modules/communication/home/ec_home_hub_branding_visual_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| pro | A | `web/ec/modules/communication/home/ec_home_standard_composition_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| pro | A | `web/ec/modules/tunnel/start/ec_start_dashboard_program_helpers_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| pro | A | `web/ec/modules/tunnel/start/ec_start_dashboard_quick_parameters_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| pro | A | `web/ec/modules/tunnel/start/ec_start_hub_demo_dashboard_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| pro | A | `web/ec/modules/tunnel/start/ec_start_legacy_offer_visibility_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| pro | A | `web/ec/modules/tunnel/start/ec_start_library_hub_add_flow_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| pro | A | `web/ec/modules/tunnel/start/ec_start_quick_schedule_ui_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| pro | A | `web/ec/modules/tunnel/start/ec_start_session_theme_renewal_ajax_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| pro | A | `web/ec/modules/tunnel/start/ec_start_sessions_day_dashboard_test.php` | Test/diagnostic local ; hors déploiement applicatif |
| pro | A | `web/ec/modules/tunnel/start/ec_start_sessions_list_agenda_test.php` | Test/diagnostic local ; hors déploiement applicatif |

## Fichiers déjà alignés, exclus du delta applicatif

Les cinq chemins ecommerce Global et cinq chemins ecommerce WWW modifiés depuis la base commune sont identiques main=Hub et ne sont pas à redéployer pour ce chantier. Même constat pour quatre chemins Pro : les deux tests Stripe, ec_webhook_stripe_handler.php et ec_offres_include_detail.php. Leur liste complète et les deltas bruts sont dans INVENTAIRE.md/evidence.
