# Préparation migration code Hub — 09/09/2026

**Aucun merge/push/déploiement. Liste candidate uniquement.**

- [Rapport A–G](../../notes/hub-prod-code-migration-2026-09-09.md)
- [Inventaire complet branches/commits/fichiers](INVENTAIRE.md)
- [Fichiers PROD ordonnés](FICHIERS-PROD.md)
- [CSV opérateur : chemins absolus et empreintes](FICHIERS-PROD.csv)
- [Manifest machine](manifest.json)
- [Tables/colonnes/index/défauts](DB-ATTENDUS.md)
- [Preuves Git/tests](evidence/)

153 chemins applicatifs dont2 PNG optionnels ;106 exclusions classées. Aucune suppression. Deux sources Pro à reconstruire depuis le merge résolu. Cibles PROD physiques non attestées. Ne pas interpréter les SHA des arbres simulés comme des commits de merge. Voir blocages et ordre de livraison dans le rapport. Dossier local ignoré par Git, à archiver par l’opérateur. Aucun secret/config ni source du backfill copié dans ce dossier.
