-- prod_hb_20260908_v1 / PRECHECK. PREPARATION UNIQUEMENT, AUCUNE AUTORISATION PROD.
-- Importer le fichier ENTIER dans une connexion dediee ; phpMyAdmin doit
-- reconnaitre DELIMITER et BEGIN NOT ATOMIC (MariaDB 10.3).
-- Aucune execution SQL, meme locale, effectuee lors de la preparation.
-- Sources MyISAM : arret operateur de TOUTES les ecritures applicatives/CRON
-- de PRE jusqu'au POST et decision de rollback ; pas de deploiement entre eux.
-- Ne pas utiliser les anciens fichiers10/11/12/13 pour cette phase.
SET NAMES utf8mb4;
SET SESSION time_zone='+00:00';
SET SESSION group_concat_max_len=1048576;
SET @cotton_hub_schema_issues=NULL;
SET @hb_capture_digest=NULL;
DELIMITER $$
BEGIN NOT ATOMIC
 DECLARE hb_lock_acquired INT DEFAULT 0;
 DECLARE EXIT HANDLER FOR SQLEXCEPTION
 BEGIN
  ROLLBACK;
  IF hb_lock_acquired=1 THEN DO RELEASE_LOCK('cotton_prod_hb_20260908_v1'); END IF;
  RESIGNAL;
 END;
 DECLARE EXIT HANDLER FOR SQLWARNING
 BEGIN
  ROLLBACK;
  IF hb_lock_acquired=1 THEN DO RELEASE_LOCK('cotton_prod_hb_20260908_v1'); END IF;
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='SQL_WARNING_ABORTED_INCLUDING_HASH_TRUNCATION';
 END;
WITH
expected_tables(table_name) AS (
SELECT 'games_hubs'
UNION ALL
SELECT 'games_hubs_sessions'
UNION ALL
SELECT 'games_hubs_players'
UNION ALL
SELECT 'games_hubs_participations_probables'
UNION ALL
SELECT 'games_hubs_players_sessions'
UNION ALL
SELECT 'games_hubs_publication'
UNION ALL
SELECT 'games_hubs_prizes'
UNION ALL
SELECT 'games_hubs_remote_access'
UNION ALL
SELECT 'games_hubs_remote_master_presence'
UNION ALL
SELECT 'games_hubs_remote_runtime_presence'
UNION ALL
SELECT 'games_hubs_remote_commands'
UNION ALL
SELECT 'programming_quick_operations'
UNION ALL
SELECT 'programming_quick_series_operations'
),
expected_columns(table_name,column_name,ordinal_position,column_type,is_nullable,column_default,extra,character_set_name,collation_name) AS (
SELECT 'games_hubs', 'id', 1, 'int(10) unsigned', 'NO', NULL, 'auto_increment', NULL, NULL
UNION ALL
SELECT 'games_hubs', 'id_securite', 2, 'varchar(64)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs', 'id_client', 3, 'mediumint(9) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs', 'hub_date', 4, 'date', 'NO', NULL, '', NULL, NULL
UNION ALL
SELECT 'games_hubs', 'context_type', 5, 'varchar(16)', 'NO', '''day''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs', 'id_operation_evenement', 6, 'int(10) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs', 'hub_label', 7, 'varchar(255)', 'YES', 'NULL', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs', 'flag_active', 8, 'tinyint(1) unsigned', 'NO', '1', '', NULL, NULL
UNION ALL
SELECT 'games_hubs', 'hub_status', 9, 'varchar(32)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs', 'active_session_id', 10, 'int(10) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs', 'active_session_activated_at', 11, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs', 'remote_routing_generation', 12, 'bigint(20) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs', 'remote_routing_intent_id', 13, 'varchar(80)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs', 'remote_transition_type', 14, 'varchar(32)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs', 'remote_transition_payload_json', 15, 'text', 'YES', 'NULL', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs', 'remote_transition_started_at', 16, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs', 'presentation_session_id', 17, 'int(10) unsigned', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs', 'presentation_mode', 18, 'varchar(24)', 'NO', '''session''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs', 'presentation_updated_at', 19, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs', 'hub_master_instance_id', 20, 'varchar(80)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs', 'hub_master_instance_seen_at', 21, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs', 'hub_remote_instance_id', 22, 'varchar(80)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs', 'hub_remote_instance_seen_at', 23, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs', 'prizes_initialized_at', 24, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs', 'delete_operation_token', 25, 'varchar(80)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs', 'delete_step', 26, 'varchar(48)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs', 'delete_started_at', 27, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs', 'delete_error_at', 28, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs', 'date_ajout', 29, 'datetime', 'NO', NULL, '', NULL, NULL
UNION ALL
SELECT 'games_hubs', 'date_maj', 30, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs', 'player_qr_display_mode', 31, 'varchar(8)', 'YES', 'NULL', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs', 'player_qr_display_revision', 32, 'bigint(20) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs', 'player_qr_display_confirmation_json', 33, 'text', 'YES', 'NULL', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs', 'player_qr_official_started_at', 34, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_sessions', 'id', 1, 'int(10) unsigned', 'NO', NULL, 'auto_increment', NULL, NULL
UNION ALL
SELECT 'games_hubs_sessions', 'id_hub', 2, 'int(10) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_sessions', 'id_session', 3, 'int(10) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_sessions', 'membership_source', 4, 'varchar(32)', 'NO', '''legacy_reconciled''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_sessions', 'status', 5, 'enum(''active'',''inactive'')', 'NO', '''active''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_sessions', 'created_at', 6, 'datetime', 'NO', NULL, '', NULL, NULL
UNION ALL
SELECT 'games_hubs_sessions', 'updated_at', 7, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_players', 'id', 1, 'int(10) unsigned', 'NO', NULL, 'auto_increment', NULL, NULL
UNION ALL
SELECT 'games_hubs_players', 'id_hub', 2, 'int(10) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_players', 'id_client', 3, 'mediumint(9) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_players', 'id_operation_evenement', 4, 'int(10) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_players', 'hub_token', 5, 'varchar(64)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_players', 'player_token', 6, 'varchar(96)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_players', 'auth_identity_key', 7, 'varchar(128)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_players', 'id_ep_player', 8, 'int(10) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_players', 'auth_type', 9, 'enum(''guest'',''ep'')', 'NO', '''guest''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_players', 'pseudo', 10, 'varchar(80)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_players', 'pseudo_normalized', 11, 'varchar(80)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_players', 'status', 12, 'enum(''active'',''left'')', 'NO', '''active''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_players', 'return_token', 13, 'varchar(64)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_players', 'return_expires_at', 14, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_players', 'created_at', 15, 'datetime', 'NO', NULL, '', NULL, NULL
UNION ALL
SELECT 'games_hubs_players', 'updated_at', 16, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_players', 'last_seen_at', 17, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_players', 'last_ip', 18, 'varchar(45)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_players', 'user_agent_hash', 19, 'char(40)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_players', 'hub_photo_media_id', 20, 'int(10) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_players', 'hub_photo_game_key', 21, 'varchar(32)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_players', 'hub_photo_source', 22, 'varchar(32)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_players', 'hub_photo_updated_at', 23, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_players', 'stats_aggregate_score', 24, 'int(10) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_players', 'stats_wins_count', 25, 'int(10) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_players', 'stats_second_places_count', 26, 'int(10) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_players', 'stats_third_places_count', 27, 'int(10) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_players', 'stats_parties_count', 28, 'int(10) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_players', 'stats_last_result_at', 29, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_players', 'stats_source_revision', 30, 'char(40)', 'YES', 'NULL', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_players', 'stats_computed_at', 31, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_players', 'stats_dirty_at', 32, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_players', 'stats_error', 33, 'varchar(255)', 'YES', 'NULL', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_participations_probables', 'id', 1, 'int(10) unsigned', 'NO', NULL, 'auto_increment', NULL, NULL
UNION ALL
SELECT 'games_hubs_participations_probables', 'id_hub', 2, 'int(10) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_participations_probables', 'id_client', 3, 'mediumint(9) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_participations_probables', 'id_operation_evenement', 4, 'int(10) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_participations_probables', 'hub_token', 5, 'varchar(64)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_participations_probables', 'auth_identity_key', 6, 'varchar(128)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_participations_probables', 'id_ep_player', 7, 'int(10) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_participations_probables', 'source', 8, 'varchar(32)', 'NO', '''hub_play''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_participations_probables', 'status', 9, 'enum(''declared'',''cancelled'',''confirmed'')', 'NO', '''declared''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_participations_probables', 'date_ajout', 10, 'datetime', 'NO', NULL, '', NULL, NULL
UNION ALL
SELECT 'games_hubs_participations_probables', 'date_maj', 11, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_participations_probables', 'declared_at', 12, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_participations_probables', 'cancelled_at', 13, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_participations_probables', 'confirmed_at', 14, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_participations_probables', 'ip', 15, 'varchar(45)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_participations_probables', 'id_user_ajout', 16, 'mediumint(9) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_participations_probables', 'id_user_maj', 17, 'mediumint(9) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_players_sessions', 'id', 1, 'int(10) unsigned', 'NO', NULL, 'auto_increment', NULL, NULL
UNION ALL
SELECT 'games_hubs_players_sessions', 'id_hub', 2, 'int(10) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_players_sessions', 'id_hub_player', 3, 'int(10) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_players_sessions', 'id_session', 4, 'int(10) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_players_sessions', 'session_token', 5, 'varchar(64)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_players_sessions', 'game_type', 6, 'varchar(32)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_players_sessions', 'id_participation', 7, 'int(10) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_players_sessions', 'participant_key', 8, 'varchar(128)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_players_sessions', 'id_ep_player', 9, 'int(10) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_players_sessions', 'status', 10, 'enum(''created'',''active'',''left'',''completed'',''failed'')', 'NO', '''created''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_players_sessions', 'auto_joined_at', 11, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_players_sessions', 'manual_joined_at', 12, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_players_sessions', 'last_joined_at', 13, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_players_sessions', 'left_at', 14, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_players_sessions', 'completed_at', 15, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_players_sessions', 'join_count', 16, 'int(10) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_players_sessions', 'last_action', 17, 'varchar(32)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_players_sessions', 'created_at', 18, 'datetime', 'NO', NULL, '', NULL, NULL
UNION ALL
SELECT 'games_hubs_players_sessions', 'updated_at', 19, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_players_sessions', 'last_error', 20, 'varchar(255)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_publication', 'id', 1, 'int(10) unsigned', 'NO', NULL, 'auto_increment', NULL, NULL
UNION ALL
SELECT 'games_hubs_publication', 'id_hub', 2, 'int(10) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_publication', 'title', 3, 'varchar(150)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_publication', 'tagline', 4, 'varchar(255)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_publication', 'description', 5, 'text', 'YES', 'NULL', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_publication', 'location_name', 6, 'varchar(150)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_publication', 'address', 7, 'varchar(180)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_publication', 'postal_code', 8, 'varchar(20)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_publication', 'city', 9, 'varchar(120)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_publication', 'country', 10, 'varchar(80)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_publication', 'website_url', 11, 'varchar(255)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_publication', 'cta_label', 12, 'varchar(150)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_publication', 'publication_status', 13, 'varchar(32)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_publication', 'date_ajout', 14, 'datetime', 'NO', NULL, '', NULL, NULL
UNION ALL
SELECT 'games_hubs_publication', 'date_maj', 15, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_prizes', 'id', 1, 'int(10) unsigned', 'NO', NULL, 'auto_increment', NULL, NULL
UNION ALL
SELECT 'games_hubs_prizes', 'id_hub', 2, 'int(10) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_prizes', 'rank', 3, 'tinyint(3) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_prizes', 'label', 4, 'varchar(120)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_prizes', 'description', 5, 'varchar(255)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_prizes', 'date_ajout', 6, 'datetime', 'NO', NULL, '', NULL, NULL
UNION ALL
SELECT 'games_hubs_prizes', 'date_maj', 7, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_remote_access', 'id', 1, 'int(10) unsigned', 'NO', NULL, 'auto_increment', NULL, NULL
UNION ALL
SELECT 'games_hubs_remote_access', 'id_hub', 2, 'int(10) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_remote_access', 'id_client', 3, 'mediumint(9) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_remote_access', 'remote_token', 4, 'varchar(96)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_remote_access', 'remote_token_hash', 5, 'char(64)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_remote_access', 'session_token_hash', 6, 'char(64)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_remote_access', 'status', 7, 'enum(''active'',''revoked'')', 'NO', '''active''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_remote_access', 'label', 8, 'varchar(80)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_remote_access', 'created_at', 9, 'datetime', 'NO', NULL, '', NULL, NULL
UNION ALL
SELECT 'games_hubs_remote_access', 'revoked_at', 10, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_remote_access', 'last_seen_at', 11, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_remote_access', 'last_ip', 12, 'varchar(45)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_remote_access', 'user_agent_hash', 13, 'char(40)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_remote_master_presence', 'id', 1, 'int(10) unsigned', 'NO', NULL, 'auto_increment', NULL, NULL
UNION ALL
SELECT 'games_hubs_remote_master_presence', 'id_hub', 2, 'int(10) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_remote_master_presence', 'master_instance_id', 3, 'varchar(80)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_remote_master_presence', 'last_seen_at', 4, 'datetime', 'NO', NULL, '', NULL, NULL
UNION ALL
SELECT 'games_hubs_remote_master_presence', 'last_applied_preparation_revision', 5, 'varchar(64)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_remote_master_presence', 'last_control_revision', 6, 'varchar(64)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_remote_master_presence', 'visibility', 7, 'varchar(16)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_remote_master_presence', 'user_agent_hash', 8, 'char(40)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_remote_master_presence', 'created_at', 9, 'datetime', 'NO', NULL, '', NULL, NULL
UNION ALL
SELECT 'games_hubs_remote_master_presence', 'updated_at', 10, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_remote_runtime_presence', 'id', 1, 'int(10) unsigned', 'NO', NULL, 'auto_increment', NULL, NULL
UNION ALL
SELECT 'games_hubs_remote_runtime_presence', 'id_hub', 2, 'int(10) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_remote_runtime_presence', 'id_session', 3, 'int(10) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_remote_runtime_presence', 'execution_id', 4, 'varchar(80)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_remote_runtime_presence', 'master_instance_id', 5, 'varchar(80)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_remote_runtime_presence', 'last_seen_at', 6, 'datetime', 'NO', NULL, '', NULL, NULL
UNION ALL
SELECT 'games_hubs_remote_runtime_presence', 'visibility', 7, 'varchar(16)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_remote_runtime_presence', 'user_agent_hash', 8, 'char(40)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_remote_runtime_presence', 'created_at', 9, 'datetime', 'NO', NULL, '', NULL, NULL
UNION ALL
SELECT 'games_hubs_remote_runtime_presence', 'updated_at', 10, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_remote_commands', 'id', 1, 'int(10) unsigned', 'NO', NULL, 'auto_increment', NULL, NULL
UNION ALL
SELECT 'games_hubs_remote_commands', 'id_hub', 2, 'int(10) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_remote_commands', 'id_remote_access', 3, 'int(10) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_remote_commands', 'command_type', 4, 'varchar(32)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_remote_commands', 'payload_json', 5, 'text', 'YES', 'NULL', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_remote_commands', 'status', 6, 'enum(''pending'',''claimed'',''processing'',''completed'',''failed'',''expired'',''cancelled'')', 'NO', '''pending''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_remote_commands', 'remote_command_key', 7, 'varchar(96)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_remote_commands', 'created_at', 8, 'datetime', 'NO', NULL, '', NULL, NULL
UNION ALL
SELECT 'games_hubs_remote_commands', 'expires_at', 9, 'datetime', 'NO', NULL, '', NULL, NULL
UNION ALL
SELECT 'games_hubs_remote_commands', 'claimed_by', 10, 'varchar(80)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_remote_commands', 'claimed_at', 11, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_remote_commands', 'completed_at', 12, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'games_hubs_remote_commands', 'result_json', 13, 'text', 'YES', 'NULL', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_remote_commands', 'error_code', 14, 'varchar(64)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'games_hubs_remote_commands', 'date_maj', 15, 'datetime', 'YES', 'NULL', '', NULL, NULL
UNION ALL
SELECT 'programming_quick_operations', 'id', 1, 'int(10) unsigned', 'NO', NULL, 'auto_increment', NULL, NULL
UNION ALL
SELECT 'programming_quick_operations', 'id_client', 2, 'int(10) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'programming_quick_operations', 'idempotency_key', 3, 'varchar(80)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'programming_quick_operations', 'command_hash', 4, 'char(64)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'programming_quick_operations', 'status', 5, 'varchar(24)', 'NO', '''pending''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'programming_quick_operations', 'operation_step', 6, 'varchar(32)', 'NO', '''pending''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'programming_quick_operations', 'session_ids_json', 7, 'text', 'YES', 'NULL', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'programming_quick_operations', 'session_security_ids_json', 8, 'text', 'YES', 'NULL', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'programming_quick_operations', 'hub_id', 9, 'int(10) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'programming_quick_operations', 'dashboard_url', 10, 'varchar(255)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'programming_quick_operations', 'result_json', 11, 'text', 'YES', 'NULL', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'programming_quick_operations', 'error_code', 12, 'varchar(80)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'programming_quick_operations', 'created_at', 13, 'datetime', 'NO', NULL, '', NULL, NULL
UNION ALL
SELECT 'programming_quick_operations', 'updated_at', 14, 'datetime', 'NO', NULL, '', NULL, NULL
UNION ALL
SELECT 'programming_quick_operations', 'expires_at', 15, 'datetime', 'NO', NULL, '', NULL, NULL
UNION ALL
SELECT 'programming_quick_series_operations', 'id', 1, 'int(10) unsigned', 'NO', NULL, 'auto_increment', NULL, NULL
UNION ALL
SELECT 'programming_quick_series_operations', 'id_client', 2, 'int(10) unsigned', 'NO', '0', '', NULL, NULL
UNION ALL
SELECT 'programming_quick_series_operations', 'idempotency_key', 3, 'varchar(80)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'programming_quick_series_operations', 'command_hash', 4, 'char(64)', 'NO', '''''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'programming_quick_series_operations', 'status', 5, 'varchar(24)', 'NO', '''pending''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'programming_quick_series_operations', 'operation_step', 6, 'varchar(32)', 'NO', '''pending''', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'programming_quick_series_operations', 'template_json', 7, 'mediumtext', 'YES', 'NULL', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'programming_quick_series_operations', 'recurrence_json', 8, 'mediumtext', 'YES', 'NULL', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'programming_quick_series_operations', 'occurrences_json', 9, 'mediumtext', 'YES', 'NULL', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'programming_quick_series_operations', 'themes_json', 10, 'mediumtext', 'YES', 'NULL', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'programming_quick_series_operations', 'result_json', 11, 'mediumtext', 'YES', 'NULL', '', 'utf8', 'utf8_general_ci'
UNION ALL
SELECT 'programming_quick_series_operations', 'created_at', 12, 'datetime', 'NO', NULL, '', NULL, NULL
UNION ALL
SELECT 'programming_quick_series_operations', 'updated_at', 13, 'datetime', 'NO', NULL, '', NULL, NULL
UNION ALL
SELECT 'programming_quick_series_operations', 'expires_at', 14, 'datetime', 'NO', NULL, '', NULL, NULL
),
expected_indexes(table_name,index_name,non_unique,seq_in_index,column_name) AS (
SELECT 'games_hubs', 'PRIMARY', 0, 1, 'id'
UNION ALL
SELECT 'games_hubs', 'uniq_games_hubs_token', 0, 1, 'id_securite'
UNION ALL
SELECT 'games_hubs', 'uniq_games_hubs_context', 0, 1, 'id_client'
UNION ALL
SELECT 'games_hubs', 'uniq_games_hubs_context', 0, 2, 'hub_date'
UNION ALL
SELECT 'games_hubs', 'uniq_games_hubs_context', 0, 3, 'context_type'
UNION ALL
SELECT 'games_hubs', 'uniq_games_hubs_context', 0, 4, 'id_operation_evenement'
UNION ALL
SELECT 'games_hubs', 'idx_games_hubs_client_date', 1, 1, 'id_client'
UNION ALL
SELECT 'games_hubs', 'idx_games_hubs_client_date', 1, 2, 'hub_date'
UNION ALL
SELECT 'games_hubs', 'idx_games_hubs_active_session', 1, 1, 'active_session_id'
UNION ALL
SELECT 'games_hubs', 'idx_games_hubs_presentation_session', 1, 1, 'presentation_session_id'
UNION ALL
SELECT 'games_hubs', 'idx_games_hubs_operation', 1, 1, 'id_operation_evenement'
UNION ALL
SELECT 'games_hubs_sessions', 'PRIMARY', 0, 1, 'id'
UNION ALL
SELECT 'games_hubs_sessions', 'uniq_games_hubs_sessions_hub_session', 0, 1, 'id_hub'
UNION ALL
SELECT 'games_hubs_sessions', 'uniq_games_hubs_sessions_hub_session', 0, 2, 'id_session'
UNION ALL
SELECT 'games_hubs_sessions', 'idx_games_hubs_sessions_hub_status', 1, 1, 'id_hub'
UNION ALL
SELECT 'games_hubs_sessions', 'idx_games_hubs_sessions_hub_status', 1, 2, 'status'
UNION ALL
SELECT 'games_hubs_sessions', 'idx_games_hubs_sessions_session', 1, 1, 'id_session'
UNION ALL
SELECT 'games_hubs_players', 'PRIMARY', 0, 1, 'id'
UNION ALL
SELECT 'games_hubs_players', 'uniq_games_hubs_players_identity', 0, 1, 'id_hub'
UNION ALL
SELECT 'games_hubs_players', 'uniq_games_hubs_players_identity', 0, 2, 'auth_identity_key'
UNION ALL
SELECT 'games_hubs_players', 'idx_games_hubs_players_hub_status', 1, 1, 'id_hub'
UNION ALL
SELECT 'games_hubs_players', 'idx_games_hubs_players_hub_status', 1, 2, 'status'
UNION ALL
SELECT 'games_hubs_players', 'idx_games_hubs_players_pseudo', 1, 1, 'id_hub'
UNION ALL
SELECT 'games_hubs_players', 'idx_games_hubs_players_pseudo', 1, 2, 'pseudo_normalized'
UNION ALL
SELECT 'games_hubs_players', 'idx_games_hubs_players_return', 1, 1, 'return_token'
UNION ALL
SELECT 'games_hubs_participations_probables', 'PRIMARY', 0, 1, 'id'
UNION ALL
SELECT 'games_hubs_participations_probables', 'uniq_games_hubs_probables_identity', 0, 1, 'id_hub'
UNION ALL
SELECT 'games_hubs_participations_probables', 'uniq_games_hubs_probables_identity', 0, 2, 'auth_identity_key'
UNION ALL
SELECT 'games_hubs_participations_probables', 'idx_games_hubs_probables_hub_status', 1, 1, 'id_hub'
UNION ALL
SELECT 'games_hubs_participations_probables', 'idx_games_hubs_probables_hub_status', 1, 2, 'status'
UNION ALL
SELECT 'games_hubs_participations_probables', 'idx_games_hubs_probables_ep', 1, 1, 'id_ep_player'
UNION ALL
SELECT 'games_hubs_players_sessions', 'PRIMARY', 0, 1, 'id'
UNION ALL
SELECT 'games_hubs_players_sessions', 'uniq_games_hubs_players_sessions_player_session', 0, 1, 'id_hub_player'
UNION ALL
SELECT 'games_hubs_players_sessions', 'uniq_games_hubs_players_sessions_player_session', 0, 2, 'id_session'
UNION ALL
SELECT 'games_hubs_players_sessions', 'idx_games_hubs_players_sessions_hub_session', 1, 1, 'id_hub'
UNION ALL
SELECT 'games_hubs_players_sessions', 'idx_games_hubs_players_sessions_hub_session', 1, 2, 'id_session'
UNION ALL
SELECT 'games_hubs_players_sessions', 'idx_games_hubs_players_sessions_session', 1, 1, 'id_session'
UNION ALL
SELECT 'games_hubs_players_sessions', 'idx_games_hubs_players_sessions_participant', 1, 1, 'game_type'
UNION ALL
SELECT 'games_hubs_players_sessions', 'idx_games_hubs_players_sessions_participant', 1, 2, 'participant_key'
UNION ALL
SELECT 'games_hubs_publication', 'PRIMARY', 0, 1, 'id'
UNION ALL
SELECT 'games_hubs_publication', 'uniq_games_hubs_publication_hub', 0, 1, 'id_hub'
UNION ALL
SELECT 'games_hubs_prizes', 'PRIMARY', 0, 1, 'id'
UNION ALL
SELECT 'games_hubs_prizes', 'uniq_games_hubs_prizes_hub_rank', 0, 1, 'id_hub'
UNION ALL
SELECT 'games_hubs_prizes', 'uniq_games_hubs_prizes_hub_rank', 0, 2, 'rank'
UNION ALL
SELECT 'games_hubs_prizes', 'idx_games_hubs_prizes_hub', 1, 1, 'id_hub'
UNION ALL
SELECT 'games_hubs_remote_access', 'PRIMARY', 0, 1, 'id'
UNION ALL
SELECT 'games_hubs_remote_access', 'uniq_games_hubs_remote_token_hash', 0, 1, 'remote_token_hash'
UNION ALL
SELECT 'games_hubs_remote_access', 'idx_games_hubs_remote_hub_status', 1, 1, 'id_hub'
UNION ALL
SELECT 'games_hubs_remote_access', 'idx_games_hubs_remote_hub_status', 1, 2, 'status'
UNION ALL
SELECT 'games_hubs_remote_access', 'idx_games_hubs_remote_session_hash', 1, 1, 'session_token_hash'
UNION ALL
SELECT 'games_hubs_remote_master_presence', 'PRIMARY', 0, 1, 'id'
UNION ALL
SELECT 'games_hubs_remote_master_presence', 'uniq_games_hubs_remote_presence_master', 0, 1, 'id_hub'
UNION ALL
SELECT 'games_hubs_remote_master_presence', 'uniq_games_hubs_remote_presence_master', 0, 2, 'master_instance_id'
UNION ALL
SELECT 'games_hubs_remote_master_presence', 'idx_games_hubs_remote_presence_seen', 1, 1, 'id_hub'
UNION ALL
SELECT 'games_hubs_remote_master_presence', 'idx_games_hubs_remote_presence_seen', 1, 2, 'last_seen_at'
UNION ALL
SELECT 'games_hubs_remote_runtime_presence', 'PRIMARY', 0, 1, 'id'
UNION ALL
SELECT 'games_hubs_remote_runtime_presence', 'uniq_games_hubs_remote_runtime_master', 0, 1, 'id_hub'
UNION ALL
SELECT 'games_hubs_remote_runtime_presence', 'uniq_games_hubs_remote_runtime_master', 0, 2, 'id_session'
UNION ALL
SELECT 'games_hubs_remote_runtime_presence', 'uniq_games_hubs_remote_runtime_master', 0, 3, 'execution_id'
UNION ALL
SELECT 'games_hubs_remote_runtime_presence', 'uniq_games_hubs_remote_runtime_master', 0, 4, 'master_instance_id'
UNION ALL
SELECT 'games_hubs_remote_runtime_presence', 'idx_games_hubs_remote_runtime_seen', 1, 1, 'id_hub'
UNION ALL
SELECT 'games_hubs_remote_runtime_presence', 'idx_games_hubs_remote_runtime_seen', 1, 2, 'id_session'
UNION ALL
SELECT 'games_hubs_remote_runtime_presence', 'idx_games_hubs_remote_runtime_seen', 1, 3, 'execution_id'
UNION ALL
SELECT 'games_hubs_remote_runtime_presence', 'idx_games_hubs_remote_runtime_seen', 1, 4, 'last_seen_at'
UNION ALL
SELECT 'games_hubs_remote_commands', 'PRIMARY', 0, 1, 'id'
UNION ALL
SELECT 'games_hubs_remote_commands', 'uniq_games_hubs_remote_command_key', 0, 1, 'id_hub'
UNION ALL
SELECT 'games_hubs_remote_commands', 'uniq_games_hubs_remote_command_key', 0, 2, 'remote_command_key'
UNION ALL
SELECT 'games_hubs_remote_commands', 'idx_games_hubs_remote_commands_pending', 1, 1, 'id_hub'
UNION ALL
SELECT 'games_hubs_remote_commands', 'idx_games_hubs_remote_commands_pending', 1, 2, 'status'
UNION ALL
SELECT 'games_hubs_remote_commands', 'idx_games_hubs_remote_commands_pending', 1, 3, 'expires_at'
UNION ALL
SELECT 'games_hubs_remote_commands', 'idx_games_hubs_remote_commands_pending', 1, 4, 'id'
UNION ALL
SELECT 'games_hubs_remote_commands', 'idx_games_hubs_remote_commands_access', 1, 1, 'id_remote_access'
UNION ALL
SELECT 'games_hubs_remote_commands', 'idx_games_hubs_remote_commands_access', 1, 2, 'created_at'
UNION ALL
SELECT 'programming_quick_operations', 'PRIMARY', 0, 1, 'id'
UNION ALL
SELECT 'programming_quick_operations', 'uniq_programming_quick_client_key', 0, 1, 'id_client'
UNION ALL
SELECT 'programming_quick_operations', 'uniq_programming_quick_client_key', 0, 2, 'idempotency_key'
UNION ALL
SELECT 'programming_quick_operations', 'idx_programming_quick_expires_at', 1, 1, 'expires_at'
UNION ALL
SELECT 'programming_quick_operations', 'idx_programming_quick_client_status', 1, 1, 'id_client'
UNION ALL
SELECT 'programming_quick_operations', 'idx_programming_quick_client_status', 1, 2, 'status'
UNION ALL
SELECT 'programming_quick_series_operations', 'PRIMARY', 0, 1, 'id'
UNION ALL
SELECT 'programming_quick_series_operations', 'uniq_programming_quick_series_client_key', 0, 1, 'id_client'
UNION ALL
SELECT 'programming_quick_series_operations', 'uniq_programming_quick_series_client_key', 0, 2, 'idempotency_key'
UNION ALL
SELECT 'programming_quick_series_operations', 'idx_programming_quick_series_expires_at', 1, 1, 'expires_at'
UNION ALL
SELECT 'programming_quick_series_operations', 'idx_programming_quick_series_client_status', 1, 1, 'id_client'
UNION ALL
SELECT 'programming_quick_series_operations', 'idx_programming_quick_series_client_status', 1, 2, 'status'
),
expected_constraints(table_name,constraint_name,constraint_type) AS (
SELECT 'games_hubs', 'PRIMARY', 'PRIMARY KEY'
UNION ALL
SELECT 'games_hubs', 'uniq_games_hubs_token', 'UNIQUE'
UNION ALL
SELECT 'games_hubs', 'uniq_games_hubs_context', 'UNIQUE'
UNION ALL
SELECT 'games_hubs_sessions', 'PRIMARY', 'PRIMARY KEY'
UNION ALL
SELECT 'games_hubs_sessions', 'uniq_games_hubs_sessions_hub_session', 'UNIQUE'
UNION ALL
SELECT 'games_hubs_players', 'PRIMARY', 'PRIMARY KEY'
UNION ALL
SELECT 'games_hubs_players', 'uniq_games_hubs_players_identity', 'UNIQUE'
UNION ALL
SELECT 'games_hubs_participations_probables', 'PRIMARY', 'PRIMARY KEY'
UNION ALL
SELECT 'games_hubs_participations_probables', 'uniq_games_hubs_probables_identity', 'UNIQUE'
UNION ALL
SELECT 'games_hubs_players_sessions', 'PRIMARY', 'PRIMARY KEY'
UNION ALL
SELECT 'games_hubs_players_sessions', 'uniq_games_hubs_players_sessions_player_session', 'UNIQUE'
UNION ALL
SELECT 'games_hubs_publication', 'PRIMARY', 'PRIMARY KEY'
UNION ALL
SELECT 'games_hubs_publication', 'uniq_games_hubs_publication_hub', 'UNIQUE'
UNION ALL
SELECT 'games_hubs_prizes', 'PRIMARY', 'PRIMARY KEY'
UNION ALL
SELECT 'games_hubs_prizes', 'uniq_games_hubs_prizes_hub_rank', 'UNIQUE'
UNION ALL
SELECT 'games_hubs_remote_access', 'PRIMARY', 'PRIMARY KEY'
UNION ALL
SELECT 'games_hubs_remote_access', 'uniq_games_hubs_remote_token_hash', 'UNIQUE'
UNION ALL
SELECT 'games_hubs_remote_master_presence', 'PRIMARY', 'PRIMARY KEY'
UNION ALL
SELECT 'games_hubs_remote_master_presence', 'uniq_games_hubs_remote_presence_master', 'UNIQUE'
UNION ALL
SELECT 'games_hubs_remote_runtime_presence', 'PRIMARY', 'PRIMARY KEY'
UNION ALL
SELECT 'games_hubs_remote_runtime_presence', 'uniq_games_hubs_remote_runtime_master', 'UNIQUE'
UNION ALL
SELECT 'games_hubs_remote_commands', 'PRIMARY', 'PRIMARY KEY'
UNION ALL
SELECT 'games_hubs_remote_commands', 'uniq_games_hubs_remote_command_key', 'UNIQUE'
UNION ALL
SELECT 'programming_quick_operations', 'PRIMARY', 'PRIMARY KEY'
UNION ALL
SELECT 'programming_quick_operations', 'uniq_programming_quick_client_key', 'UNIQUE'
UNION ALL
SELECT 'programming_quick_series_operations', 'PRIMARY', 'PRIMARY KEY'
UNION ALL
SELECT 'programming_quick_series_operations', 'uniq_programming_quick_series_client_key', 'UNIQUE'
),
actual_tables AS (SELECT * FROM information_schema.TABLES WHERE TABLE_SCHEMA = 'prod_cotton_global_0' AND TABLE_NAME IN (SELECT table_name FROM expected_tables)),
actual_columns AS (SELECT * FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = 'prod_cotton_global_0' AND TABLE_NAME IN (SELECT table_name FROM expected_tables)),
actual_indexes AS (SELECT * FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = 'prod_cotton_global_0' AND TABLE_NAME IN (SELECT table_name FROM expected_tables)),
actual_constraints AS (SELECT * FROM information_schema.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA = 'prod_cotton_global_0' AND TABLE_NAME IN (SELECT table_name FROM expected_tables)),
issues AS (
SELECT e.table_name AS object_name, 'TABLE_ABSENTE_OU_ENGINE_COLLATION_TYPE' AS problem
FROM expected_tables e LEFT JOIN actual_tables a ON a.TABLE_NAME=e.table_name
WHERE a.TABLE_NAME IS NULL OR a.TABLE_TYPE <> 'BASE TABLE' OR a.ENGINE <> 'InnoDB'
   OR REPLACE(a.TABLE_COLLATION,'utf8mb3','utf8') <> 'utf8_general_ci'
UNION ALL
SELECT CONCAT(e.table_name,'.',e.column_name), 'COLONNE_ABSENTE_OU_DEFINITION'
FROM expected_columns e LEFT JOIN actual_columns a ON a.TABLE_NAME=e.table_name AND a.COLUMN_NAME=e.column_name
WHERE a.COLUMN_NAME IS NULL OR a.ORDINAL_POSITION <> e.ordinal_position
   OR NOT (BINARY a.COLUMN_TYPE <=> BINARY e.column_type)
   OR NOT (a.IS_NULLABLE <=> e.is_nullable)
   OR NOT (BINARY a.COLUMN_DEFAULT <=> BINARY e.column_default)
   OR NOT (BINARY a.EXTRA <=> BINARY e.extra)
   OR NOT (REPLACE(a.CHARACTER_SET_NAME,'utf8mb3','utf8') <=> e.character_set_name)
   OR NOT (REPLACE(a.COLLATION_NAME,'utf8mb3','utf8') <=> e.collation_name)
UNION ALL
SELECT CONCAT(a.TABLE_NAME,'.',a.COLUMN_NAME), 'COLONNE_INATTENDUE'
FROM actual_columns a LEFT JOIN expected_columns e ON a.TABLE_NAME=e.table_name AND a.COLUMN_NAME=e.column_name
WHERE e.column_name IS NULL
UNION ALL
SELECT CONCAT(e.table_name,'.',e.index_name,'#',e.seq_in_index), 'INDEX_ABSENT_OU_DEFINITION'
FROM expected_indexes e LEFT JOIN actual_indexes a ON a.TABLE_NAME=e.table_name AND a.INDEX_NAME=e.index_name AND a.SEQ_IN_INDEX=e.seq_in_index
WHERE a.INDEX_NAME IS NULL OR a.NON_UNIQUE<>e.non_unique OR a.COLUMN_NAME<>e.column_name
   OR a.SUB_PART IS NOT NULL OR a.INDEX_TYPE<>'BTREE' OR NOT(a.COLLATION <=> 'A')
UNION ALL
SELECT CONCAT(a.TABLE_NAME,'.',a.INDEX_NAME,'#',a.SEQ_IN_INDEX), 'INDEX_INATTENDU'
FROM actual_indexes a LEFT JOIN expected_indexes e ON a.TABLE_NAME=e.table_name AND a.INDEX_NAME=e.index_name AND a.SEQ_IN_INDEX=e.seq_in_index
WHERE e.index_name IS NULL
UNION ALL
SELECT CONCAT(e.table_name,'.',e.constraint_name), 'CONTRAINTE_ABSENTE_OU_TYPE'
FROM expected_constraints e LEFT JOIN actual_constraints a ON a.TABLE_NAME=e.table_name AND a.CONSTRAINT_NAME=e.constraint_name
WHERE a.CONSTRAINT_NAME IS NULL OR a.CONSTRAINT_TYPE<>e.constraint_type
UNION ALL
SELECT CONCAT(a.TABLE_NAME,'.',a.CONSTRAINT_NAME), 'CONTRAINTE_INATTENDUE'
FROM actual_constraints a LEFT JOIN expected_constraints e ON a.TABLE_NAME=e.table_name AND a.CONSTRAINT_NAME=e.constraint_name
WHERE e.constraint_name IS NULL
UNION ALL
SELECT CONCAT(EVENT_OBJECT_TABLE,'.',TRIGGER_NAME), 'TRIGGER_INATTENDU'
FROM information_schema.TRIGGERS WHERE TRIGGER_SCHEMA = 'prod_cotton_global_0'
UNION ALL
SELECT TABLE_NAME, 'TABLE_HUB_INATTENDUE'
FROM information_schema.TABLES WHERE TABLE_SCHEMA = 'prod_cotton_global_0'
AND LEFT(TABLE_NAME,10)='games_hubs' AND TABLE_NAME NOT IN (SELECT table_name FROM expected_tables)
)
SELECT COUNT(*) INTO @cotton_hub_schema_issues FROM issues;
IF COALESCE(@cotton_hub_schema_issues,1)<>0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='TARGET_SCHEMA_MISMATCH'; END IF;


-- Noms reserves a cette connexion ; connexion neuve apres tout echec.
CREATE TEMPORARY TABLE hb_expected_sessions (
 id_session INT UNSIGNED PRIMARY KEY, logical_hub VARCHAR(100) NOT NULL,
 signature CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL
) ENGINE=InnoDB;
CREATE TEMPORARY TABLE hb_expected_hubs (
 logical_hub VARCHAR(100) PRIMARY KEY, token CHAR(48) CHARACTER SET ascii COLLATE ascii_bin UNIQUE,
 id_client INT UNSIGNED NOT NULL, hub_date DATE NOT NULL, context_type VARCHAR(16) NOT NULL,
 id_operation_evenement INT UNSIGNED NOT NULL,
 UNIQUE (id_client,hub_date,context_type,id_operation_evenement)
) ENGINE=InnoDB;
INSERT INTO hb_expected_sessions VALUES
(29370,CONVERT(0x3536377c323032362d30392d30397c736f697265657c30 USING utf8mb4),CONVERT(0x63373530373136383965623931633365636564343538376437373930336132323161303363616132613834343462623365626133633063643566326234666435 USING utf8mb4)),
(29371,CONVERT(0x3536377c323032362d30392d31367c736f697265657c30 USING utf8mb4),CONVERT(0x64613730653534393332333435366434626165303866313236393065653539366137643835303034646231343962613136636537343164376664353161663031 USING utf8mb4)),
(29622,CONVERT(0x323433367c323032362d30392d32367c6576656e747c363031 USING utf8mb4),CONVERT(0x66613631393035646638313734303533373164303539653033303137656330616566666161356263636532356664333833323065346536633566646434663538 USING utf8mb4)),
(29623,CONVERT(0x323433367c323032362d30392d32367c6576656e747c363031 USING utf8mb4),CONVERT(0x34373439303565366464383838383663616431343830306437393865373034373465343362363035376566356437656638613465366261613630326635326363 USING utf8mb4)),
(29631,CONVERT(0x313935397c323032362d30392d32357c736f697265657c30 USING utf8mb4),CONVERT(0x64343233626434323835656139386334323766353863663639333035633036633936646638613566373934383832316337336266613766356334303665623234 USING utf8mb4)),
(29632,CONVERT(0x313935397c323032362d30392d32357c736f697265657c30 USING utf8mb4),CONVERT(0x31326537386563663164313064343333303363393764363731663662326536353034623033643738663666356632376135396261653136663439663737336439 USING utf8mb4)),
(29643,CONVERT(0x313935387c323032362d30392d32347c736f697265657c30 USING utf8mb4),CONVERT(0x39393039373435633163656431303434353332633662303962633930343534623435326662626230303839653937323831363738363765626237613732633235 USING utf8mb4)),
(29644,CONVERT(0x313935387c323032362d30392d32347c736f697265657c30 USING utf8mb4),CONVERT(0x65316536313862626237613737643239346437666463653464343435626663393338366434373665653365356238663534663434323266376530303034373162 USING utf8mb4)),
(29668,CONVERT(0x3135347c323032362d30392d31307c736f697265657c30 USING utf8mb4),CONVERT(0x66386139306231643865323038663464333661373632616464333438363835353864306163316631303530663831656266373864663438656132336435633338 USING utf8mb4)),
(29669,CONVERT(0x3135347c323032362d30392d31387c736f697265657c30 USING utf8mb4),CONVERT(0x63636266303764663236313632663564376130613833346632613339363437323566306339336535373464376137326666653338616661313831636638643931 USING utf8mb4)),
(29670,CONVERT(0x3135347c323032362d30392d32347c736f697265657c30 USING utf8mb4),CONVERT(0x65633363646661646335653432366235653766613261663837393836393538616565363963393536356236396139653264643138393539393263323366353035 USING utf8mb4)),
(29673,CONVERT(0x3135347c323032362d30392d31317c736f697265657c30 USING utf8mb4),CONVERT(0x36616138623063346362616434343531393263656639363732343436393831326639393231303464386436636332343536313536343861303536646638356162 USING utf8mb4)),
(29674,CONVERT(0x3135347c323032362d30392d32357c736f697265657c30 USING utf8mb4),CONVERT(0x36663763336262346330383839373362633939656433383061653436613030363434383537346436396330663764313333323530626139373135653762386134 USING utf8mb4)),
(29705,CONVERT(0x3537317c323032362d30392d31367c736f697265657c30 USING utf8mb4),CONVERT(0x64373632356232633439323239623139393665323863376531376132396261613838313432333365616637396233356263373730343938353565306238393830 USING utf8mb4)),
(29706,CONVERT(0x3537317c323032362d30392d33307c736f697265657c30 USING utf8mb4),CONVERT(0x33353261373337363238393666343765313563643637333961333830306132636465363439636233653865343630393330643162366533313664316366393937 USING utf8mb4)),
(29756,CONVERT(0x323137307c323032362d30392d31307c736f697265657c30 USING utf8mb4),CONVERT(0x33323933313764613965613062643665663935353735393330653034393565613664323135333139626565383533386562363364373931653862366531343139 USING utf8mb4)),
(29774,CONVERT(0x3832347c323032362d30392d31377c736f697265657c30 USING utf8mb4),CONVERT(0x64393336316339346539323739663938336661623737393937363337393561303435353239333161303338626663316330343533353731386631623762323837 USING utf8mb4)),
(29775,CONVERT(0x3832347c323032362d30392d31377c736f697265657c30 USING utf8mb4),CONVERT(0x34326531663863613362343966386463303835363133643737323337616264313165313438346438363732336363363763346266336336303635313231363430 USING utf8mb4)),
(29827,CONVERT(0x337c323032362d30392d31307c736f697265657c30 USING utf8mb4),CONVERT(0x61343636643137383131376239626430356165653665613663636238383238623862316431346563373763653766353736356136623666373038623530386366 USING utf8mb4)),
(29828,CONVERT(0x337c323032362d30392d31377c736f697265657c30 USING utf8mb4),CONVERT(0x64343764326331363466326131333966613063666338643163316662396432323334613634616332313632326462393962393363653333386334613635316266 USING utf8mb4)),
(29829,CONVERT(0x337c323032362d31302d30317c736f697265657c30 USING utf8mb4),CONVERT(0x65623536663832333936333665306537336532636335343439303864363939316633303835343838353039396630343962396334363737653538383166313337 USING utf8mb4)),
(29830,CONVERT(0x337c323032362d31302d30387c736f697265657c30 USING utf8mb4),CONVERT(0x63666463323739653333353765356336336339383138356334616437666531316339653633326365623039633366386433356464316639343463363761386365 USING utf8mb4)),
(29831,CONVERT(0x337c323032362d31302d31357c736f697265657c30 USING utf8mb4),CONVERT(0x38633932623037623065323761306232353566613838643835363536643439633639343666363939653739623561373865656539343439656364313365303861 USING utf8mb4)),
(29832,CONVERT(0x337c323032362d31302d32327c736f697265657c30 USING utf8mb4),CONVERT(0x36626232646138646563363039613534386564616663396336363836646662373236343533656236383936626130303630353235346133616330666331313862 USING utf8mb4)),
(29833,CONVERT(0x337c323032362d31302d32397c736f697265657c30 USING utf8mb4),CONVERT(0x64633061326431663561386265343366353562636633633231623530643332616361316639363031373634336632656438396537633739653465363665643562 USING utf8mb4)),
(29834,CONVERT(0x337c323032362d31312d30357c736f697265657c30 USING utf8mb4),CONVERT(0x64353466383330616232636162633662393564353435333232376234656634363261616663306365616333366231333330616439656339363335643831633233 USING utf8mb4)),
(29835,CONVERT(0x337c323032362d31312d31327c736f697265657c30 USING utf8mb4),CONVERT(0x61376365643230306561653161326332633734636463623736393830386230633766353363656537623035363836346436326534373239636437303862656335 USING utf8mb4)),
(29836,CONVERT(0x337c323032362d31312d31397c736f697265657c30 USING utf8mb4),CONVERT(0x36376635333936393639366230393637353936366134633639666330663131653564666237633937663831353664366166643534313133316231303161373961 USING utf8mb4)),
(29837,CONVERT(0x337c323032362d31312d32367c736f697265657c30 USING utf8mb4),CONVERT(0x36623334363937393330656633656138353862303931623764383137613433653733326531336561386530306535343633386263656666356631633731366664 USING utf8mb4)),
(29838,CONVERT(0x337c323032362d31322d30337c736f697265657c30 USING utf8mb4),CONVERT(0x30313366356566333439353838353062646133376439383862366338323634376535646661386466636339663335376438353563643535643733616639386633 USING utf8mb4)),
(29839,CONVERT(0x337c323032362d31322d31307c736f697265657c30 USING utf8mb4),CONVERT(0x66313531633738343434316234633939643063613038356333343833363761383737646330346638653566343461626636393362633330316362616230356337 USING utf8mb4)),
(29840,CONVERT(0x337c323032362d31322d31377c736f697265657c30 USING utf8mb4),CONVERT(0x37383236613136646436303338636433343130626638653064613435333933373239386139336134666138393064373136333262646430383434363038363834 USING utf8mb4)),
(29913,CONVERT(0x3934377c323032362d30392d31307c736f697265657c30 USING utf8mb4),CONVERT(0x31613462613236653134393931373334316331313566613037396533323234353835333837383432633464616265353865363532616536303939616238393430 USING utf8mb4)),
(29914,CONVERT(0x3934377c323032362d30392d31377c736f697265657c30 USING utf8mb4),CONVERT(0x39363932386137643565396636633237356263383163373133616638396234353632636535396563343136633538336638383963663231666331323834316231 USING utf8mb4)),
(29915,CONVERT(0x3934377c323032362d30392d32347c736f697265657c30 USING utf8mb4),CONVERT(0x34396430366634653639653463373436363436366265396465623262303938353964626161616563626638333939326633613337616432666261373166326233 USING utf8mb4)),
(29916,CONVERT(0x3934377c323032362d31302d30317c736f697265657c30 USING utf8mb4),CONVERT(0x37363065646362633662623635653132626536386163613734303038313564336161643761626465393230373962343830653162326338623533363334623732 USING utf8mb4)),
(29976,CONVERT(0x3830327c323032362d30392d30397c736f697265657c30 USING utf8mb4),CONVERT(0x66633631643138303633396237643561333665643233313234376537343930613436616563623564323161653233363732666231663735363262323430326534 USING utf8mb4)),
(29978,CONVERT(0x3830327c323032362d30392d31367c736f697265657c30 USING utf8mb4),CONVERT(0x66333733383036326236333936656363353365316363663331616231663330383832646433626434623335643361616238643834313463333935643133306435 USING utf8mb4)),
(29979,CONVERT(0x3830327c323032362d30392d32337c736f697265657c30 USING utf8mb4),CONVERT(0x39363939376433393666666139656638616430343665326430316237333866323361616533363161356331613066656361393963626532373063623831303330 USING utf8mb4)),
(30029,CONVERT(0x323435357c323032362d30392d30397c736f697265657c30 USING utf8mb4),CONVERT(0x63316261353239303739393837623336366337623934343234333830613362363165373664356462376433376565613431343733343335666564333334316266 USING utf8mb4)),
(30030,CONVERT(0x323435357c323032362d30392d30397c736f697265657c30 USING utf8mb4),CONVERT(0x61326639633431383635666633323466336662313662353435623563316561646334333636666232643131333236393435643736333163636234663065613766 USING utf8mb4)),
(30031,CONVERT(0x323435357c323032362d30392d30397c736f697265657c30 USING utf8mb4),CONVERT(0x30393933333134633262393062353662663436336537656461636336616365653061323635666639366339343330376565643931303332323566306438393261 USING utf8mb4)),
(30035,CONVERT(0x323435347c323032362d30392d30397c736f697265657c30 USING utf8mb4),CONVERT(0x30356536653430346634363733306235303464343835366161323937663436626363356430303230643836323462623466306261613061373030616662333831 USING utf8mb4)),
(30036,CONVERT(0x323435347c323032362d30392d30397c736f697265657c30 USING utf8mb4),CONVERT(0x30303037376461363263383764333531616433343163356162346364613539343964626639383334356234653033626430656635393232303934303564633233 USING utf8mb4)),
(30047,CONVERT(0x323433377c323032362d30392d31307c736f697265657c30 USING utf8mb4),CONVERT(0x30613233643334386134346634366131643836656636383235353731633739653132616266386365663730396135376338366633386237633064616131653735 USING utf8mb4)),
(30049,CONVERT(0x323433377c323032362d30392d31307c736f697265657c30 USING utf8mb4),CONVERT(0x32383466386163363738316430643165363762393139326663633532353034346165346266303634666632323165666666646465323836666531636661303238 USING utf8mb4)),
(30053,CONVERT(0x313930397c323032362d30392d31307c736f697265657c30 USING utf8mb4),CONVERT(0x32353838656662643836616639616330343166356663386132353035383333313039636337333531323465343839366632333430316238393538633162626638 USING utf8mb4)),
(30054,CONVERT(0x313930397c323032362d30392d31377c736f697265657c30 USING utf8mb4),CONVERT(0x33613931626233333563396633386636623239396138353831613764303633666366653530633632316536616130363063633566326337323132326131396435 USING utf8mb4)),
(30055,CONVERT(0x313930397c323032362d30392d32347c736f697265657c30 USING utf8mb4),CONVERT(0x62643064356332353461316364626336323836393538613565323665623931653863386435393466656566346462633437373965393837616661313632616434 USING utf8mb4)),
(30056,CONVERT(0x313930397c323032362d31302d30317c736f697265657c30 USING utf8mb4),CONVERT(0x37643330356233383863323339636433653830363262376336653032633439356666666638616639313765616637646361363331653935373231363830633738 USING utf8mb4)),
(30057,CONVERT(0x313930397c323032362d31302d30387c736f697265657c30 USING utf8mb4),CONVERT(0x37303433363464353631343465303865623037633530616233356364643132356463343932326339393536393239326464323939613136303331346438666565 USING utf8mb4)),
(30058,CONVERT(0x313930397c323032362d31302d31357c736f697265657c30 USING utf8mb4),CONVERT(0x62306632316666636635393264383431343632326138343933646366646539343464343062363365376539646562656461313032623065316339623861323266 USING utf8mb4)),
(30059,CONVERT(0x313930397c323032362d31302d32327c736f697265657c30 USING utf8mb4),CONVERT(0x38386661663061383436663664313663346234353265346434633466313838356461666463353936353432343539623036646333613162386630626534396436 USING utf8mb4)),
(30060,CONVERT(0x313930397c323032362d31302d32397c736f697265657c30 USING utf8mb4),CONVERT(0x34393833613437323866656164383235633535633230313037393034363137626536356531626330313265376165616562633163313363383634373838663864 USING utf8mb4)),
(30061,CONVERT(0x313930397c323032362d31312d30357c736f697265657c30 USING utf8mb4),CONVERT(0x38643561653035623866323838656561376465643732303962653038353366306665663961353336353939373465393863303364353034383264376666383834 USING utf8mb4)),
(30062,CONVERT(0x313930397c323032362d31312d31327c736f697265657c30 USING utf8mb4),CONVERT(0x62663436363864303034313939373932356134666639383263303235616166643235383331633137383362316639313936643031323838363932626466303264 USING utf8mb4)),
(30063,CONVERT(0x313930397c323032362d31312d31397c736f697265657c30 USING utf8mb4),CONVERT(0x62303732396236383466313161616537303962306462363064306561373464336231336166623864623665643063303665306564306466633964633538313832 USING utf8mb4)),
(30064,CONVERT(0x313930397c323032362d31312d32367c736f697265657c30 USING utf8mb4),CONVERT(0x36376233653861326533366334653931663961303833643737633432613066393638626232613935343664666439353632623038376632653732326461633634 USING utf8mb4)),
(30065,CONVERT(0x313930397c323032362d31322d30337c736f697265657c30 USING utf8mb4),CONVERT(0x38393839383330356530613839343035393731306436636534323233303234653734616633653966326434373830646561343064326363633165363864353232 USING utf8mb4)),
(30066,CONVERT(0x313930397c323032362d31322d31307c736f697265657c30 USING utf8mb4),CONVERT(0x38383833343162316539616634666433313137643466323366656665636662656265616534633538383466653934316561653739396364656539306331343762 USING utf8mb4)),
(30067,CONVERT(0x313930397c323032362d31322d31377c736f697265657c30 USING utf8mb4),CONVERT(0x66353539336130356639323231613236633231313431643630363436623434383039656662376362633266313437646363366663396163376138316436653636 USING utf8mb4)),
(30068,CONVERT(0x313930397c323032362d31322d32347c736f697265657c30 USING utf8mb4),CONVERT(0x33383962306132626230303161316231623335383435633966636635373733366263623564633830326437633566656138373165383733336536616336656335 USING utf8mb4)),
(30069,CONVERT(0x313930397c323032362d31322d33317c736f697265657c30 USING utf8mb4),CONVERT(0x63366437343539366533616330663638356630333633373066333163636232353163323033353537373666666636626363373031316264306233383137643164 USING utf8mb4)),
(30071,CONVERT(0x3738307c323032362d30392d30397c736f697265657c30 USING utf8mb4),CONVERT(0x63313034383932306566343034346534623530626238666464376238323730633665636364343130326331323333383830633233643333616430396333343563 USING utf8mb4)),
(30121,CONVERT(0x3934307c323032362d30392d30387c736f697265657c30 USING utf8mb4),CONVERT(0x32383561383636663931353239353664376237306464316437346166383636656236366262633431373566386438656465613036303336643337346339643236 USING utf8mb4)),
(30122,CONVERT(0x3934307c323032362d30392d30387c736f697265657c30 USING utf8mb4),CONVERT(0x39653730313336303362633438363630613934633663343564666566343864346662386436316635663035343365656139306639633730303137323537636634 USING utf8mb4)),
(30126,CONVERT(0x323435397c323032362d30392d31327c6576656e747c363138 USING utf8mb4),CONVERT(0x37323334363062653662386439376337346632323632333835373466376536336332333632393738393464643835383237656130616364326266653261383933 USING utf8mb4)),
(30127,CONVERT(0x323435397c323032362d30392d31327c6576656e747c363138 USING utf8mb4),CONVERT(0x39316663643565396662303032326665316530396162626330643361663236613265643766616162386465333361303932363030373933363463653536623565 USING utf8mb4)),
(30139,CONVERT(0x3539357c323032362d30392d30387c736f697265657c30 USING utf8mb4),CONVERT(0x38313765313138623931383237343637346461653266616530653833326239626532366263373261393232393638653166396336366662336130373739616537 USING utf8mb4)),
(30140,CONVERT(0x3539357c323032362d30392d30387c736f697265657c30 USING utf8mb4),CONVERT(0x65313164363965636135303533343437323338633465373139333161633561323330326564303332323638326239626163646434323830346432376462336466 USING utf8mb4));
INSERT INTO hb_expected_hubs VALUES
(CONVERT(0x3135347c323032362d30392d31307c736f697265657c30 USING utf8mb4),CONVERT(0x613432353437626533643837386631623638656339373137373565636631343438636431623630636639643732333938 USING utf8mb4),154,CONVERT(0x323032362d30392d3130 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x3135347c323032362d30392d31317c736f697265657c30 USING utf8mb4),CONVERT(0x313430346335393962376563333138323733653262343937663733356331653763353635613361626566653933323764 USING utf8mb4),154,CONVERT(0x323032362d30392d3131 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x3135347c323032362d30392d31387c736f697265657c30 USING utf8mb4),CONVERT(0x353933633938656436316365373862316566326338326331306165373630396161326365323564393463383936383939 USING utf8mb4),154,CONVERT(0x323032362d30392d3138 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x3135347c323032362d30392d32347c736f697265657c30 USING utf8mb4),CONVERT(0x376166313736663631663465363362393533653663633036386334666435653330346564323433653162343439376633 USING utf8mb4),154,CONVERT(0x323032362d30392d3234 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x3135347c323032362d30392d32357c736f697265657c30 USING utf8mb4),CONVERT(0x396535373462363232313262636636306337373461383235643338383763346631323064613538623036363935316635 USING utf8mb4),154,CONVERT(0x323032362d30392d3235 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x313930397c323032362d30392d31307c736f697265657c30 USING utf8mb4),CONVERT(0x623437393834643664366536333632666334366430656539323935353430306433623164623164343232616536623737 USING utf8mb4),1909,CONVERT(0x323032362d30392d3130 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x313930397c323032362d30392d31377c736f697265657c30 USING utf8mb4),CONVERT(0x643934663264616564616634303035376665326533383363313136343265626263656662323239613232333363643730 USING utf8mb4),1909,CONVERT(0x323032362d30392d3137 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x313930397c323032362d30392d32347c736f697265657c30 USING utf8mb4),CONVERT(0x303232363763353937353932613032663763353965303665356338356461313934313762396230633636333439623832 USING utf8mb4),1909,CONVERT(0x323032362d30392d3234 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x313930397c323032362d31302d30317c736f697265657c30 USING utf8mb4),CONVERT(0x666661366231336265393332303932613537623764626636656539636637623530383961336366353930616466643630 USING utf8mb4),1909,CONVERT(0x323032362d31302d3031 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x313930397c323032362d31302d30387c736f697265657c30 USING utf8mb4),CONVERT(0x303263336533393165666462623733373338636338333765393066303663636462383465383865613866623539646138 USING utf8mb4),1909,CONVERT(0x323032362d31302d3038 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x313930397c323032362d31302d31357c736f697265657c30 USING utf8mb4),CONVERT(0x336231313239333366653233656339373832383931363232626337393132393661353637303161343931386232646461 USING utf8mb4),1909,CONVERT(0x323032362d31302d3135 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x313930397c323032362d31302d32327c736f697265657c30 USING utf8mb4),CONVERT(0x373339383139636132343966633664623064393231643135353161643735663231633363386664363135393939306565 USING utf8mb4),1909,CONVERT(0x323032362d31302d3232 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x313930397c323032362d31302d32397c736f697265657c30 USING utf8mb4),CONVERT(0x656639666233633736626439363836636365376465396639353237663531623136343138626265326361653836643334 USING utf8mb4),1909,CONVERT(0x323032362d31302d3239 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x313930397c323032362d31312d30357c736f697265657c30 USING utf8mb4),CONVERT(0x646531373833656331306130643962353437343134336135346565396238666563313731356239356566343361346366 USING utf8mb4),1909,CONVERT(0x323032362d31312d3035 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x313930397c323032362d31312d31327c736f697265657c30 USING utf8mb4),CONVERT(0x623866623162386361643631376361363538353138346134653863613061653032393239353366663663646261646663 USING utf8mb4),1909,CONVERT(0x323032362d31312d3132 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x313930397c323032362d31312d31397c736f697265657c30 USING utf8mb4),CONVERT(0x323230316538636463373035303239303936646563643631316466386662643532646261393863656631353933323462 USING utf8mb4),1909,CONVERT(0x323032362d31312d3139 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x313930397c323032362d31312d32367c736f697265657c30 USING utf8mb4),CONVERT(0x396264393561393166393533666138383737366439343735303538616232353664363237346533323039363562633537 USING utf8mb4),1909,CONVERT(0x323032362d31312d3236 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x313930397c323032362d31322d30337c736f697265657c30 USING utf8mb4),CONVERT(0x653963353766326639616138363565666639353931613064383139623334363735356239386136353862366166343464 USING utf8mb4),1909,CONVERT(0x323032362d31322d3033 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x313930397c323032362d31322d31307c736f697265657c30 USING utf8mb4),CONVERT(0x376633373839353131376139393839653130343231373866373536666266663134623764616633376637313965613432 USING utf8mb4),1909,CONVERT(0x323032362d31322d3130 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x313930397c323032362d31322d31377c736f697265657c30 USING utf8mb4),CONVERT(0x666165373837313863363765346664323135623461326463633033373236333664663732356231623361613664666164 USING utf8mb4),1909,CONVERT(0x323032362d31322d3137 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x313930397c323032362d31322d32347c736f697265657c30 USING utf8mb4),CONVERT(0x363236376539343365353564663161626138313131623732313663653635636162653136306137313534363437643734 USING utf8mb4),1909,CONVERT(0x323032362d31322d3234 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x313930397c323032362d31322d33317c736f697265657c30 USING utf8mb4),CONVERT(0x653036393639633634623138666632346538313166623734313132303266623862643532343231613635326161353734 USING utf8mb4),1909,CONVERT(0x323032362d31322d3331 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x313935387c323032362d30392d32347c736f697265657c30 USING utf8mb4),CONVERT(0x303635323266363134626131356430396235613832333936616265373361616630396132396537376461663664396265 USING utf8mb4),1958,CONVERT(0x323032362d30392d3234 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x313935397c323032362d30392d32357c736f697265657c30 USING utf8mb4),CONVERT(0x303661626362343463393261303739386130306239363735666336393939636164343938396435383534353634313735 USING utf8mb4),1959,CONVERT(0x323032362d30392d3235 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x323137307c323032362d30392d31307c736f697265657c30 USING utf8mb4),CONVERT(0x346365616436376363376538323539393739383234663561393964373830613263313666383134396662396565343436 USING utf8mb4),2170,CONVERT(0x323032362d30392d3130 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x323433367c323032362d30392d32367c6576656e747c363031 USING utf8mb4),CONVERT(0x653661666634306236303537386265623162353663313565626133376439663961383730313364313833363964663733 USING utf8mb4),2436,CONVERT(0x323032362d30392d3236 USING utf8mb4),CONVERT(0x6576656e74 USING utf8mb4),601),
(CONVERT(0x323433377c323032362d30392d31307c736f697265657c30 USING utf8mb4),CONVERT(0x633063616330306566356330626566306466313766316665353563633138303762616434656262353863303363633731 USING utf8mb4),2437,CONVERT(0x323032362d30392d3130 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x323435347c323032362d30392d30397c736f697265657c30 USING utf8mb4),CONVERT(0x373036636137373932313063656166356334346336373432396430353736333932663139613832306531313466306237 USING utf8mb4),2454,CONVERT(0x323032362d30392d3039 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x323435357c323032362d30392d30397c736f697265657c30 USING utf8mb4),CONVERT(0x633336666161353532653837333939616462373462616161333331343662333362396330633035313532396261653333 USING utf8mb4),2455,CONVERT(0x323032362d30392d3039 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x323435397c323032362d30392d31327c6576656e747c363138 USING utf8mb4),CONVERT(0x393862626665323335666631363466303435323532316134373464636265303330343837393032633437336339663466 USING utf8mb4),2459,CONVERT(0x323032362d30392d3132 USING utf8mb4),CONVERT(0x6576656e74 USING utf8mb4),618),
(CONVERT(0x337c323032362d30392d31307c736f697265657c30 USING utf8mb4),CONVERT(0x393430613834636463643832626230383939393937626339623065353864356633353435333337363061663261666430 USING utf8mb4),3,CONVERT(0x323032362d30392d3130 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x337c323032362d30392d31377c736f697265657c30 USING utf8mb4),CONVERT(0x623165306563306264633731396331626432376262653632386337393536646563323365323866646335656337656264 USING utf8mb4),3,CONVERT(0x323032362d30392d3137 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x337c323032362d31302d30317c736f697265657c30 USING utf8mb4),CONVERT(0x356332373937653738353166336561343564303330623139326538323232376533363866383063306365643766623136 USING utf8mb4),3,CONVERT(0x323032362d31302d3031 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x337c323032362d31302d30387c736f697265657c30 USING utf8mb4),CONVERT(0x646166303865356261353062613530376461653735313432373435623033376439343335363861373161383931353833 USING utf8mb4),3,CONVERT(0x323032362d31302d3038 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x337c323032362d31302d31357c736f697265657c30 USING utf8mb4),CONVERT(0x326139633262643064636638363562343563633834376332336662616632383864363962303263333533303264653335 USING utf8mb4),3,CONVERT(0x323032362d31302d3135 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x337c323032362d31302d32327c736f697265657c30 USING utf8mb4),CONVERT(0x333532366533336231326238323737303039366539373734306138356565636166646361613335666339343531303637 USING utf8mb4),3,CONVERT(0x323032362d31302d3232 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x337c323032362d31302d32397c736f697265657c30 USING utf8mb4),CONVERT(0x373165386133613065396462333334396534336235363862306664343261383537616530373936326136313165643631 USING utf8mb4),3,CONVERT(0x323032362d31302d3239 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x337c323032362d31312d30357c736f697265657c30 USING utf8mb4),CONVERT(0x663262386464646561303333323636666634356666386139343536613738356262393135343938336130353939333739 USING utf8mb4),3,CONVERT(0x323032362d31312d3035 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x337c323032362d31312d31327c736f697265657c30 USING utf8mb4),CONVERT(0x303038613830376434316339653633346464363733383336366265343536363632666565663966656232323962663735 USING utf8mb4),3,CONVERT(0x323032362d31312d3132 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x337c323032362d31312d31397c736f697265657c30 USING utf8mb4),CONVERT(0x303939353865393563386433623332653832343432356230356538663466626265333865633733613531613532373866 USING utf8mb4),3,CONVERT(0x323032362d31312d3139 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x337c323032362d31312d32367c736f697265657c30 USING utf8mb4),CONVERT(0x646131616531343234326138386562356462373239623134313365336133366433386565333562323863303330343433 USING utf8mb4),3,CONVERT(0x323032362d31312d3236 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x337c323032362d31322d30337c736f697265657c30 USING utf8mb4),CONVERT(0x633361316231366530633634623466616439616563303439313964666535653737626264323937663932633633353331 USING utf8mb4),3,CONVERT(0x323032362d31322d3033 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x337c323032362d31322d31307c736f697265657c30 USING utf8mb4),CONVERT(0x343737356435316637643332336233326436323564346436336531343962613664656430626138623737393131393035 USING utf8mb4),3,CONVERT(0x323032362d31322d3130 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x337c323032362d31322d31377c736f697265657c30 USING utf8mb4),CONVERT(0x626531333336646239633538643161626465633063303039663934383034363264316464383865333132356638346264 USING utf8mb4),3,CONVERT(0x323032362d31322d3137 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x3536377c323032362d30392d30397c736f697265657c30 USING utf8mb4),CONVERT(0x346135343633656161666434623934386465386665333666313162393965663664373265646636393432393531633937 USING utf8mb4),567,CONVERT(0x323032362d30392d3039 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x3536377c323032362d30392d31367c736f697265657c30 USING utf8mb4),CONVERT(0x383161616366613037616238646436616130303134656239663839633662393263383462626137383733356136356265 USING utf8mb4),567,CONVERT(0x323032362d30392d3136 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x3537317c323032362d30392d31367c736f697265657c30 USING utf8mb4),CONVERT(0x393532346136666565393939383436323563626533613036346564366165313866326439333539393166623637616463 USING utf8mb4),571,CONVERT(0x323032362d30392d3136 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x3537317c323032362d30392d33307c736f697265657c30 USING utf8mb4),CONVERT(0x353431653939306535613062393861316333643332306438363565366461363332646265623337353035643664326335 USING utf8mb4),571,CONVERT(0x323032362d30392d3330 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x3539357c323032362d30392d30387c736f697265657c30 USING utf8mb4),CONVERT(0x393433353161363061366539336536623666646261313163613465356133326632623739666466306530656665613863 USING utf8mb4),595,CONVERT(0x323032362d30392d3038 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x3738307c323032362d30392d30397c736f697265657c30 USING utf8mb4),CONVERT(0x636563646630663036373738313963396362636461376634363838373365383261393864626533666139643161663538 USING utf8mb4),780,CONVERT(0x323032362d30392d3039 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x3830327c323032362d30392d30397c736f697265657c30 USING utf8mb4),CONVERT(0x643630323739653462383139396331316665326338386461326234343731333235356238653665366639623030386434 USING utf8mb4),802,CONVERT(0x323032362d30392d3039 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x3830327c323032362d30392d31367c736f697265657c30 USING utf8mb4),CONVERT(0x363930323535623737626461646666323765313736626235613365326131653266383434313633396437353332383137 USING utf8mb4),802,CONVERT(0x323032362d30392d3136 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x3830327c323032362d30392d32337c736f697265657c30 USING utf8mb4),CONVERT(0x623333643566613536333763643331353032643131653438633066646532386639316466356138346337336538333363 USING utf8mb4),802,CONVERT(0x323032362d30392d3233 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x3832347c323032362d30392d31377c736f697265657c30 USING utf8mb4),CONVERT(0x333065626338363236303630356164653636373566306662623734356336383937343065383931623830623333656230 USING utf8mb4),824,CONVERT(0x323032362d30392d3137 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x3934307c323032362d30392d30387c736f697265657c30 USING utf8mb4),CONVERT(0x333030333634393635646630356438393363376332383932393830393636386639656537313231346530636265643463 USING utf8mb4),940,CONVERT(0x323032362d30392d3038 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x3934377c323032362d30392d31307c736f697265657c30 USING utf8mb4),CONVERT(0x316364353335333164326664636166326563623762356661333935623036646131646530303563643430356631666533 USING utf8mb4),947,CONVERT(0x323032362d30392d3130 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x3934377c323032362d30392d31377c736f697265657c30 USING utf8mb4),CONVERT(0x623665396234366263643962303862383437313361316366363538346130353430666138613732303231353434326434 USING utf8mb4),947,CONVERT(0x323032362d30392d3137 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x3934377c323032362d30392d32347c736f697265657c30 USING utf8mb4),CONVERT(0x653535653738353139396163356236633563336132396438303162353936396338626633643638613563333966363963 USING utf8mb4),947,CONVERT(0x323032362d30392d3234 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0),
(CONVERT(0x3934377c323032362d31302d30317c736f697265657c30 USING utf8mb4),CONVERT(0x653332643730636565376137373262386361626239343563636636313238643965663237366236623136646161373062 USING utf8mb4),947,CONVERT(0x323032362d31302d3031 USING utf8mb4),CONVERT(0x736f69726565 USING utf8mb4),0);

CREATE TEMPORARY TABLE hb_sources (
 table_name VARCHAR(64) PRIMARY KEY, predicate_sql LONGTEXT NOT NULL,
 required_column VARCHAR(64) NOT NULL, mandatory TINYINT NOT NULL
) ENGINE=InnoDB;
CREATE TEMPORARY TABLE hb_hash_rows (
 row_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin PRIMARY KEY,
 multiplicity BIGINT UNSIGNED NOT NULL
) ENGINE=InnoDB;
CREATE TEMPORARY TABLE hb_capture (
 object_key VARCHAR(64) PRIMARY KEY, row_count BIGINT UNSIGNED NOT NULL,
 schema_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 data_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL
) ENGINE=InnoDB;

IF (SELECT COUNT(*) FROM hb_expected_sessions)<>70 OR (SELECT COUNT(*) FROM hb_expected_hubs)<>59 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='INVALID_PACK_COUNTS'; END IF;
IF (SELECT COUNT(*) FROM `prod_cotton_global_0`.championnats_sessions WHERE flag_session_demo=0 AND date>='2026-09-08')<>70 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='COHORT_CHANGED_REGENERATE'; END IF;
IF EXISTS(SELECT 1 FROM hb_expected_sessions e LEFT JOIN `prod_cotton_global_0`.championnats_sessions s ON s.id=e.id_session WHERE s.id IS NULL OR NOT(BINARY e.signature <=> BINARY SHA2(CONCAT_WS('|',IFNULL(HEX(CAST(s.`id` AS BINARY)),'N'),IFNULL(HEX(CAST(s.`id_client` AS BINARY)),'N'),IFNULL(HEX(CAST(s.`date` AS BINARY)),'N'),IFNULL(HEX(CAST(s.`heure_debut` AS BINARY)),'N'),IFNULL(HEX(CAST(s.`heure_fin` AS BINARY)),'N'),IFNULL(HEX(CAST(s.`id_operation_evenement` AS BINARY)),'N'),IFNULL(HEX(CAST(s.`id_evenement` AS BINARY)),'N'),IFNULL(HEX(CAST(s.`flag_session_demo` AS BINARY)),'N'),IFNULL(HEX(CAST(s.`flag_configuration_complete` AS BINARY)),'N'),IFNULL(HEX(CAST(s.`id_offre_client` AS BINARY)),'N'),IFNULL(HEX(CAST(s.`id_type_produit` AS BINARY)),'N'),IFNULL(HEX(CAST(s.`id_produit` AS BINARY)),'N'),IFNULL(HEX(CAST(s.`id_format` AS BINARY)),'N'),IFNULL(HEX(CAST(s.`flag_controle_numerique` AS BINARY)),'N'),IFNULL(HEX(CAST(s.`lot_ids` AS BINARY)),'N'),IFNULL(HEX(CAST(s.`community_item_id` AS BINARY)),'N'),IFNULL(HEX(CAST(s.`id_championnat_saison` AS BINARY)),'N'),IFNULL(HEX(CAST(s.`flag_session_finale` AS BINARY)),'N'),IFNULL(HEX(CAST(s.`flag_session_privee` AS BINARY)),'N'),IFNULL(HEX(CAST(s.`flag_session_weblive` AS BINARY)),'N'),IFNULL(HEX(CAST(s.`online` AS BINARY)),'N'),IFNULL(HEX(CAST(s.`position` AS BINARY)),'N'),IFNULL(HEX(CAST(s.`nb_joueurs_max` AS BINARY)),'N'),IFNULL(HEX(CAST(s.`nom` AS BINARY)),'N'),IFNULL(HEX(CAST(s.`nom_court` AS BINARY)),'N'),IFNULL(HEX(CAST(s.`lot_1` AS BINARY)),'N'),IFNULL(HEX(CAST(s.`lot_2` AS BINARY)),'N'),IFNULL(HEX(CAST(s.`lot_3` AS BINARY)),'N'),IFNULL(HEX(CAST(s.`date_ajout` AS BINARY)),'N'),IFNULL(HEX(CAST(s.`date_maj` AS BINARY)),'N')),256))) THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='SOURCE_CHANGED_REGENERATE'; END IF;
IF EXISTS(SELECT 1 FROM hb_expected_hubs e LEFT JOIN `prod_cotton_global_0`.clients c ON c.id=e.id_client WHERE c.id IS NULL) THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='CLIENT_MISSING'; END IF;
IF EXISTS(SELECT 1 FROM hb_expected_sessions s LEFT JOIN hb_expected_hubs h ON h.logical_hub=s.logical_hub WHERE h.logical_hub IS NULL) THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='MANIFEST_ORPHAN'; END IF;
IF EXISTS(SELECT 1 FROM `prod_cotton_global_0`.championnats_sessions WHERE id IN (29370,29371,29622,29623,29631,29632,29643,29644,29668,29669,29670,29673,29674,29705,29706,29756,29774,29775,29827,29828,29829,29830,29831,29832,29833,29834,29835,29836,29837,29838,29839,29840,29913,29914,29915,29916,29976,29978,29979,30029,30030,30031,30035,30036,30047,30049,30053,30054,30055,30056,30057,30058,30059,30060,30061,30062,30063,30064,30065,30066,30067,30068,30069,30071,30121,30122,30126,30127,30139,30140) AND (id_securite IS NULL OR TRIM(id_securite)='')) THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='LEGACY_TOKEN_MISSING'; END IF;
IF (SELECT COUNT(*) FROM `prod_cotton_global_0`.operations_evenements WHERE BINARY CAST(`id` AS CHAR) <=> BINARY CONVERT(0x363031 USING utf8mb4) AND BINARY CAST(`id_client` AS CHAR) <=> BINARY CONVERT(0x32343336 USING utf8mb4) AND BINARY CAST(`date_debut` AS CHAR) <=> BINARY CONVERT(0x323032362d30392d32362030303a30303a3030 USING utf8mb4) AND BINARY CAST(`date_fin` AS CHAR) <=> BINARY CONVERT(0x323032362d30392d32362030303a30303a3030 USING utf8mb4) AND BINARY CAST(`nom` AS CHAR) <=> BINARY CONVERT(0xc38976c3a96e656d656e742064752032362f30392f32303236 USING utf8mb4) AND BINARY CAST(`nom_court` AS CHAR) <=> BINARY CONVERT(0xc38976c3a96e656d656e742064752032362f30392f32303236 USING utf8mb4) AND BINARY CAST(`seo_slug` AS CHAR) <=> BINARY CONVERT(0x636f74746f6e2d6576656e742d323433362d3230323630393236 USING utf8mb4) AND BINARY CAST(`flag_evenement_demo` AS CHAR) <=> BINARY CONVERT(0x30 USING utf8mb4) AND BINARY CAST(`flag_evenement_prive` AS CHAR) <=> BINARY CONVERT(0x31 USING utf8mb4) AND BINARY CAST(`online` AS CHAR) <=> BINARY CONVERT(0x30 USING utf8mb4))<>1 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='EVENT_CHANGED_REGENERATE'; END IF;
IF (SELECT COUNT(*) FROM `prod_cotton_global_0`.operations_evenements WHERE BINARY CAST(`id` AS CHAR) <=> BINARY CONVERT(0x363138 USING utf8mb4) AND BINARY CAST(`id_client` AS CHAR) <=> BINARY CONVERT(0x32343539 USING utf8mb4) AND BINARY CAST(`date_debut` AS CHAR) <=> BINARY CONVERT(0x323032362d30392d31322030303a30303a3030 USING utf8mb4) AND BINARY CAST(`date_fin` AS CHAR) <=> BINARY CONVERT(0x323032362d30392d31322030303a30303a3030 USING utf8mb4) AND BINARY CAST(`nom` AS CHAR) <=> BINARY CONVERT(0xc38976c3a96e656d656e742064752031322f30392f32303236 USING utf8mb4) AND BINARY CAST(`nom_court` AS CHAR) <=> BINARY CONVERT(0xc38976c3a96e656d656e742064752031322f30392f32303236 USING utf8mb4) AND BINARY CAST(`seo_slug` AS CHAR) <=> BINARY CONVERT(0x636f74746f6e2d6576656e742d323435392d3230323630393132 USING utf8mb4) AND BINARY CAST(`flag_evenement_demo` AS CHAR) <=> BINARY CONVERT(0x30 USING utf8mb4) AND BINARY CAST(`flag_evenement_prive` AS CHAR) <=> BINARY CONVERT(0x31 USING utf8mb4) AND BINARY CAST(`online` AS CHAR) <=> BINARY CONVERT(0x30 USING utf8mb4))<>1 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='EVENT_CHANGED_REGENERATE'; END IF;
IF (SELECT COUNT(*) FROM `prod_cotton_global_0`.`games_hubs`)<>0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='ALREADY_RUN_OR_HUB_COLLISION'; END IF;
IF (SELECT COUNT(*) FROM `prod_cotton_global_0`.`games_hubs_sessions`)<>0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='ALREADY_RUN_OR_HUB_COLLISION'; END IF;
IF (SELECT COUNT(*) FROM `prod_cotton_global_0`.`games_hubs_players`)<>0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='HUB_OR_QUICK_ACTIVITY_PRESENT'; END IF;
IF (SELECT COUNT(*) FROM `prod_cotton_global_0`.`games_hubs_participations_probables`)<>0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='HUB_OR_QUICK_ACTIVITY_PRESENT'; END IF;
IF (SELECT COUNT(*) FROM `prod_cotton_global_0`.`games_hubs_players_sessions`)<>0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='HUB_OR_QUICK_ACTIVITY_PRESENT'; END IF;
IF (SELECT COUNT(*) FROM `prod_cotton_global_0`.`games_hubs_publication`)<>0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='HUB_OR_QUICK_ACTIVITY_PRESENT'; END IF;
IF (SELECT COUNT(*) FROM `prod_cotton_global_0`.`games_hubs_prizes`)<>0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='HUB_OR_QUICK_ACTIVITY_PRESENT'; END IF;
IF (SELECT COUNT(*) FROM `prod_cotton_global_0`.`games_hubs_remote_access`)<>0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='HUB_OR_QUICK_ACTIVITY_PRESENT'; END IF;
IF (SELECT COUNT(*) FROM `prod_cotton_global_0`.`games_hubs_remote_master_presence`)<>0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='HUB_OR_QUICK_ACTIVITY_PRESENT'; END IF;
IF (SELECT COUNT(*) FROM `prod_cotton_global_0`.`games_hubs_remote_runtime_presence`)<>0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='HUB_OR_QUICK_ACTIVITY_PRESENT'; END IF;
IF (SELECT COUNT(*) FROM `prod_cotton_global_0`.`games_hubs_remote_commands`)<>0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='HUB_OR_QUICK_ACTIVITY_PRESENT'; END IF;
IF (SELECT COUNT(*) FROM `prod_cotton_global_0`.`programming_quick_operations`)<>0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='HUB_OR_QUICK_ACTIVITY_PRESENT'; END IF;
IF (SELECT COUNT(*) FROM `prod_cotton_global_0`.`programming_quick_series_operations`)<>0 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='HUB_OR_QUICK_ACTIVITY_PRESENT'; END IF;
DELETE FROM hb_sources;
INSERT INTO hb_sources VALUES
(CONVERT(0x6368616d70696f6e6e6174735f73657373696f6e73 USING utf8mb4),CONVERT(0x696420494e202832393337302c32393337312c32393632322c32393632332c32393633312c32393633322c32393634332c32393634342c32393636382c32393636392c32393637302c32393637332c32393637342c32393730352c32393730362c32393735362c32393737342c32393737352c32393832372c32393832382c32393832392c32393833302c32393833312c32393833322c32393833332c32393833342c32393833352c32393833362c32393833372c32393833382c32393833392c32393834302c32393931332c32393931342c32393931352c32393931362c32393937362c32393937382c32393937392c33303032392c33303033302c33303033312c33303033352c33303033362c33303034372c33303034392c33303035332c33303035342c33303035352c33303035362c33303035372c33303035382c33303035392c33303036302c33303036312c33303036322c33303036332c33303036342c33303036352c33303036362c33303036372c33303036382c33303036392c33303037312c33303132312c33303132322c33303132362c33303132372c33303133392c333031343029 USING utf8mb4),CONVERT(0x6964 USING utf8mb4),1),
(CONVERT(0x636c69656e7473 USING utf8mb4),CONVERT(0x696420494e2028332c39322c3135342c3536372c3537312c3539352c3738302c3830322c3832342c3934302c3934372c313930392c313935382c313935392c323137302c323433362c323433372c323435342c323435352c3234353929 USING utf8mb4),CONVERT(0x6964 USING utf8mb4),1),
(CONVERT(0x6f7065726174696f6e735f6576656e656d656e7473 USING utf8mb4),CONVERT(0x696420494e20283630312c36313829 USING utf8mb4),CONVERT(0x6964 USING utf8mb4),1),
(CONVERT(0x6368616d70696f6e6e6174735f73657373696f6e735f6c6f7473 USING utf8mb4),CONVERT(0x69645f6368616d70696f6e6e61745f73657373696f6e20494e202832393337302c32393337312c32393632322c32393632332c32393633312c32393633322c32393634332c32393634342c32393636382c32393636392c32393637302c32393637332c32393637342c32393730352c32393730362c32393735362c32393737342c32393737352c32393832372c32393832382c32393832392c32393833302c32393833312c32393833322c32393833332c32393833342c32393833352c32393833362c32393833372c32393833382c32393833392c32393834302c32393931332c32393931342c32393931352c32393931362c32393937362c32393937382c32393937392c33303032392c33303033302c33303033312c33303033352c33303033362c33303034372c33303034392c33303035332c33303035342c33303035352c33303035362c33303035372c33303035382c33303035392c33303036302c33303036312c33303036322c33303036332c33303036342c33303036352c33303036362c33303036372c33303036382c33303036392c33303037312c33303132312c33303132322c33303132362c33303132372c33303133392c333031343029 USING utf8mb4),CONVERT(0x69645f6368616d70696f6e6e61745f73657373696f6e USING utf8mb4),1),
(CONVERT(0x6368616d70696f6e6e6174735f73657373696f6e735f70617274696369706174696f6e735f70726f6261626c6573 USING utf8mb4),CONVERT(0x69645f6368616d70696f6e6e61745f73657373696f6e20494e202832393337302c32393337312c32393632322c32393632332c32393633312c32393633322c32393634332c32393634342c32393636382c32393636392c32393637302c32393637332c32393637342c32393730352c32393730362c32393735362c32393737342c32393737352c32393832372c32393832382c32393832392c32393833302c32393833312c32393833322c32393833332c32393833342c32393833352c32393833362c32393833372c32393833382c32393833392c32393834302c32393931332c32393931342c32393931352c32393931362c32393937362c32393937382c32393937392c33303032392c33303033302c33303033312c33303033352c33303033362c33303034372c33303034392c33303035332c33303035342c33303035352c33303035362c33303035372c33303035382c33303035392c33303036302c33303036312c33303036322c33303036332c33303036342c33303036352c33303036362c33303036372c33303036382c33303036392c33303037312c33303132312c33303132322c33303132362c33303132372c33303133392c333031343029 USING utf8mb4),CONVERT(0x69645f6368616d70696f6e6e61745f73657373696f6e USING utf8mb4),1),
(CONVERT(0x67656e6572616c5f6272616e64696e67 USING utf8mb4),CONVERT(0x2869645f747970655f6272616e64696e673d3120414e442069645f72656c6174656420494e202832393337302c32393337312c32393632322c32393632332c32393633312c32393633322c32393634332c32393634342c32393636382c32393636392c32393637302c32393637332c32393637342c32393730352c32393730362c32393735362c32393737342c32393737352c32393832372c32393832382c32393832392c32393833302c32393833312c32393833322c32393833332c32393833342c32393833352c32393833362c32393833372c32393833382c32393833392c32393834302c32393931332c32393931342c32393931352c32393931362c32393937362c32393937382c32393937392c33303032392c33303033302c33303033312c33303033352c33303033362c33303034372c33303034392c33303035332c33303035342c33303035352c33303035362c33303035372c33303035382c33303035392c33303036302c33303036312c33303036322c33303036332c33303036342c33303036352c33303036362c33303036372c33303036382c33303036392c33303037312c33303132312c33303132322c33303132362c33303132372c33303133392c33303134302929204f52202869645f747970655f6272616e64696e673d3220414e442069645f72656c6174656420494e20283630312c3631382929204f52202869645f747970655f6272616e64696e673d3320414e442069645f72656c6174656420494e202839322929204f52202869645f747970655f6272616e64696e673d3420414e442069645f72656c6174656420494e2028332c39322c3135342c3536372c3537312c3539352c3738302c3830322c3832342c3934302c3934372c313930392c313935382c313935392c323137302c323433362c323433372c323435342c323435352c323435392929204f522069645f747970655f6272616e64696e673d35 USING utf8mb4),CONVERT(0x69645f72656c61746564 USING utf8mb4),1),
(CONVERT(0x636c69656e74735f6272616e64696e67 USING utf8mb4),CONVERT(0x69645f636c69656e7420494e2028332c39322c3135342c3536372c3537312c3539352c3738302c3830322c3832342c3934302c3934372c313930392c313935382c313935392c323137302c323433362c323433372c323435342c323435352c3234353929204f522069645f6f7065726174696f6e5f6576656e656d656e7420494e20283630312c36313829 USING utf8mb4),CONVERT(0x69645f636c69656e74 USING utf8mb4),1),
(CONVERT(0x6368616d70696f6e6e6174735f726573756c74617473 USING utf8mb4),CONVERT(0x69645f6368616d70696f6e6e61745f73657373696f6e20494e202832393337302c32393337312c32393632322c32393632332c32393633312c32393633322c32393634332c32393634342c32393636382c32393636392c32393637302c32393637332c32393637342c32393730352c32393730362c32393735362c32393737342c32393737352c32393832372c32393832382c32393832392c32393833302c32393833312c32393833322c32393833332c32393833342c32393833352c32393833362c32393833372c32393833382c32393833392c32393834302c32393931332c32393931342c32393931352c32393931362c32393937362c32393937382c32393937392c33303032392c33303033302c33303033312c33303033352c33303033362c33303034372c33303034392c33303035332c33303035342c33303035352c33303035362c33303035372c33303035382c33303035392c33303036302c33303036312c33303036322c33303036332c33303036342c33303036352c33303036362c33303036372c33303036382c33303036392c33303037312c33303132312c33303132322c33303132362c33303132372c33303133392c333031343029 USING utf8mb4),CONVERT(0x69645f6368616d70696f6e6e61745f73657373696f6e USING utf8mb4),1),
(CONVERT(0x657175697065735f746f5f6368616d70696f6e6e6174735f73657373696f6e73 USING utf8mb4),CONVERT(0x69645f6368616d70696f6e6e61745f73657373696f6e20494e202832393337302c32393337312c32393632322c32393632332c32393633312c32393633322c32393634332c32393634342c32393636382c32393636392c32393637302c32393637332c32393637342c32393730352c32393730362c32393735362c32393737342c32393737352c32393832372c32393832382c32393832392c32393833302c32393833312c32393833322c32393833332c32393833342c32393833352c32393833362c32393833372c32393833382c32393833392c32393834302c32393931332c32393931342c32393931352c32393931362c32393937362c32393937382c32393937392c33303032392c33303033302c33303033312c33303033352c33303033362c33303034372c33303034392c33303035332c33303035342c33303035352c33303035362c33303035372c33303035382c33303035392c33303036302c33303036312c33303036322c33303036332c33303036342c33303036352c33303036362c33303036372c33303036382c33303036392c33303037312c33303132312c33303132322c33303132362c33303132372c33303133392c333031343029 USING utf8mb4),CONVERT(0x69645f6368616d70696f6e6e61745f73657373696f6e USING utf8mb4),1),
(CONVERT(0x657175697065735f6368616d70696f6e6e6174735f73657373696f6e735f7265706f6e736573 USING utf8mb4),CONVERT(0x69645f6368616d70696f6e6e61745f73657373696f6e20494e202832393337302c32393337312c32393632322c32393632332c32393633312c32393633322c32393634332c32393634342c32393636382c32393636392c32393637302c32393637332c32393637342c32393730352c32393730362c32393735362c32393737342c32393737352c32393832372c32393832382c32393832392c32393833302c32393833312c32393833322c32393833332c32393833342c32393833352c32393833362c32393833372c32393833382c32393833392c32393834302c32393931332c32393931342c32393931352c32393931362c32393937362c32393937382c32393937392c33303032392c33303033302c33303033312c33303033352c33303033362c33303034372c33303034392c33303035332c33303035342c33303035352c33303035362c33303035372c33303035382c33303035392c33303036302c33303036312c33303036322c33303036332c33303036342c33303036352c33303036362c33303036372c33303036382c33303036392c33303037312c33303132312c33303132322c33303132362c33303132372c33303133392c333031343029 USING utf8mb4),CONVERT(0x69645f6368616d70696f6e6e61745f73657373696f6e USING utf8mb4),1),
(CONVERT(0x6368616d70696f6e6e6174735f73657373696f6e735f70617274696369706174696f6e735f67616d65735f636f6e6e656374656573 USING utf8mb4),CONVERT(0x69645f6368616d70696f6e6e61745f73657373696f6e20494e202832393337302c32393337312c32393632322c32393632332c32393633312c32393633322c32393634332c32393634342c32393636382c32393636392c32393637302c32393637332c32393637342c32393730352c32393730362c32393735362c32393737342c32393737352c32393832372c32393832382c32393832392c32393833302c32393833312c32393833322c32393833332c32393833342c32393833352c32393833362c32393833372c32393833382c32393833392c32393834302c32393931332c32393931342c32393931352c32393931362c32393937362c32393937382c32393937392c33303032392c33303033302c33303033312c33303033352c33303033362c33303034372c33303034392c33303035332c33303035342c33303035352c33303035362c33303035372c33303035382c33303035392c33303036302c33303036312c33303036322c33303036332c33303036342c33303036352c33303036362c33303036372c33303036382c33303036392c33303037312c33303132312c33303132322c33303132362c33303132372c33303133392c333031343029 USING utf8mb4),CONVERT(0x69645f6368616d70696f6e6e61745f73657373696f6e USING utf8mb4),1),
(CONVERT(0x6a6575785f62696e676f5f6d75736963616c5f706c61796c697374735f636c69656e7473 USING utf8mb4),CONVERT(0x696420494e202831373532392c31373535302c31373535312c31373535322c31373536362c31373538302c31373634342c31373634352c31373634362c31373634372c31373636362c31373636382c31373636392c31373639342c31373639352c31373639362c313737303929 USING utf8mb4),CONVERT(0x6964 USING utf8mb4),1),
(CONVERT(0x6a6575785f62696e676f5f6d75736963616c5f6d6f7263656175785f746f5f706c61796c697374735f636c69656e7473 USING utf8mb4),CONVERT(0x69645f706c61796c6973745f636c69656e7420494e202831373532392c31373535302c31373535312c31373535322c31373536362c31373538302c31373634342c31373634352c31373634362c31373634372c31373636362c31373636382c31373636392c31373639342c31373639352c31373639362c313737303929 USING utf8mb4),CONVERT(0x69645f706c61796c6973745f636c69656e74 USING utf8mb4),1);

-- Tokens are used only inside this connection and are not exported.
SELECT GROUP_CONCAT(CONCAT('CONVERT(0x',HEX(TRIM(id_securite)),' USING utf8mb4)') ORDER BY id SEPARATOR ',')
 INTO @hb_legacy_tokens FROM `prod_cotton_global_0`.championnats_sessions WHERE id IN (29370,29371,29622,29623,29631,29632,29643,29644,29668,29669,29670,29673,29674,29705,29706,29756,29774,29775,29827,29828,29829,29830,29831,29832,29833,29834,29835,29836,29837,29838,29839,29840,29913,29914,29915,29916,29976,29978,29979,30029,30030,30031,30035,30036,30047,30049,30053,30054,30055,30056,30057,30058,30059,30060,30061,30062,30063,30064,30065,30066,30067,30068,30069,30071,30121,30122,30126,30127,30139,30140);
SELECT GROUP_CONCAT(CAST(id AS CHAR) ORDER BY id SEPARATOR ',') INTO @hb_lot_ids
 FROM `prod_cotton_global_0`.championnats_sessions_lots WHERE id_championnat_session IN (29370,29371,29622,29623,29631,29632,29643,29644,29668,29669,29670,29673,29674,29705,29706,29756,29774,29775,29827,29828,29829,29830,29831,29832,29833,29834,29835,29836,29837,29838,29839,29840,29913,29914,29915,29916,29976,29978,29979,30029,30030,30031,30035,30036,30047,30049,30053,30054,30055,30056,30057,30058,30059,30060,30061,30062,30063,30064,30065,30066,30067,30068,30069,30071,30121,30122,30126,30127,30139,30140);
SET @hb_lot_ids=COALESCE(@hb_lot_ids,'-1');
SET @hb_sql=CONCAT('SELECT GROUP_CONCAT(CONCAT(CHAR(39),id,CHAR(39)) ORDER BY id SEPARATOR ',CHAR(39),',',CHAR(39),') INTO @hb_bt_ids FROM `prod_cotton_global_0`.blindtest_sessions WHERE session_id IN (',@hb_legacy_tokens,')');
PREPARE hb_stmt FROM @hb_sql; EXECUTE hb_stmt; DEALLOCATE PREPARE hb_stmt;
SET @hb_sql=CONCAT('SELECT GROUP_CONCAT(CONCAT(CHAR(39),id,CHAR(39)) ORDER BY id SEPARATOR ',CHAR(39),',',CHAR(39),') INTO @hb_quiz_ids FROM `prod_cotton_global_0`.cotton_quiz_sessions WHERE session_id IN (',@hb_legacy_tokens,')');
PREPARE hb_stmt FROM @hb_sql; EXECUTE hb_stmt; DEALLOCATE PREPARE hb_stmt;
SET @hb_bt_ids=COALESCE(@hb_bt_ids,CONVERT(0x275f5f48425f4e4f5f52554e54494d455f5f27 USING utf8mb4));
SET @hb_quiz_ids=COALESCE(@hb_quiz_ids,CONVERT(0x275f5f48425f4e4f5f52554e54494d455f5f27 USING utf8mb4));
INSERT INTO hb_sources VALUES
 ('championnats_sessions_lots_to_entites_joueurs',CONCAT('id_lot IN (',@hb_lot_ids,')'),'id_lot',1),
 ('blindtest_sessions',CONCAT('session_id IN (',@hb_legacy_tokens,')'),'session_id',1),
 ('cotton_quiz_sessions',CONCAT('session_id IN (',@hb_legacy_tokens,')'),'session_id',1),
 ('blindtest_players',CONCAT('session_id IN (',@hb_bt_ids,')'),'session_id',0),
 ('cotton_quiz_players',CONCAT('session_id IN (',@hb_quiz_ids,')'),'session_id',0),
 ('bingo_players',CONCAT('session_id IN (',@hb_legacy_tokens,')'),'session_id',0),
 ('bingo_phase_winners',CONCAT('session_id IN (',@hb_legacy_tokens,')'),'session_id',0),
 ('game_events',CONCAT('session_id IN (',@hb_legacy_tokens,',',CONVERT(0x434f4e56455254283078363133343332333533343337363236353333363433383337333836363331363233363338363536333339333733313337333733353635363336363331333433343338363336343331363233363330363336363339363433373332333333393338205553494e4720757466386d6234292c434f4e56455254283078333133343330333436333335333933393632333736353633333333313338333233373333363533323632333433393337363633373333333536333331363533373633333533363335363133333631363236353636363533393333333233373634205553494e4720757466386d6234292c434f4e56455254283078333533393333363333393338363536343336333136333635333733383632333136353636333236333338333236333331333036313635333733363330333936313631333236333635333233353634333933343633333833393336333833393339205553494e4720757466386d6234292c434f4e56455254283078333736313636333133373336363633363331363633343635333633333632333933353333363533363633363333303336333836333334363636343335363533333330333436353634333233343333363533313632333433343339333736363333205553494e4720757466386d6234292c434f4e56455254283078333936353335333733343632333633323332333133323632363336363336333036333337333733343631333833323335363433333338333833373633333436363331333233303634363133353338363233303336333633393335333136363335205553494e4720757466386d6234292c434f4e56455254283078363233343337333933383334363433363634333636353336333333363332363636333334333636343330363536353339333233393335333533343330333036343333363233313634363233313634333433323332363136353336363233373337205553494e4720757466386d6234292c434f4e56455254283078363433393334363633323634363136353634363136363334333033303335333736363635333236353333333833333633333133313336333433323635363236323633363536363632333233323339363133323332333333333633363433373330205553494e4720757466386d6234292c434f4e56455254283078333033323332333633373633333533393337333533393332363133303332363633373633333533393635333033363635333536333338333536343631333133393334333133373632333936323330363333363336333333343339363233383332205553494e4720757466386d6234292c434f4e56455254283078363636363631333636323331333336323635333933333332333033393332363133353337363233373634363236363336363536353339363336363337363233353330333833393631333336333636333533393330363136343636363433363330205553494e4720757466386d6234292c434f4e56455254283078333033323633333336353333333933313635363636343632363233373333333733333338363336333338333333373635333933303636333033363633363336343632333833343635333833383635363133383636363233353339363436313338205553494e4720757466386d6234292c434f4e56455254283078333336323331333133323339333333333636363533323333363536333339333733383332333833393331333633323332363236333337333933313332333933363631333533363337333033313631333433393331333836323332363436343631205553494e4720757466386d6234292c434f4e56455254283078333733333339333833313339363336313332333433393636363333363634363233303634333933323331363433313335333533313631363433373335363633323331363333333633333836363634333633313335333933393339333036353635205553494e4720757466386d6234292c434f4e56455254283078363536363339363636323333363333373336363236343339333633383336363336333635333736343635333936363339333533323337363633353331363233313336333433313338363236323635333236333631363533383336363433333334205553494e4720757466386d6234292c434f4e56455254283078363436353331333733383333363536333331333036313330363433393632333533343337333433313334333336313335333436353635333936323338363636353633333133373331333536323339333536353636333433333631333436333636205553494e4720757466386d6234292c434f4e56455254283078363233383636363233313632333836333631363433363331333736333631333633353338333533313338333436313334363533383633363133303631363533303332333933323339333533333636363633363633363436323631363436363633205553494e4720757466386d6234292c434f4e56455254283078333233323330333136353338363336343633333733303335333033323339333033393336363436353633363433363331333136343636333836363632363433353332363436323631333933383633363536363331333533393333333233343632205553494e4720757466386d6234292c434f4e56455254283078333936323634333933353631333933313636333933353333363636313338333833373337333636343339333433373335333033353338363136323332333533363634333633323337333436353333333233303339333633353632363333353337205553494e4720757466386d6234292c434f4e56455254283078363533393633333533373636333236363339363136313338333633353635363636363339333533393331363133303634333833313339363233333334333633373335333536323339333836313336333533383632333636313636333433343634205553494e4720757466386d6234292c434f4e56455254283078333736363333333733383339333533313331333736313339333933383339363533313330333433323331333733383636333733353336363636323636363633313334363233373634363136363333333736363337333133393635363133343332205553494e4720757466386d6234292c434f4e56455254283078363636313635333733383337333133383633333633373635333436363634333233313335363233343631333236343633363333303333333733323336333333363634363633373332333536323331363233333631363133363634363636313634205553494e4720757466386d6234292c434f4e56455254283078333633323336333736353339333433333635333533353634363633313631363236313338333133313331363233373332333133363633363533363335363336313632363533313336333036313337333133353334333633343337363433373334205553494e4720757466386d6234292c434f4e56455254283078363533303336333933363339363333363334363233313338363636363332333436353338333133313636363233373334333133313332333033323636363233383632363433353332333433323331363133363335333236313631333533373334205553494e4720757466386d6234292c434f4e56455254283078333033363335333233323636333633313334363236313331333536343330333936323335363133383332333333393336363136323635333733333631363136363330333936313332333936353337333736343631363633363634333936323635205553494e4720757466386d6234292c434f4e56455254283078333033363631363236333632333433343633333933323631333033373339333836313330333036323339333633373335363636333336333933393339363336313634333433393338333936343335333833353334333533363334333133373335205553494e4720757466386d6234292c434f4e56455254283078333436333635363136343336333736333633333736353338333233353339333933373339333833323334363633353631333933393634333733383330363133323633333133363636333833313334333936363632333936353635333433343336205553494e4720757466386d6234292c434f4e56455254283078363533363631363636363334333036323336333033353337333836323635363233313632333533363633333133353635363236313333333736343339363633393631333833373330333133333634333133383333333633393634363633373333205553494e4720757466386d6234292c434f4e56455254283078363333303633363136333330333036353636333536333330363236353636333036343636333133373636333136363635333533353633363333313338333033373632363136343334363536323632333533383633333033333633363333373331205553494e4720757466386d6234292c434f4e56455254283078333733303336363336313337333733393332333133303633363536313636333536333334333436333336333733343332333936343330333533373336333333393332363633313339363133383332333036353331333133343636333036323337205553494e4720757466386d6234292c434f4e56455254283078363333333336363636313631333533353332363533383337333333393339363136343632333733343632363136313631333333333331333433363632333333333632333936333330363333303335333133353332333936323631363533333333205553494e4720757466386d6234292c434f4e56455254283078333933383632363236363635333233333335363636363331333633343636333033343335333233353332333136313334333733343634363336323635333033333330333433383337333933303332363333343337333336333339363633343636205553494e4720757466386d6234292c434f4e56455254283078333933343330363133383334363336343633363433383332363236323330333833393339333933393337363236333339363233303635333533383634333536363333333533343335333333333337333633303631363633323631363636343330205553494e4720757466386d6234292c434f4e56455254283078363233313635333036353633333036323634363333373331333936333331363236343332333736323632363533363332333836333337333933353336363436353633333233333635333233383636363436333335363536333337363536323634205553494e4720757466386d6234292c434f4e56455254283078333536333332333733393337363533373338333533313636333336353631333433353634333033333330363233313339333236353338333233323332333736353333333633383636333833303633333036333635363433373636363233313336205553494e4720757466386d6234292c434f4e56455254283078363436313636333033383635333536323631333533303632363133353330333736343631363533373335333133343332333733343335363233303333333736343339333433333335333633383631333733313631333833393331333533383333205553494e4720757466386d6234292c434f4e56455254283078333236313339363333323632363433303634363336363338333633353632333433353633363333383334333736333332333336363632363136363332333833383634333633393632333033323633333333353333333033323634363533333335205553494e4720757466386d6234292c434f4e56455254283078333333353332333636353333333336323331333236323338333233373337333033303339333636353339333733373334333036313338333536353635363336313636363436333631363133333335363636333339333433353331333033363337205553494e4720757466386d6234292c434f4e56455254283078333733313635333836313333363133303635333936343632333333333334333936353334333336323335333633383632333036363634333433323631333833353337363136353330333733393336333236313336333133313635363433363331205553494e4720757466386d6234292c434f4e56455254283078363633323632333836343634363436353631333033333333333233363336363636363334333536363636333836313339333433353336363133373338333536323632333933313335333433393338333336313330333533393339333333373339205553494e4720757466386d6234292c434f4e56455254283078333033303338363133383330333736343334333136333339363533363333333436343634333633373333333833333336333636323635333433353336333633363332363636353635363633393636363536323332333233393632363633373335205553494e4720757466386d6234292c434f4e56455254283078333033393339333533383635333933353633333836343333363233333332363533383332333433343332333536323330333536353338363633343636363236323635333333383635363333373333363133353331363133353332333733383636205553494e4720757466386d6234292c434f4e56455254283078363436313331363136353331333433323334333236313338333836353632333536343632333733323339363233313334333133333635333336313333333636343333333836353635333333353632333233383633333033333330333433343333205553494e4720757466386d6234292c434f4e56455254283078363333333631333136323331333636353330363333363334363233343636363136343339363136353633333033343339333133393634363636353335363533373337363236323634333233393337363633393332363333363333333533333331205553494e4720757466386d6234292c434f4e56455254283078333433373337333536343335333136363337363433333332333336323333333236343336333233353634333436343336333336353331333433393632363133363634363536343330363236313338363233373337333933313331333933303335205553494e4720757466386d6234292c434f4e56455254283078363236353331333333333336363436323339363333353338363433313631363236343635363333303633333033303339363633393334333833303334333633323634333136343634333833383635333333313332333536363338333436323634205553494e4720757466386d6234292c434f4e56455254283078333436313335333433363333363536313631363636343334363233393334333836343635333836363635333333363636333133313632333933393635363633363634333733323635363436363336333933343332333933353331363333393337205553494e4720757466386d6234292c434f4e56455254283078333833313631363136333636363133303337363136323338363436343336363136313330333033313334363536323339363633383339363333363632333933323633333833343632363236313337333833373333333536313336333536323635205553494e4720757466386d6234292c434f4e56455254283078333933353332333436313336363636353635333933393339333833343336333233353633363236353333363133303336333436353634333636313635333133383636333236343339333333353339333933313636363233363337363136343633205553494e4720757466386d6234292c434f4e56455254283078333533343331363533393339333036353335363133303632333933383631333136333333363433333332333036343338333633353635333636343631333633333332363436323635363233333337333533303335363433363634333236333335205553494e4720757466386d6234292c434f4e56455254283078333933343333333533313631333633303631333636353339333336353336363233363636363436323631333133313633363133343635333536313333333236363332363233373339363636343636333036353330363536363635363133383633205553494e4720757466386d6234292c434f4e56455254283078363336353633363436363330363633303336333733373338333133393633333936333632363336343631333736363334333633383338333733333635333833323631333933383634363236353333363636313339363433313631363633353338205553494e4720757466386d6234292c434f4e56455254283078363433363330333233373339363533343632333833313339333936333331333136363635333236333338333836343631333236323334333433373331333333323335333536323338363533363635333636363339363233303330333836343334205553494e4720757466386d6234292c434f4e56455254283078333633393330333233353335363233373337363236343631363436363636333233373635333133373336363236323335363133333635333236313331363533323636333833343334333133363333333936343337333533333332333833313337205553494e4720757466386d6234292c434f4e56455254283078363233333333363433353636363133353336333333373633363433333331333533303332363433313331363533343338363333303636363436353332333836363339333136343636333536313338333436333337333336353338333333333633205553494e4720757466386d6234292c434f4e56455254283078333333303635363236333338333633323336333033363330333536313634363533363336333733353636333036363632363233373334333536333336333833393337333433303635333833393331363233383330363233333333363536323330205553494e4720757466386d6234292c434f4e56455254283078333333303330333333363334333933363335363436363330333536343338333933333633333736333332333833393332333933383330333933363336333836363339363536353337333133323331333436353330363336323635363433343633205553494e4720757466386d6234292c434f4e56455254283078333136333634333533333335333333313634333236363634363336313636333236353633363233373632333536363631333333393335363233303336363436313331363436353330333033353633363433343330333536363331363636353333205553494e4720757466386d6234292c434f4e56455254283078363233363635333936323334333636323633363433393632333033383632333833343337333133333631333136333636333633353338333436313330333533343330363636313338363133373332333033323331333533343334333236343334205553494e4720757466386d6234292c434f4e56455254283078363533353335363533373338333533313339333936313633333536323336363333353633333336313332333936343338333033313632333533393336333936333338363236363333363433363338363133353633333333393636333633393633205553494e4720757466386d6234292c434f4e56455254283078363533333332363433373330363336353635333736313337333733323632333836333631363236323339333433353633363336363336333133323338363433393635363633323337333636323336363233313336363436313631333733303632205553494e4720757466386d623429 USING utf8mb4),')'),'session_id',0);

BEGIN
 DECLARE done_sources INT DEFAULT 0;
 DECLARE tab VARCHAR(64); DECLARE predicate_text LONGTEXT;
 DECLARE required_col VARCHAR(64); DECLARE mandatory_table INT;
 DECLARE present_count INT; DECLARE col_count INT;
 DECLARE col_defs LONGTEXT; DECLARE index_defs LONGTEXT; DECLARE exprs LONGTEXT;
 DECLARE table_engine VARCHAR(64); DECLARE table_collation VARCHAR(64);
 DECLARE schema_digest CHAR(64); DECLARE data_digest CHAR(64); DECLARE total_rows BIGINT;
 DECLARE sources_cursor CURSOR FOR SELECT table_name,predicate_sql,required_column,mandatory FROM hb_sources ORDER BY table_name;
 DECLARE CONTINUE HANDLER FOR NOT FOUND SET done_sources=1;
 DELETE FROM hb_capture;
 OPEN sources_cursor;
 source_loop: LOOP
  FETCH sources_cursor INTO tab,predicate_text,required_col,mandatory_table;
  IF done_sources=1 THEN LEAVE source_loop; END IF;
  SELECT COUNT(*) INTO present_count FROM information_schema.TABLES
   WHERE TABLE_SCHEMA='prod_cotton_global_0' AND TABLE_NAME=tab AND TABLE_TYPE='BASE TABLE';
  IF present_count=0 THEN
   IF EXISTS(SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA='prod_cotton_global_0' AND TABLE_NAME=tab) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='LEGACY_OBJECT_NOT_BASE_TABLE';
   END IF;
   IF mandatory_table=1 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='LEGACY_TABLE_MISSING'; END IF;
   INSERT INTO hb_capture VALUES(tab,0,SHA2('ABSENT_TABLE',256),SHA2('ABSENT_TABLE',256));
  ELSE
   IF NOT EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA='prod_cotton_global_0' AND TABLE_NAME=tab AND COLUMN_NAME=required_col) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='CAPTURE_FILTER_COLUMN_MISSING';
   END IF;
   SELECT ENGINE,TABLE_COLLATION INTO table_engine,table_collation FROM information_schema.TABLES
    WHERE TABLE_SCHEMA='prod_cotton_global_0' AND TABLE_NAME=tab;
   SELECT COUNT(*),GROUP_CONCAT(CONCAT(ORDINAL_POSITION,':',HEX(COLUMN_NAME),':',HEX(COLUMN_TYPE),':',IS_NULLABLE,':',IFNULL(HEX(COLUMN_DEFAULT),'N'),':',HEX(EXTRA),':',IFNULL(COLLATION_NAME,'N')) ORDER BY ORDINAL_POSITION SEPARATOR '|'),
    GROUP_CONCAT(CONCAT('IF(`',REPLACE(COLUMN_NAME,'`','``'),'` IS NULL,',CHAR(39),'N',CHAR(39),',CONCAT(',CHAR(39),'V',CHAR(39),',SHA2(CAST(`',REPLACE(COLUMN_NAME,'`','``'),'` AS BINARY),256)))') ORDER BY ORDINAL_POSITION SEPARATOR ',')
    INTO col_count,col_defs,exprs FROM information_schema.COLUMNS WHERE TABLE_SCHEMA='prod_cotton_global_0' AND TABLE_NAME=tab;
   SELECT GROUP_CONCAT(CONCAT(HEX(INDEX_NAME),':',SEQ_IN_INDEX,':',NON_UNIQUE,':',IFNULL(HEX(COLUMN_NAME),'N'),':',IFNULL(SUB_PART,'N'),':',INDEX_TYPE) ORDER BY INDEX_NAME,SEQ_IN_INDEX SEPARATOR '|')
    INTO index_defs FROM information_schema.STATISTICS WHERE TABLE_SCHEMA='prod_cotton_global_0' AND TABLE_NAME=tab;
   IF col_count=0 OR exprs IS NULL THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='CAPTURE_COLUMNS_MISSING'; END IF;
   SET schema_digest=SHA2(CONCAT_WS('|',tab,table_engine,IFNULL(table_collation,'N'),col_defs,IFNULL(index_defs,'N')),256);
   DELETE FROM hb_hash_rows;
   SET @hb_sql=CONCAT('INSERT INTO hb_hash_rows SELECT SHA2(CONCAT_WS(',CHAR(39),'|',CHAR(39),',',exprs,'),256) AS rh,COUNT(*) FROM `prod_cotton_global_0`.`',tab,'` WHERE ',predicate_text,' GROUP BY rh');
   PREPARE hb_stmt FROM @hb_sql; EXECUTE hb_stmt; DEALLOCATE PREPARE hb_stmt;
   SET data_digest=SHA2(CONCAT('HB_CAPTURE_V1|',tab,'|',schema_digest),256);
   SET total_rows=0;
   BEGIN
    DECLARE done_rows INT DEFAULT 0;
    DECLARE rh CHAR(64); DECLARE n BIGINT;
    DECLARE row_cursor CURSOR FOR SELECT row_hash,multiplicity FROM hb_hash_rows ORDER BY row_hash;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done_rows=1;
    OPEN row_cursor;
    row_loop: LOOP
     FETCH row_cursor INTO rh,n;
     IF done_rows=1 THEN LEAVE row_loop; END IF;
     SET data_digest=SHA2(CONCAT(data_digest,'|',rh,'|',n),256);
     SET total_rows=total_rows+n;
    END LOOP;
    CLOSE row_cursor;
   END;
   INSERT INTO hb_capture VALUES(tab,total_rows,schema_digest,data_digest);
  END IF;
 END LOOP;
 CLOSE sources_cursor;
END;
SELECT SHA2(GROUP_CONCAT(CONCAT(object_key,':',row_count,':',schema_hash,':',data_hash) ORDER BY object_key SEPARATOR '|'),256)
 INTO @hb_capture_digest FROM hb_capture;

-- Manifest exhaustif, IDs reels mappes par token et contexte en POST.
SELECT e.logical_hub,e.id_session,h.id_client,h.hub_date,h.context_type,h.id_operation_evenement,
 NULL AS `hub_label`,1 AS `flag_active`,'' AS `hub_status`,0 AS `active_session_id`,NULL AS `active_session_activated_at`,0 AS `remote_routing_generation`,'' AS `remote_routing_intent_id`,'' AS `remote_transition_type`,NULL AS `remote_transition_payload_json`,NULL AS `remote_transition_started_at`,NULL AS `presentation_session_id`,CONVERT(0x73657373696f6e USING utf8mb4) AS `presentation_mode`,NULL AS `presentation_updated_at`,'' AS `hub_master_instance_id`,NULL AS `hub_master_instance_seen_at`,'' AS `hub_remote_instance_id`,NULL AS `hub_remote_instance_seen_at`,NULL AS `prizes_initialized_at`,'' AS `delete_operation_token`,'' AS `delete_step`,NULL AS `delete_started_at`,NULL AS `delete_error_at`,NULL AS `date_maj`,NULL AS `player_qr_display_mode`,0 AS `player_qr_display_revision`,NULL AS `player_qr_display_confirmation_json`,NULL AS `player_qr_official_started_at`,
 'AUTO_INCREMENT_AT_WRITE' AS id_rule,'UTC_TIMESTAMP_AT_WRITE' AS date_ajout_rule,
 SHA2(h.token,256) AS future_hub_token_hash,e.signature AS snapshot_session_signature
FROM hb_expected_sessions e JOIN hb_expected_hubs h ON h.logical_hub=e.logical_hub
ORDER BY e.logical_hub,e.id_session;
SELECT object_key,row_count,schema_hash,data_hash FROM hb_capture ORDER BY object_key;
SELECT 'prod_hb_20260908_v1' AS batch_id,@hb_capture_digest AS legacy_pre_post_digest,
 UTC_TIMESTAMP() AS capture_utc;
SELECT 'PRECHECK_OK_REQUIRES_HUMAN_VALIDATION_AND_QUIESCENCE' AS verdict,59 AS hubs,70 AS memberships;

DROP TEMPORARY TABLE hb_capture,hb_hash_rows,hb_sources,hb_expected_sessions,hb_expected_hubs;
END$$
DELIMITER ;
