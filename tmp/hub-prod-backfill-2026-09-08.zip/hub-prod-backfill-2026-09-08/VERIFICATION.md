# Vérification du pack — préparation uniquement

**Aucun SQL exécuté**, même localement. Aucun accès DB/SSH/DEV/PROD, appel PHP, bootstrap, import, déploiement ou modification de code applicatif.

Vérifications effectuées sur les fichiers :

- `python3 verify-pack.py` : PASS.70 sessions uniques,59 groupes disjoints, contexte/client/date/opération concordants, démos et dates antérieures exclues ;34 colonnes cibles ;59 tokens uniques de48 caractères et manifeste concordant.
- Liste fermée des mutations persistantes :20/22 aucune ;21 uniquement INSERT racines puis memberships ;23 uniquement DELETE memberships puis racines. Les DDL sont temporaires ; les SQL dynamiques lisent les sources ou écrivent les tables temporaires de capture. Aucun ALTER/TRUNCATE/CALL, upsert ou bootstrap.
- Garde-fous statiques : paramètres d'écriture bloqués par défaut, contrôle des sources et digest avant mutation, transaction, handlers exception/avertissement, reçu de création obligatoire au rollback.
- Comparateur CSV testé sur données synthétiques : ordre des lignes sans effet ; changement de cardinalité, schéma ou données détecté ; export incomplet ou doublonné refusé. Ces tests ne sont pas des résultats PRE/POST réels.
- Parsing SQLGlot30.18.0, dialecte MySQL, du CTE de conformité et des quatre instructions DML persistantes : sans erreur. Les blocs procéduraux MariaDB et l'import phpMyAdmin n'ont pas été validés par ce parseur ni exécutés.

Reproduire les vérifications sans SQL depuis ce dossier :

```bash
python3 verify-pack.py
```

Les fichiers SQL sont reproductibles avec `python3 build-pack.py` tant que `cohort.json`, `schema-contract.json`, `schema-check.inc.sql` et `hub-tokens.private.json` sont conservés. Ne pas régénérer le fichier de tokens après import. Le générateur n'exécute aucun SQL.

## Risques à valider lors de la revue

Le code SQL vise MariaDB10.3 et emploie des blocs anonymes avec gestion d'erreur. La qualification réelle du serveur/importeur reste nécessaire avant exécution autorisée ; ce résultat est **ready for review**, pas une certification d'exécutabilité PROD.

Les sources MyISAM nécessitent une pause opérateur réelle de toutes les écritures. Les captures font des lectures intégrales des lignes sélectionnées et parfois des scans de tables sans index ; elles évitent les jointures BNL de R02 mais leur coût réel n'a pas été mesuré. Si un fichier ne se termine pas, ne pas utiliser ses résultats partiels comme validation. Aucun index n'est ajouté par ce pack.

Le rollback est volontairement conservateur : tout changement, usage observable, autre Hub ou membership, table auxiliaire remplie, modification legacy ou absence du reçu provoque un refus. L'arrêt opérateur et le contrôle humain couvrent ce qu'une empreinte ne peut établir, notamment un accès sans trace persistante. Il ne répare pas une situation après reprise applicative.

Les empreintes sont une preuve de comparaison des périmètres documentés, pas une sauvegarde restaurable. Le pack conserve les écarts legacy existants. Aucun diagnostic restant sur les états runtime n'est utilisé pour inventer une valeur Hub.
