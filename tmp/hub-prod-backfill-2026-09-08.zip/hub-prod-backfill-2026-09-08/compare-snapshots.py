#!/usr/bin/env python3
"""Compare only exported capture CSVs. No SQL, network or database access."""
import csv
import hashlib
import re
import sys
from pathlib import Path

EXPECTED = set('''championnats_sessions clients operations_evenements
championnats_sessions_lots championnats_sessions_participations_probables
general_branding clients_branding championnats_resultats equipes_to_championnats_sessions
equipes_championnats_sessions_reponses championnats_sessions_participations_games_connectees
jeux_bingo_musical_playlists_clients jeux_bingo_musical_morceaux_to_playlists_clients
championnats_sessions_lots_to_entites_joueurs blindtest_sessions cotton_quiz_sessions
blindtest_players cotton_quiz_players bingo_players bingo_phase_winners game_events'''.split())
FIELDS = ['object_key', 'row_count', 'schema_hash', 'data_hash']


def read_capture(path):
    text = Path(path).read_text(encoding='utf-8-sig')
    dialect = csv.Sniffer().sniff(text[:8192], delimiters=',;\t')
    reader = csv.DictReader(text.splitlines(), dialect=dialect)
    if reader.fieldnames != FIELDS:
        raise ValueError('Export only the capture table, with headers: ' + ','.join(FIELDS))
    rows = {}
    for row in reader:
        key = row['object_key']
        if key in rows or key not in EXPECTED:
            raise ValueError('Duplicate/unexpected object: ' + str(key))
        if not re.fullmatch(r'0|[1-9][0-9]*', row['row_count'] or ''):
            raise ValueError('Invalid count: ' + key)
        if any(not re.fullmatch('[a-f0-9]{64}', row[c] or '') for c in FIELDS[2:]):
            raise ValueError('Invalid hash: ' + key)
        rows[key] = row
    if set(rows) != EXPECTED:
        raise ValueError('Missing objects: ' + ','.join(sorted(EXPECTED - set(rows))))
    return rows


def digest(rows):
    value = '|'.join(':'.join(rows[k][f] for f in FIELDS) for k in sorted(rows))
    return hashlib.sha256(value.encode()).hexdigest()


def main():
    if len(sys.argv) not in (2, 3):
        raise ValueError('Usage: compare-snapshots.py PRE.csv [POST.csv]')
    pre = read_capture(sys.argv[1])
    print('PRE digest:', digest(pre))
    if len(sys.argv) == 3:
        post = read_capture(sys.argv[2])
        changed = [k for k in sorted(EXPECTED) if pre[k] != post[k]]
        print('POST digest:', digest(post))
        if changed:
            print('CHANGED — STOP:', ', '.join(changed))
            return 1
        print('UNCHANGED — 21 object captures identical; not an execution authorization.')
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (ValueError, OSError, csv.Error, TypeError) as error:
        print('INVALID EXPORT — STOP:', error, file=sys.stderr)
        sys.exit(2)
