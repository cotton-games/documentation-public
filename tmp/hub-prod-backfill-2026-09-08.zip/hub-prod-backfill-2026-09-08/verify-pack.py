#!/usr/bin/env python3
"""Offline checks of fixed cohort, mutation surface and CSV comparator. No SQL execution."""
import contextlib
import csv
import hashlib
import io
import json
import re
import runpy
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
c = json.loads((HERE / 'cohort.json').read_text())
tokens = json.loads((HERE / 'hub-tokens.private.json').read_text())
contract = json.loads((HERE / 'schema-contract.json').read_text())
sessions = {int(s['id']): s for s in c['sessions']}
assert len(sessions) == len(c['sessions']) == 70
assert len(c['groups']) == len(tokens) == len(set(tokens.values())) == 59
assert all(re.fullmatch('[a-f0-9]{48}', t) for t in tokens.values())
assert len(contract['games_hubs']['columns']) == 34
seen = set()
for key, members in c['groups'].items():
    client, date, context, event = key.split('|')
    assert members and len(members) == len(set(members))
    assert not seen.intersection(members)
    seen.update(members)
    for sid in members:
        s = sessions[sid]
        assert s['logical_hub'] == key
        assert s['id_client'] == client and s['date'] == date >= '2026-09-08'
        assert s['id_operation_evenement'] == event
        assert s['flag_session_demo'] == '0' and s['flag_configuration_complete'] == '1'
        assert context == ('event' if int(event) else 'soiree')
assert seen == set(sessions)
assert sum('|event|' in k for k in c['groups']) == 2
manifest = list(csv.DictReader((HERE / 'manifest.csv').open()))
assert len(manifest) == 70 and {int(m['session_id']) for m in manifest} == set(sessions)
for m in manifest:
    assert m['hub_token_sha256'] == hashlib.sha256(tokens[m['logical_hub']].encode()).hexdigest()

for number in (20, 21, 22, 23):
    sql = next(HERE.glob(f'{number}-*.sql')).read_text()
    # Only qualified persistent DML; dynamic DML is separately checked below.
    mutations = re.findall(r'(?m)^(INSERT INTO|DELETE [mh] FROM|UPDATE|REPLACE INTO) `prod_cotton_global_0`\.([a-z_]+)', sql)
    assert mutations == {
        20: [], 21: [('INSERT INTO', 'games_hubs'), ('INSERT INTO', 'games_hubs_sessions')],
        22: [], 23: [('DELETE m FROM', 'games_hubs_sessions'), ('DELETE h FROM', 'games_hubs')],
    }[number], (number, mutations)
    assert not re.search(r'(?mi)^\s*(CALL|ALTER|TRUNCATE|CREATE PROCEDURE|CREATE FUNCTION)\b', sql)
    assert len(re.findall(r'(?m)^CREATE TEMPORARY TABLE ', sql)) == 5
    assert 'COHORT_CHANGED_REGENERATE' in sql and 'SOURCE_CHANGED_REGENERATE' in sql
    assert "DECLARE EXIT HANDLER FOR SQLEXCEPTION" in sql and 'RESIGNAL;' in sql
    assert 'SQL_WARNING_ABORTED_INCLUDING_HASH_TRUNCATION' in sql
    if number in (21, 23):
        assert "SET @hb_operator_writes_paused=0;" in sql
        assert "SET @hb_explicit_approval='PENDING_EXPLICIT_APPROVAL';" in sql
        assert sql.index('LEGACY_BASELINE_CHANGED_STOP') < sql.index(mutations[0][0] + ' `prod_cotton_global_0`')
        assert sql.index('START TRANSACTION;') < sql.index(mutations[0][0] + ' `prod_cotton_global_0`') < sql.index('COMMIT;')
    if number == 23:
        assert 'ORIGINAL_COMMIT_RECEIPT_REQUIRED' in sql and 'SET @hb_expected_created_at=NULL;' in sql
    dynamic = re.findall(r"SET @hb_sql=CONCAT\('([^']*)", sql)
    assert dynamic and all(s.startswith(('SELECT GROUP_CONCAT(', 'INSERT INTO hb_hash_rows SELECT ')) for s in dynamic)
print('PASS: fixed70/59 grouping,34-column contract, tokens/manifest, persistent write allowlist, fail-closed defaults.')

compare = runpy.run_path(str(HERE / 'compare-snapshots.py'))
fields = compare['FIELDS']
rows = {k: dict(zip(fields, [k, '0', 'a'*64, 'b'*64])) for k in compare['EXPECTED']}
with tempfile.TemporaryDirectory(prefix='hub-capture-test-', dir='/tmp') as directory:
    path = Path(directory) / 'synthetic.csv'
    def write(values):
        with path.open('w', newline='') as f:
            w = csv.DictWriter(f, fieldnames=fields); w.writeheader(); w.writerows(values)
    write(list(rows.values())[::-1])
    assert compare['read_capture'](path) == rows
    baseline = compare['digest'](rows)
    for field, value in [('row_count', '1'), ('schema_hash', 'c'*64), ('data_hash', 'd'*64)]:
        altered = {k: dict(v) for k,v in rows.items()}
        altered['championnats_sessions'][field] = value
        assert compare['digest'](altered) != baseline
    for bad in [list(rows.values())[:-1], list(rows.values()) + [next(iter(rows.values()))]]:
        write(bad)
        try:
            compare['read_capture'](path)
        except ValueError:
            pass
        else:
            raise AssertionError('Incomplete/duplicate export accepted')
print('PASS: CSV ordering, changed count/schema/data, missing and duplicate capture objects.')
print('NO SQL EXECUTED. Procedural MariaDB syntax/runtime and phpMyAdmin import remain untested.')
