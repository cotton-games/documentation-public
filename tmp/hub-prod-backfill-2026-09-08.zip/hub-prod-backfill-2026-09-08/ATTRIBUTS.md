# Attributs des racines Hub

**34 colonnes couvertes.** Valeurs explicites dans21, sauf ID auto-incrémenté. Le manifeste SQL20/22 fournit les valeurs neutres, clés de contexte et règles des champs générés ; manifest.csv associe chaque session à son groupe et à une empreinte du futur token.

| Colonne | Source | Règle / valeur écrite | Défaut SQL éventuel | Risque |
| --- | --- | --- | --- | --- |
| `id` | AUTO_INCREMENT cible | Omis de INSERT ; récupération par token ET contexte | `AUTO_INCREMENT` | Aucune hypothèse de contiguïté |
| `id_securite` | Générateur cryptographique local, contrat token_generate | 59 tokens fixes uniques de48 caractères hex ; jamais un token legacy | `''` | Conserver le fichier privé et les SQL pour le mapping/rollback |
| `id_client` | Regroupement B01 et session R01 | Compte du regroupement figé, existence vérifiée ;19 clients | `0` | Ne pas déduire depuis le profil courant |
| `hub_date` | Regroupement B01 et date R01 | Date explicite du groupe >=2026-09-08 | `Aucun` | NOT NULL sans DEFAULT : toujours fournie |
| `context_type` | Partition B01 validée | soiree pour57 groupes ; event pour2 groupes | `'day'` | Ne pas utiliser le défaut SQL day |
| `id_operation_evenement` | B01/R01 ; D01 pour événements | 0 pour soirée ;601 ou618 pour événement | `0` | Ne pas confondre id_evenement legacy et id_operation_evenement |
| `hub_label` | Décision de migration minimale ; colonne nullable | NULL pour tous ; aucune sélection arbitraire de nom de session | `NULL` | Le titre reste une projection du lecteur, pas une copie figée |
| `flag_active` | Défaut de racine utilisable du code et schéma | 1 pour tous, y compris événements | `1` | Ce champ ne porte pas la confidentialité du compte |
| `hub_status` | Défaut neutre du code et schéma | Chaîne vide '' ; aucun statut de jeu déduit | `''` | Ne pas traduire privé/offline en statut Hub |
| `active_session_id` | Défaut du schéma initial vérifié | 0 ; aucun bootstrap ni état runtime projeté | `0` | Ne pas inventer de focus, présence, routing, transition, suppression ou confirmation QR |
| `active_session_activated_at` | Défaut du schéma initial vérifié | NULL ; aucun bootstrap ni état runtime projeté | `NULL` | Ne pas inventer de focus, présence, routing, transition, suppression ou confirmation QR |
| `remote_routing_generation` | Défaut du schéma initial vérifié | 0 ; aucun bootstrap ni état runtime projeté | `0` | Ne pas inventer de focus, présence, routing, transition, suppression ou confirmation QR |
| `remote_routing_intent_id` | Défaut du schéma initial vérifié | '' ; aucun bootstrap ni état runtime projeté | `''` | Ne pas inventer de focus, présence, routing, transition, suppression ou confirmation QR |
| `remote_transition_type` | Défaut du schéma initial vérifié | '' ; aucun bootstrap ni état runtime projeté | `''` | Ne pas inventer de focus, présence, routing, transition, suppression ou confirmation QR |
| `remote_transition_payload_json` | Défaut du schéma initial vérifié | NULL ; aucun bootstrap ni état runtime projeté | `NULL` | Ne pas inventer de focus, présence, routing, transition, suppression ou confirmation QR |
| `remote_transition_started_at` | Défaut du schéma initial vérifié | NULL ; aucun bootstrap ni état runtime projeté | `NULL` | Ne pas inventer de focus, présence, routing, transition, suppression ou confirmation QR |
| `presentation_session_id` | Défaut du schéma initial vérifié | NULL ; aucun bootstrap ni état runtime projeté | `NULL` | Ne pas inventer de focus, présence, routing, transition, suppression ou confirmation QR |
| `presentation_mode` | Défaut du schéma | 'session', avec presentation_session_id=NULL | `'session'` | Mode par défaut sans focus de session |
| `presentation_updated_at` | Défaut du schéma initial vérifié | NULL ; aucun bootstrap ni état runtime projeté | `NULL` | Ne pas inventer de focus, présence, routing, transition, suppression ou confirmation QR |
| `hub_master_instance_id` | Défaut du schéma initial vérifié | '' ; aucun bootstrap ni état runtime projeté | `''` | Ne pas inventer de focus, présence, routing, transition, suppression ou confirmation QR |
| `hub_master_instance_seen_at` | Défaut du schéma initial vérifié | NULL ; aucun bootstrap ni état runtime projeté | `NULL` | Ne pas inventer de focus, présence, routing, transition, suppression ou confirmation QR |
| `hub_remote_instance_id` | Défaut du schéma initial vérifié | '' ; aucun bootstrap ni état runtime projeté | `''` | Ne pas inventer de focus, présence, routing, transition, suppression ou confirmation QR |
| `hub_remote_instance_seen_at` | Défaut du schéma initial vérifié | NULL ; aucun bootstrap ni état runtime projeté | `NULL` | Ne pas inventer de focus, présence, routing, transition, suppression ou confirmation QR |
| `prizes_initialized_at` | Défaut nullable ; migration sans lots Hub | NULL ; games_hubs_prizes reste vide | `NULL` | Préserve le fallback legacy ; aucune initialisation proclamée |
| `delete_operation_token` | Défaut du schéma initial vérifié | '' ; aucun bootstrap ni état runtime projeté | `''` | Ne pas inventer de focus, présence, routing, transition, suppression ou confirmation QR |
| `delete_step` | Défaut du schéma initial vérifié | '' ; aucun bootstrap ni état runtime projeté | `''` | Ne pas inventer de focus, présence, routing, transition, suppression ou confirmation QR |
| `delete_started_at` | Défaut du schéma initial vérifié | NULL ; aucun bootstrap ni état runtime projeté | `NULL` | Ne pas inventer de focus, présence, routing, transition, suppression ou confirmation QR |
| `delete_error_at` | Défaut du schéma initial vérifié | NULL ; aucun bootstrap ni état runtime projeté | `NULL` | Ne pas inventer de focus, présence, routing, transition, suppression ou confirmation QR |
| `date_ajout` | Horloge SQL UTC lors de21 | Un UTC_TIMESTAMP commun aux59 Hubs et70 memberships | `Aucun` | NOT NULL sans DEFAULT ; conserver le reçu UTC |
| `date_maj` | Défaut nullable du schéma | NULL ; racine créée sans mise à jour métier | `NULL` | Diffère du helper get_or_create qui remplit NOW ; aucune activation déduite |
| `player_qr_display_mode` | Défaut du schéma initial vérifié | NULL ; aucun bootstrap ni état runtime projeté | `NULL` | Ne pas inventer de focus, présence, routing, transition, suppression ou confirmation QR |
| `player_qr_display_revision` | Défaut du schéma initial vérifié | 0 ; aucun bootstrap ni état runtime projeté | `0` | Ne pas inventer de focus, présence, routing, transition, suppression ou confirmation QR |
| `player_qr_display_confirmation_json` | Défaut du schéma initial vérifié | NULL ; aucun bootstrap ni état runtime projeté | `NULL` | Ne pas inventer de focus, présence, routing, transition, suppression ou confirmation QR |
| `player_qr_official_started_at` | Défaut du schéma initial vérifié | NULL ; aucun bootstrap ni état runtime projeté | `NULL` | Ne pas inventer de focus, présence, routing, transition, suppression ou confirmation QR |

## Provenance contrôlable

- Contrat complet : [schema-contract.json](schema-contract.json), issu du pack schéma initial13 tables. Chaque colonne porte son fichier et sa ligne source.
- Racine et defaults : [app_games_hubs_functions.php](/home/romain/Cotton/global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:185). Tokens : [token_generate](/home/romain/Cotton/global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:568). Aucun helper appelé par le pack.
- Colonnes QR : [app_games_hub_player_qr_functions.php](/home/romain/Cotton/global/web/app/modules/jeux/hubs/app_games_hub_player_qr_functions.php:10).
- Création applicative de référence : [get_or_create](/home/romain/Cotton/global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:2428). La migration reprend les défauts neutres du schéma ; date_maj reste NULL.
- Lots : [prizes_get](/home/romain/Cotton/global/web/app/modules/jeux/hubs/app_games_hubs_functions.php:3697). Pas de ligne Hub ni de marker initialized ; aucun lot choisi automatiquement.
- Cohorte : retour opérateur B01/D01 du08/09 et R01 détaillé fourni, conservés sous forme [cohort.json](cohort.json). Les instructions sont celles de la demande explicite et de ses compléments ; les exports SQL sont des preuves de données, jamais des commandes à exécuter.

## Deux Hubs événementiels — source exacte

| Compte | Date Hub | Contexte/opération | Sessions | Événement D01 conservé | Attributs Hub |
| --- | --- | --- | --- | --- | --- |
|2436|2026-09-26|event /601|29622,29623|demo=0 ; privé=1 ; online=0 ; dates début/fin2026-09-26|label=NULL ; active=1 ; status=chaîne vide|
|2459|2026-09-12|event /618|30126,30127|demo=0 ; privé=1 ; online=0 ; dates début/fin2026-09-12|label=NULL ; active=1 ; status=chaîne vide|

Le PRE compare les10 champs D01 disponibles (ID, compte, dates, noms, slug, trois flags) et le PRE/POST capture toutes les colonnes des deux événements. Aucun attribut de visibilité événementielle n’est recopié dans le Hub. Selon la clarification utilisateur, la publication sur les pages publiques hors lien dépend du compte client ; ses colonnes restent intactes et sont empreintées. Aucun write dans games_hubs_publication.

## Memberships —7 colonnes

| Colonne | Source / valeur | Protection |
| --- | --- | --- |
|id|AUTO_INCREMENT, omis|Aucune arithmétique sur les IDs|
|id_hub|Hub créé retrouvé par token unique et clé de contexte exacte|Aucun premier résultat arbitraire|
|id_session|ID explicite R01 du manifeste|PK temporaire,70 IDs, contrôle global rattachement unique|
|membership_source|prod_hb_20260908_v1|Marqueur strict exigé par POST et rollback|
|status|'active'|Rattachement actif ; aucun statut runtime|
|created_at|Même UTC_TIMESTAMP que les racines|Égalité contrôlée et reçu21 conservé|
|updated_at|NULL|Aucune modification métier annoncée|

**Aucune décision d’attribut restante. La disponibilité réelle du schéma et la conformité du PRE sont des préconditions d’exécution, non des faits acquis.**
