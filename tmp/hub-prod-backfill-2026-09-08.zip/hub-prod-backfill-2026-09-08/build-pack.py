#!/usr/bin/env python3
"""Offline generator. No SQL execution and no database/network connection."""
import csv
import hashlib
import json
import re
import secrets
from pathlib import Path

HERE = Path(__file__).resolve().parent
DB = 'prod_cotton_global_0'
BATCH = 'prod_hb_20260908_v1'
cohort = json.loads((HERE / 'cohort.json').read_text())
contract = json.loads((HERE / 'schema-contract.json').read_text())
sessions = sorted(cohort['sessions'], key=lambda x: int(x['id']))
groups = dict(sorted(cohort['groups'].items()))
assert len(sessions) == 70 and len(groups) == 59
assert len({x['id'] for x in sessions}) == 70
assert all(x['flag_session_demo'] == '0' and x['date'] >= '2026-09-08'
           and x['flag_configuration_complete'] == '1' for x in sessions)
assert sorted(i for ids in groups.values() for i in ids) == [int(x['id']) for x in sessions]

def lit(value):
    if value is None:
        return 'NULL'
    # All text is encoded as a hex literal: independent of escaping/sql_mode.
    return "CONVERT(0x" + str(value).encode().hex() + " USING utf8mb4)" if str(value) else "''"

def ids(values):
    return ','.join(str(int(v)) for v in sorted(set(map(int, values)))) or '-1'

SIDS = ids(x['id'] for x in sessions)
CLIENTS = ids(x['id_client'] for x in sessions)
NETWORKS = ids(x['id_client_reseau'] for x in sessions if int(x['id_client_reseau']) > 0)
ALL_CLIENTS = ids([x['id_client'] for x in sessions] +
                  [x['id_client_reseau'] for x in sessions if int(x['id_client_reseau']) > 0])
BINGO_PRODUCTS = ids(x['id_produit'] for x in sessions if x['id_type_produit'] in ('3', '6'))
tokenfile = HERE / 'hub-tokens.private.json'
tokens = json.loads(tokenfile.read_text()) if tokenfile.exists() else {
    key: secrets.token_hex(24) for key in groups
}
assert set(tokens) == set(groups) and len(set(tokens.values())) == 59
assert all(re.fullmatch('[a-f0-9]{48}', x) for x in tokens.values())
tokenfile.write_text(json.dumps(tokens, indent=2) + '\n')
tokenfile.chmod(0o600)
HUB_TOKENS = ','.join(lit(tokens[k]) for k in groups)

# All 30 named session fields transmitted by R01, not current client profiles.
FIELDS = ['id','id_client','date','heure_debut','heure_fin','id_operation_evenement',
          'id_evenement','flag_session_demo','flag_configuration_complete','id_offre_client',
          'id_type_produit','id_produit','id_format','flag_controle_numerique','lot_ids',
          'community_item_id','id_championnat_saison','flag_session_finale','flag_session_privee',
          'flag_session_weblive','online','position','nb_joueurs_max','nom','nom_court',
          'lot_1','lot_2','lot_3','date_ajout','date_maj']
NULLABLE = {'lot_1','lot_2','lot_3','lot_ids','community_item_id'}

def signature(row):
    values = [('N' if row[c] == 'NULL' and c in NULLABLE else row[c].encode().hex().upper()) for c in FIELDS]
    return hashlib.sha256('|'.join(values).encode()).hexdigest()

LIVE_SIGNATURE = "SHA2(CONCAT_WS('|'," + ','.join(
    f"IFNULL(HEX(CAST(s.`{c}` AS BINARY)),'N')" for c in FIELDS) + '),256)'

hub_defaults = {
    'hub_label': None, 'flag_active': 1, 'hub_status': '',
    'active_session_id': 0, 'active_session_activated_at': None,
    'remote_routing_generation': 0, 'remote_routing_intent_id': '',
    'remote_transition_type': '', 'remote_transition_payload_json': None,
    'remote_transition_started_at': None, 'presentation_session_id': None,
    'presentation_mode': 'session', 'presentation_updated_at': None,
    'hub_master_instance_id': '', 'hub_master_instance_seen_at': None,
    'hub_remote_instance_id': '', 'hub_remote_instance_seen_at': None,
    'prizes_initialized_at': None, 'delete_operation_token': '', 'delete_step': '',
    'delete_started_at': None, 'delete_error_at': None, 'date_maj': None,
    'player_qr_display_mode': None, 'player_qr_display_revision': 0,
    'player_qr_display_confirmation_json': None, 'player_qr_official_started_at': None,
}
assert set(hub_defaults) | {'id','id_securite','id_client','hub_date','context_type',
                            'id_operation_evenement','date_ajout'} == {
    c['name'] for c in contract['games_hubs']['columns']}

def val(v):
    return str(v) if isinstance(v, int) else lit(v)

schema_sql = (HERE / 'schema-check.inc.sql').read_text()
# Extract just the schema query (the outer scripts reinitialize the variable).
schema_query = schema_sql[re.search(r'\bWITH\s', schema_sql).start():].strip()

setup = f"""
-- Noms reserves a cette connexion ; connexion neuve apres tout echec.
CREATE TEMPORARY TABLE hb_expected_sessions (
 id_session INT UNSIGNED PRIMARY KEY, logical_hub VARCHAR(100) NOT NULL,
 signature CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL
) ENGINE=InnoDB;
CREATE TEMPORARY TABLE hb_expected_hubs (
 logical_hub VARCHAR(100) PRIMARY KEY, token CHAR(48) CHARACTER SET ascii COLLATE ascii_bin UNIQUE,
 id_client INT UNSIGNED NOT NULL, hub_date DATE NOT NULL, context_type VARCHAR(16) NOT NULL,
 id_operation_evenement INT UNSIGNED NOT NULL,
 UNIQUE (id_client,hub_date,context_type,id_operation_evenement)
) ENGINE=InnoDB;
INSERT INTO hb_expected_sessions VALUES
""" + ',\n'.join(f"({x['id']},{lit(x['logical_hub'])},{lit(signature(x))})" for x in sessions) + ';\n'
setup += 'INSERT INTO hb_expected_hubs VALUES\n' + ',\n'.join(
    f"({lit(k)},{lit(tokens[k])},{int(k.split('|')[0])},{lit(k.split('|')[1])},"
    f"{lit(k.split('|')[2])},{int(k.split('|')[3])})" for k in groups) + ';\n'
setup += """
CREATE TEMPORARY TABLE hb_sources (
 table_name VARCHAR(64) PRIMARY KEY, predicate_sql LONGTEXT NOT NULL,
 required_column VARCHAR(64) NOT NULL, mandatory TINYINT NOT NULL
) ENGINE=InnoDB;
CREATE TEMPORARY TABLE hb_hash_rows (
 row_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin PRIMARY KEY,
 multiplicity BIGINT UNSIGNED NOT NULL
) ENGINE=InnoDB;
CREATE TEMPORARY TABLE hb_capture (
 object_key VARCHAR(64) PRIMARY KEY, row_count BIGINT UNSIGNED NOT NULL,
 schema_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 data_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL
) ENGINE=InnoDB;
"""

# SIGNAL MESSAGE_TEXT expects a simple_value_specification, not an expression.
def check(test, message):
    assert re.fullmatch('[A-Z0-9_ :.-]+', message)
    return f"IF {test} THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='{message}'; END IF;\n"

cohort_checks = check('(SELECT COUNT(*) FROM hb_expected_sessions)<>70 OR (SELECT COUNT(*) FROM hb_expected_hubs)<>59', 'INVALID_PACK_COUNTS')
cohort_checks += check(f"(SELECT COUNT(*) FROM `{DB}`.championnats_sessions WHERE flag_session_demo=0 AND date>='2026-09-08')<>70", 'COHORT_CHANGED_REGENERATE')
cohort_checks += check(f"EXISTS(SELECT 1 FROM hb_expected_sessions e LEFT JOIN `{DB}`.championnats_sessions s ON s.id=e.id_session WHERE s.id IS NULL OR NOT(BINARY e.signature <=> BINARY {LIVE_SIGNATURE}))", 'SOURCE_CHANGED_REGENERATE')
cohort_checks += check(f"EXISTS(SELECT 1 FROM hb_expected_hubs e LEFT JOIN `{DB}`.clients c ON c.id=e.id_client WHERE c.id IS NULL)", 'CLIENT_MISSING')
cohort_checks += check(f"EXISTS(SELECT 1 FROM hb_expected_sessions s LEFT JOIN hb_expected_hubs h ON h.logical_hub=s.logical_hub WHERE h.logical_hub IS NULL)", 'MANIFEST_ORPHAN')
cohort_checks += check(f"EXISTS(SELECT 1 FROM `{DB}`.championnats_sessions WHERE id IN ({SIDS}) AND (id_securite IS NULL OR TRIM(id_securite)=''))", 'LEGACY_TOKEN_MISSING')
for e in cohort['events']:
    evfields = ['id','id_client','date_debut','date_fin','nom','nom_court','seo_slug',
                'flag_evenement_demo','flag_evenement_prive','online']
    predicates = ' AND '.join(f"BINARY CAST(`{c}` AS CHAR) <=> BINARY {lit(e[c])}" for c in evfields)
    cohort_checks += check(f"(SELECT COUNT(*) FROM `{DB}`.operations_evenements WHERE {predicates})<>1", 'EVENT_CHANGED_REGENERATE')

aux_tables = [t for t in contract if t not in ('games_hubs','games_hubs_sessions')]
aux_checks = ''.join(check(f"(SELECT COUNT(*) FROM `{DB}`.`{t}`)<>0", 'HUB_OR_QUICK_ACTIVITY_PRESENT') for t in aux_tables)
empty_checks = ''.join(check(f"(SELECT COUNT(*) FROM `{DB}`.`{t}`)<>0", 'ALREADY_RUN_OR_HUB_COLLISION') for t in ('games_hubs','games_hubs_sessions')) + aux_checks

# Each persistent capture is a single-table SELECT with fixed scalar lists.
# Optional table absence is itself captured and compared, never treated as empty.
source_rows = [
 ('championnats_sessions', f'id IN ({SIDS})', 'id', 1),
 ('clients', f'id IN ({ALL_CLIENTS})', 'id', 1),
 ('operations_evenements', 'id IN (601,618)', 'id', 1),
 ('championnats_sessions_lots', f'id_championnat_session IN ({SIDS})','id_championnat_session',1),
 ('championnats_sessions_participations_probables', f'id_championnat_session IN ({SIDS})','id_championnat_session',1),
 ('general_branding', f'(id_type_branding=1 AND id_related IN ({SIDS})) OR (id_type_branding=2 AND id_related IN (601,618)) OR (id_type_branding=3 AND id_related IN ({NETWORKS})) OR (id_type_branding=4 AND id_related IN ({ALL_CLIENTS})) OR id_type_branding=5','id_related',1),
 ('clients_branding', f'id_client IN ({ALL_CLIENTS}) OR id_operation_evenement IN (601,618)','id_client',1),
 ('championnats_resultats', f'id_championnat_session IN ({SIDS})','id_championnat_session',1),
 ('equipes_to_championnats_sessions', f'id_championnat_session IN ({SIDS})','id_championnat_session',1),
 ('equipes_championnats_sessions_reponses', f'id_championnat_session IN ({SIDS})','id_championnat_session',1),
 ('championnats_sessions_participations_games_connectees', f'id_championnat_session IN ({SIDS})','id_championnat_session',1),
 ('jeux_bingo_musical_playlists_clients', f'id IN ({BINGO_PRODUCTS})','id',1),
 ('jeux_bingo_musical_morceaux_to_playlists_clients', f'id_playlist_client IN ({BINGO_PRODUCTS})','id_playlist_client',1),
]
sources_setup = 'DELETE FROM hb_sources;\nINSERT INTO hb_sources VALUES\n' + ',\n'.join(
    '('+','.join([lit(t),lit(p),lit(c),str(m)])+')' for t,p,c,m in source_rows) + ';\n'
sources_setup += f"""
-- Tokens are used only inside this connection and are not exported.
SELECT GROUP_CONCAT(CONCAT('CONVERT(0x',HEX(TRIM(id_securite)),' USING utf8mb4)') ORDER BY id SEPARATOR ',')
 INTO @hb_legacy_tokens FROM `{DB}`.championnats_sessions WHERE id IN ({SIDS});
SELECT GROUP_CONCAT(CAST(id AS CHAR) ORDER BY id SEPARATOR ',') INTO @hb_lot_ids
 FROM `{DB}`.championnats_sessions_lots WHERE id_championnat_session IN ({SIDS});
SET @hb_lot_ids=COALESCE(@hb_lot_ids,'-1');
SET @hb_sql=CONCAT('SELECT GROUP_CONCAT(CONCAT(CHAR(39),id,CHAR(39)) ORDER BY id SEPARATOR ',CHAR(39),',',CHAR(39),') INTO @hb_bt_ids FROM `{DB}`.blindtest_sessions WHERE session_id IN (',@hb_legacy_tokens,')');
PREPARE hb_stmt FROM @hb_sql; EXECUTE hb_stmt; DEALLOCATE PREPARE hb_stmt;
SET @hb_sql=CONCAT('SELECT GROUP_CONCAT(CONCAT(CHAR(39),id,CHAR(39)) ORDER BY id SEPARATOR ',CHAR(39),',',CHAR(39),') INTO @hb_quiz_ids FROM `{DB}`.cotton_quiz_sessions WHERE session_id IN (',@hb_legacy_tokens,')');
PREPARE hb_stmt FROM @hb_sql; EXECUTE hb_stmt; DEALLOCATE PREPARE hb_stmt;
SET @hb_bt_ids=COALESCE(@hb_bt_ids,{lit("'__HB_NO_RUNTIME__'")});
SET @hb_quiz_ids=COALESCE(@hb_quiz_ids,{lit("'__HB_NO_RUNTIME__'")});
INSERT INTO hb_sources VALUES
 ('championnats_sessions_lots_to_entites_joueurs',CONCAT('id_lot IN (',@hb_lot_ids,')'),'id_lot',1),
 ('blindtest_sessions',CONCAT('session_id IN (',@hb_legacy_tokens,')'),'session_id',1),
 ('cotton_quiz_sessions',CONCAT('session_id IN (',@hb_legacy_tokens,')'),'session_id',1),
 ('blindtest_players',CONCAT('session_id IN (',@hb_bt_ids,')'),'session_id',0),
 ('cotton_quiz_players',CONCAT('session_id IN (',@hb_quiz_ids,')'),'session_id',0),
 ('bingo_players',CONCAT('session_id IN (',@hb_legacy_tokens,')'),'session_id',0),
 ('bingo_phase_winners',CONCAT('session_id IN (',@hb_legacy_tokens,')'),'session_id',0),
 ('game_events',CONCAT('session_id IN (',@hb_legacy_tokens,',',{lit(HUB_TOKENS)},')'),'session_id',0);
"""

# Preserve every column, including unknown additions to the legacy snapshots.
# Row hashes and multiplicities form a deterministic multiset; no XOR/CRC shortcut.
capture = f"""
BEGIN
 DECLARE done_sources INT DEFAULT 0;
 DECLARE tab VARCHAR(64); DECLARE predicate_text LONGTEXT;
 DECLARE required_col VARCHAR(64); DECLARE mandatory_table INT;
 DECLARE present_count INT; DECLARE col_count INT;
 DECLARE col_defs LONGTEXT; DECLARE index_defs LONGTEXT; DECLARE exprs LONGTEXT;
 DECLARE table_engine VARCHAR(64); DECLARE table_collation VARCHAR(64);
 DECLARE schema_digest CHAR(64); DECLARE data_digest CHAR(64); DECLARE total_rows BIGINT;
 DECLARE sources_cursor CURSOR FOR SELECT table_name,predicate_sql,required_column,mandatory FROM hb_sources ORDER BY table_name;
 DECLARE CONTINUE HANDLER FOR NOT FOUND SET done_sources=1;
 DELETE FROM hb_capture;
 OPEN sources_cursor;
 source_loop: LOOP
  FETCH sources_cursor INTO tab,predicate_text,required_col,mandatory_table;
  IF done_sources=1 THEN LEAVE source_loop; END IF;
  SELECT COUNT(*) INTO present_count FROM information_schema.TABLES
   WHERE TABLE_SCHEMA='{DB}' AND TABLE_NAME=tab AND TABLE_TYPE='BASE TABLE';
  IF present_count=0 THEN
   IF EXISTS(SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA='{DB}' AND TABLE_NAME=tab) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='LEGACY_OBJECT_NOT_BASE_TABLE';
   END IF;
   IF mandatory_table=1 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='LEGACY_TABLE_MISSING'; END IF;
   INSERT INTO hb_capture VALUES(tab,0,SHA2('ABSENT_TABLE',256),SHA2('ABSENT_TABLE',256));
  ELSE
   IF NOT EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA='{DB}' AND TABLE_NAME=tab AND COLUMN_NAME=required_col) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='CAPTURE_FILTER_COLUMN_MISSING';
   END IF;
   SELECT ENGINE,TABLE_COLLATION INTO table_engine,table_collation FROM information_schema.TABLES
    WHERE TABLE_SCHEMA='{DB}' AND TABLE_NAME=tab;
   SELECT COUNT(*),GROUP_CONCAT(CONCAT(ORDINAL_POSITION,':',HEX(COLUMN_NAME),':',HEX(COLUMN_TYPE),':',IS_NULLABLE,':',IFNULL(HEX(COLUMN_DEFAULT),'N'),':',HEX(EXTRA),':',IFNULL(COLLATION_NAME,'N')) ORDER BY ORDINAL_POSITION SEPARATOR '|'),
    GROUP_CONCAT(CONCAT('IF(`',REPLACE(COLUMN_NAME,'`','``'),'` IS NULL,',CHAR(39),'N',CHAR(39),',CONCAT(',CHAR(39),'V',CHAR(39),',SHA2(CAST(`',REPLACE(COLUMN_NAME,'`','``'),'` AS BINARY),256)))') ORDER BY ORDINAL_POSITION SEPARATOR ',')
    INTO col_count,col_defs,exprs FROM information_schema.COLUMNS WHERE TABLE_SCHEMA='{DB}' AND TABLE_NAME=tab;
   SELECT GROUP_CONCAT(CONCAT(HEX(INDEX_NAME),':',SEQ_IN_INDEX,':',NON_UNIQUE,':',IFNULL(HEX(COLUMN_NAME),'N'),':',IFNULL(SUB_PART,'N'),':',INDEX_TYPE) ORDER BY INDEX_NAME,SEQ_IN_INDEX SEPARATOR '|')
    INTO index_defs FROM information_schema.STATISTICS WHERE TABLE_SCHEMA='{DB}' AND TABLE_NAME=tab;
   IF col_count=0 OR exprs IS NULL THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='CAPTURE_COLUMNS_MISSING'; END IF;
   SET schema_digest=SHA2(CONCAT_WS('|',tab,table_engine,IFNULL(table_collation,'N'),col_defs,IFNULL(index_defs,'N')),256);
   DELETE FROM hb_hash_rows;
   SET @hb_sql=CONCAT('INSERT INTO hb_hash_rows SELECT SHA2(CONCAT_WS(',CHAR(39),'|',CHAR(39),',',exprs,'),256) AS rh,COUNT(*) FROM `{DB}`.`',tab,'` WHERE ',predicate_text,' GROUP BY rh');
   PREPARE hb_stmt FROM @hb_sql; EXECUTE hb_stmt; DEALLOCATE PREPARE hb_stmt;
   SET data_digest=SHA2(CONCAT('HB_CAPTURE_V1|',tab,'|',schema_digest),256);
   SET total_rows=0;
   BEGIN
    DECLARE done_rows INT DEFAULT 0;
    DECLARE rh CHAR(64); DECLARE n BIGINT;
    DECLARE row_cursor CURSOR FOR SELECT row_hash,multiplicity FROM hb_hash_rows ORDER BY row_hash;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done_rows=1;
    OPEN row_cursor;
    row_loop: LOOP
     FETCH row_cursor INTO rh,n;
     IF done_rows=1 THEN LEAVE row_loop; END IF;
     SET data_digest=SHA2(CONCAT(data_digest,'|',rh,'|',n),256);
     SET total_rows=total_rows+n;
    END LOOP;
    CLOSE row_cursor;
   END;
   INSERT INTO hb_capture VALUES(tab,total_rows,schema_digest,data_digest);
  END IF;
 END LOOP;
 CLOSE sources_cursor;
END;
SELECT SHA2(GROUP_CONCAT(CONCAT(object_key,':',row_count,':',schema_hash,':',data_hash) ORDER BY object_key SEPARATOR '|'),256)
 INTO @hb_capture_digest FROM hb_capture;
"""

neutral_mismatch = ' OR '.join(
    f'NOT(BINARY h.`{c}` <=> BINARY {val(v)})' if isinstance(v,str)
    else f'NOT(h.`{c}` <=> {val(v)})' for c,v in hub_defaults.items())
post_checks = check(f"(SELECT COUNT(*) FROM `{DB}`.games_hubs)<>59 OR (SELECT COUNT(*) FROM `{DB}`.games_hubs_sessions)<>70", 'TARGET_COUNTS_MISMATCH')
post_checks += check(f"EXISTS(SELECT 1 FROM hb_expected_hubs e LEFT JOIN `{DB}`.games_hubs h ON BINARY h.id_securite=BINARY e.token WHERE h.id IS NULL OR h.id_client<>e.id_client OR h.hub_date<>e.hub_date OR BINARY h.context_type<>BINARY e.context_type OR h.id_operation_evenement<>e.id_operation_evenement OR {neutral_mismatch})", 'HUB_ATTRIBUTES_OR_MAPPING_MISMATCH')
post_checks += check(f"EXISTS(SELECT 1 FROM hb_expected_sessions e JOIN hb_expected_hubs eh ON eh.logical_hub=e.logical_hub JOIN `{DB}`.games_hubs h ON BINARY h.id_securite=BINARY eh.token LEFT JOIN `{DB}`.games_hubs_sessions m ON m.id_hub=h.id AND m.id_session=e.id_session WHERE m.id IS NULL OR BINARY m.membership_source<>BINARY '{BATCH}' OR BINARY m.status<>BINARY 'active' OR m.updated_at IS NOT NULL OR NOT(m.created_at <=> h.date_ajout))", 'MEMBERSHIP_MISMATCH')
post_checks += check(f"EXISTS(SELECT id_session FROM `{DB}`.games_hubs_sessions GROUP BY id_session HAVING COUNT(*)<>1)", 'SESSION_MULTIPLE_MEMBERSHIPS')
post_checks += check(f"(SELECT COUNT(DISTINCT date_ajout) FROM `{DB}`.games_hubs)<>1 OR EXISTS(SELECT 1 FROM `{DB}`.games_hubs WHERE date_ajout IS NULL OR YEAR(date_ajout)=0)", 'CREATION_TIMESTAMP_MISMATCH')
post_checks += aux_checks

def header(mode):
    return f"""-- {BATCH} / {mode}. PREPARATION UNIQUEMENT, AUCUNE AUTORISATION PROD.
-- Importer le fichier ENTIER dans une connexion dediee ; phpMyAdmin doit
-- reconnaitre DELIMITER et BEGIN NOT ATOMIC (MariaDB 10.3).
-- Aucune execution SQL, meme locale, effectuee lors de la preparation.
-- Sources MyISAM : arret operateur de TOUTES les ecritures applicatives/CRON
-- de PRE jusqu'au POST et decision de rollback ; pas de deploiement entre eux.
-- Ne pas utiliser les anciens fichiers10/11/12/13 pour cette phase.
SET NAMES utf8mb4;
SET SESSION time_zone='+00:00';
SET SESSION group_concat_max_len=1048576;
SET @cotton_hub_schema_issues=NULL;
SET @hb_capture_digest=NULL;
"""

def block(body, cleanup=True):
    return """DELIMITER $$
BEGIN NOT ATOMIC
 DECLARE hb_lock_acquired INT DEFAULT 0;
 DECLARE EXIT HANDLER FOR SQLEXCEPTION
 BEGIN
  ROLLBACK;
  IF hb_lock_acquired=1 THEN DO RELEASE_LOCK('cotton_prod_hb_20260908_v1'); END IF;
  RESIGNAL;
 END;
 DECLARE EXIT HANDLER FOR SQLWARNING
 BEGIN
  ROLLBACK;
  IF hb_lock_acquired=1 THEN DO RELEASE_LOCK('cotton_prod_hb_20260908_v1'); END IF;
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='SQL_WARNING_ABORTED_INCLUDING_HASH_TRUNCATION';
 END;
""" + body + "\nDROP TEMPORARY TABLE hb_capture,hb_hash_rows,hb_sources,hb_expected_sessions,hb_expected_hubs;\nEND$$\nDELIMITER ;\n"

schema_guard = schema_query + '\n' + check('COALESCE(@cotton_hub_schema_issues,1)<>0', 'TARGET_SCHEMA_MISMATCH')
common = schema_guard + '\n' + setup + '\n' + cohort_checks
manifest_output = f"""
-- Manifest exhaustif, IDs reels mappes par token et contexte en POST.
SELECT e.logical_hub,e.id_session,h.id_client,h.hub_date,h.context_type,h.id_operation_evenement,
 {','.join(val(v)+' AS `'+k+'`' for k,v in hub_defaults.items())},
 'AUTO_INCREMENT_AT_WRITE' AS id_rule,'UTC_TIMESTAMP_AT_WRITE' AS date_ajout_rule,
 SHA2(h.token,256) AS future_hub_token_hash,e.signature AS snapshot_session_signature
FROM hb_expected_sessions e JOIN hb_expected_hubs h ON h.logical_hub=e.logical_hub
ORDER BY e.logical_hub,e.id_session;
SELECT object_key,row_count,schema_hash,data_hash FROM hb_capture ORDER BY object_key;
SELECT '{BATCH}' AS batch_id,@hb_capture_digest AS legacy_pre_post_digest,
 UTC_TIMESTAMP() AS capture_utc;
"""
pre_body = common + empty_checks + sources_setup + capture + manifest_output
pre_body += "SELECT 'PRECHECK_OK_REQUIRES_HUMAN_VALIDATION_AND_QUIESCENCE' AS verdict,59 AS hubs,70 AS memberships;\n"
(HERE/'20-hub-backfill-precheck.sql').write_text(header('PRECHECK') + block(pre_body))

approval = """
-- Remplacer seulement APRES PRECHECK et validation humaine explicite.
SET @hb_approved_pre_digest='PENDING_PRE_REVIEW';
SET @hb_operator_writes_paused=0;
SET @hb_explicit_approval='PENDING_EXPLICIT_APPROVAL';
"""
approval_checks = check("NOT(COALESCE(@hb_approved_pre_digest,'') REGEXP '^[a-f0-9]{64}$')", 'PRE_DIGEST_REQUIRED')
approval_checks += check(f"NOT(COALESCE(@hb_explicit_approval,'')='{BATCH}') OR COALESCE(@hb_operator_writes_paused,0)<>1", 'EXPLICIT_APPROVAL_AND_WRITE_PAUSE_REQUIRED')
acquire = "SELECT GET_LOCK('cotton_prod_hb_20260908_v1',5) INTO hb_lock_acquired;\n" + check('COALESCE(hb_lock_acquired,0)<>1', 'BACKFILL_LOCK_UNAVAILABLE')
begin_tx = "SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;\nSTART TRANSACTION;\n"
begin_tx += f"SELECT COUNT(*) INTO @hb_lock_h FROM `{DB}`.games_hubs FOR UPDATE;\nSELECT COUNT(*) INTO @hb_lock_m FROM `{DB}`.games_hubs_sessions FOR UPDATE;\n"
baseline_check = check("NOT(BINARY @hb_capture_digest <=> BINARY @hb_approved_pre_digest)", 'LEGACY_BASELINE_CHANGED_STOP')

columns = ['id_securite','id_client','hub_date','context_type','id_operation_evenement'] + list(hub_defaults) + ['date_ajout']
root_values = ['e.token','e.id_client','e.hub_date','e.context_type','e.id_operation_evenement'] + [val(v) for v in hub_defaults.values()] + ['@hb_created_at']
insert_sql = f"""
-- SEULES DEUX ECRITURES METIER DU BACKFILL. AUCUN UPSERT/IGNORE.
SET @hb_created_at=UTC_TIMESTAMP();
INSERT INTO `{DB}`.games_hubs ({','.join('`'+c+'`' for c in columns)})
 SELECT {','.join(root_values)} FROM hb_expected_hubs e ORDER BY e.logical_hub;
""" + check('ROW_COUNT()<>59','HUB_INSERT_COUNT_MISMATCH') + f"""
-- Aucun LAST_INSERT_ID ni hypothese sur les IDs consecutifs.
INSERT INTO `{DB}`.games_hubs_sessions
 (id_hub,id_session,membership_source,status,created_at,updated_at)
 SELECT h.id,e.id_session,'{BATCH}','active',@hb_created_at,NULL
 FROM hb_expected_sessions e JOIN hb_expected_hubs eh ON eh.logical_hub=e.logical_hub
 JOIN `{DB}`.games_hubs h ON h.id_securite=eh.token
  AND h.id_client=eh.id_client AND h.hub_date=eh.hub_date
  AND h.context_type=eh.context_type AND h.id_operation_evenement=eh.id_operation_evenement
 ORDER BY e.id_session;
""" + check('ROW_COUNT()<>70','MEMBERSHIP_INSERT_COUNT_MISMATCH')

write_body = approval_checks + acquire + common + begin_tx + empty_checks
write_body += sources_setup + capture + baseline_check + insert_sql + post_checks
write_body += cohort_checks + sources_setup + capture + baseline_check
write_body += "COMMIT;\nDO RELEASE_LOCK('cotton_prod_hb_20260908_v1'); SET hb_lock_acquired=0;\n"
write_body += f"SELECT '{BATCH}' AS batch_id,'BACKFILL_COMMITTED_REQUIRES_POSTCHECK' AS verdict,@hb_created_at AS created_at_utc;\n"
(HERE/'21-hub-backfill.sql').write_text(header('BACKFILL') + approval + block(write_body))

post_config = "SET @hb_approved_pre_digest='PENDING_PRE_REVIEW';\n"
post_body = common + post_checks + sources_setup + capture + manifest_output
post_body += check("NOT(COALESCE(@hb_approved_pre_digest,'') REGEXP '^[a-f0-9]{64}$')", 'PRE_DIGEST_REQUIRED_FOR_POST_VERDICT') + baseline_check
post_body += f"SELECT e.logical_hub,e.id_session,h.id AS actual_hub_id,m.id AS actual_membership_id,h.date_ajout\nFROM hb_expected_sessions e JOIN hb_expected_hubs eh ON eh.logical_hub=e.logical_hub JOIN `{DB}`.games_hubs h ON BINARY h.id_securite=BINARY eh.token JOIN `{DB}`.games_hubs_sessions m ON m.id_hub=h.id AND m.id_session=e.id_session ORDER BY e.id_session;\n"
post_body += "SELECT 'POSTCHECK_OK_59_70_LEGACY_UNCHANGED' AS verdict;\n"
(HERE/'22-hub-backfill-postcheck.sql').write_text(header('POSTCHECK') + post_config + block(post_body))

# Only safe before deployment/usage; any observed activity or divergence refuses.
rollback_body = approval_checks + acquire + common + begin_tx + post_checks
rollback_body += check("@hb_expected_created_at IS NULL OR EXISTS(SELECT 1 FROM `prod_cotton_global_0`.games_hubs WHERE NOT(BINARY CAST(date_ajout AS CHAR) <=> BINARY @hb_expected_created_at))", 'ORIGINAL_COMMIT_RECEIPT_REQUIRED')
rollback_body += sources_setup + capture + baseline_check
rollback_body += f"""
DELETE m FROM `{DB}`.games_hubs_sessions m
 JOIN `{DB}`.games_hubs h ON h.id=m.id_hub
 JOIN hb_expected_hubs eh ON BINARY eh.token=BINARY h.id_securite
 JOIN hb_expected_sessions e ON e.id_session=m.id_session AND e.logical_hub=eh.logical_hub
 WHERE BINARY m.membership_source=BINARY '{BATCH}';
""" + check('ROW_COUNT()<>70','ROLLBACK_MEMBERSHIP_COUNT_MISMATCH')
rollback_body += f"DELETE h FROM `{DB}`.games_hubs h JOIN hb_expected_hubs eh ON BINARY eh.token=BINARY h.id_securite;\n" + check('ROW_COUNT()<>59','ROLLBACK_HUB_COUNT_MISMATCH')
rollback_body += empty_checks + cohort_checks + sources_setup + capture + baseline_check
rollback_body += "COMMIT;\nDO RELEASE_LOCK('cotton_prod_hb_20260908_v1'); SET hb_lock_acquired=0;\nSELECT 'ROLLBACK_OK_ONLY_59_HUBS_70_MEMBERSHIPS_REMOVED' AS verdict;\n"
(HERE/'23-hub-backfill-rollback.sql').write_text(header('ROLLBACK_AVANT_USAGE_SEULEMENT') + approval + "SET @hb_expected_created_at=NULL; -- Copier created_at_utc du recu de21.\n" + block(rollback_body))

with (HERE/'manifest.csv').open('w', newline='') as f:
    w=csv.writer(f);w.writerow(['logical_hub','session_id','snapshot_signature','hub_token_sha256'])
    for x in sessions:
        w.writerow([x['logical_hub'],x['id'],signature(x),hashlib.sha256(tokens[x['logical_hub']].encode()).hexdigest()])

print('Generated 20/21/22/23, 59 fixed tokens and 70 manifest entries. NO SQL EXECUTED.')
