# Roadmap & Journal des Travaux — Cotton

Ce document trace l'évolution du projet AI Studio, les tâches accomplies et la vision à moyen terme. Il sert de "mémoire" à la cascade de déploiement, et alimente le badge de suivi du tenant dans **AI Studio Admin** (`ai_studio_admin/hub/modules/dashboard/index.php`, fonction `get_tenant_roadmap_summary()`).

> [!IMPORTANT]
> **Nomenclature commune Modulo+ (stub canonique : `ai_studio_starter_kit/documentation/general/0_ROADMAP.md`).** Chaque entrée doit préciser la **date de mise en DEV**, la **date de mise en PROD**, et les **chemins complets des fichiers modifiés**.
>
> **Règles de parsing (ne pas dévier) :**
> - Titres de section en `##` (niveau 2), contenant le mot-clé quelque part sur la ligne (emoji cosmétique, non requis par la regex) : `EN COURS`/`En cours` → compteur "en cours" ; `TODO`/`À faire`/`Backlog` → compteur "todo".
> - Fin de section = prochain titre `##` suivant. Les sous-titres `###` (priorité, mois...) n'interrompent pas la section, ils sont ignorés par le parseur.
> - Sous `EN COURS` : items en `#### JJ/MM/AAAA > environnement (module/source) > sujet`, suivi d'une description.
> - Sous `TODO` : items en `- [ ] Description` exactement — seules les cases **non cochées** sont comptées (les `- [x]` ne remontent jamais, volontairement).
> - Une ligne strictement égale à `Tâche 1 : Description` (stub du starter kit) est ignorée.
> - Le compteur dans le titre (`## 📋 TODO — 28`) est une convention documentaire pour la lecture humaine — pas utilisé par le parseur.

---

## 🔧 EN COURS

#### 28/08/2026 > dev (ai_studio + www) > Campagne Rentrée "Coup d'Envoi" — finalisation avant lancement du 01/09
Stratégie, séquence newsletters (4 phases) et landing page dédiée développées en juillet ; Phase 1 Teasing publiée en PROD le 18-19/08. Entre le 21/08 et le 28/08 : tarif corrigé à 49€ (était 49,90€) sur newsletters + LP, liens espace organisateur réglés, LP restructurée suite à une revue externe de l'email Lancement (CTA remonté, preuve sociale identifiée comme manquante, widget photos, note de prix sous le CTA hero, fonctions extraites dans un fichier dédié). **Rien de tout ça n'est en PROD** — tout est en LOCAL, à pousser sur GitHub puis déployer (liste complète des fichiers dans `Fait, livré en PROD` ci-dessous). Reste à trancher avant le 01/09 : configuration tarifaire réelle côté produit, preuve sociale de l'email Lancement (actuellement absente), décision sur un éventuel décalage de date liée à l'interface de programmation de soirée. Détail dans `## 📋 TODO` ci-dessous et dans `Fait, livré en PROD`.

---

## 📋 TODO — 28

### 🔴 CRITIQUE
- [ ] **Pousser sur GitHub puis déployer en PROD** l'ensemble des fichiers LOCAL listés dans l'entrée `[DEV : 21-28/08/2026]` ci-dessous (`www/lp/lp.php` + 2 nouveaux fichiers `lp/includes/`, tarif 49€ sur toutes les newsletters, correctifs de chemin roadmap côté Hub) — rien de tout ça n'est en PROD à ce stade.
- [ ] Trancher la preuve sociale manquante dans l'email Lancement INS (chiffre ou verbatim, sinon décision consciente de lancer sans)
- [ ] Configurer le tarif abonnement Cotton à 49€ (corrigé le 21/08, était 49,90€) pour la fenêtre 01/09→22/09, repasser à 69,90€ après — **investigation du 21/08 : pas de config admin/BDD, prix codé en dur** dans `global/app/modules/ecommerce/widget/app_ecommerce_bloc_offre_tarifaire_abn.php` (tier `value => 50` "Chill", `prices.mensuel.ht/ttc`), utilisé à la fois par la LP et par le vrai tunnel de souscription (`pro/ec/modules/ecommerce/offres/`) qui facture ce montant tel quel — donc changer ce fichier change le prix réellement facturé, pas juste l'affichage. Fichiers à garder synchronisés : `fo/fo_products.php` (flux Google Merchant Center) et probablement `app_ecommerce_functions.php` (`app_ecommerce_tarifs_reference_get_segment()`). Décision de Régis (21/08) : ce changement doit être fait par un développeur via le circuit habituel, pas modifié à la volée — prévoir soit un prix fixe à repasser manuellement après le 22/09, soit une bascule automatique par date.
- [ ] Publier l'article ROI ("Combien rapporte une soirée quiz un mardi creux ?") et mettre à jour son lien dans les 3 emails Preuve Sociale concernés
- [ ] Compléter le lien "communauté" (espace organisateur) dans l'email Preuve Sociale ABN du 10/09 — lien "planning" (Lancement) réglé le 21/08 (`https://pro.cotton-quiz.com/extranet/games`) ; lien "nouveautés" retiré du Lancement, la page dashboard correspondante étant vide (contenu commenté depuis 2024, route morte — voir `pro/ec/modules/communication/actualites/ec_actualites_list.php`)
- [ ] Créer les campagnes Brevo de la séquence Rentrée (envoi manuel décidé — voir `PRET-A-ENVOYER.md` de chaque phase)
- [ ] Diagnostiquer l'erreur n8n HTTP 500 (credentials Brevo expirés ? workflow désactivé ? template ID 563 supprimé ?)
- [ ] Ré-importer `ai_studio_emails_transactional_workflow_n8n.json` dans n8n (active les tags Brevo)
- [ ] Vérifier le webhook Brevo dans Brevo Manager (Settings → Webhooks, Bearer token)
- [ ] Tester le flux complet leads P0 : formulaire Hub → n8n → BDD → CRON → email J0
- [ ] Activer les ~20 leads Cotton dans Hub (status='active', date_envoi_J0=demain) et vérifier l'envoi J0
- [ ] Vérifier le tracking Brevo (diodes J0/J+7/J+14 dans Hub après ouverture d'un email)

### 🟠 HIGH
- [ ] Valider un run scraping v2.5 sur une commune ≥ 100k habitants (sans crash, < 5 min)
- [ ] Réimporter les données Toulouse (run Apify précédent) via `apify_datasets_reimport.php`
- [ ] `NODE_OPTIONS=--max-old-space-size=4096` côté serveur n8n (à voir avec l'admin serveur)
- [ ] Développer le workflow n8n Open Data Gouv (SIRENE multi-établissements, sans Serper en Phase 1)
- [ ] Ajouter Serper.dev pour l'enrichissement email Open Data Gouv (Phase 2)
- [ ] Construire un dashboard métriques leads (taux ouverture/clic/rebond par campagne)
- [ ] Séparer `facebook_url` / `instagram_url` du champ `site_web` (leads)
- [ ] Connecter le Hub aux workflows d'exécution n8n et valider le flux Google Maps end-to-end
- [ ] Étendre le tracking Brevo (`opened_at`/`clicked_at`) à l'ensemble du flux transactionnel classique (`clients_emails_transactionnels_logs` — INS, ABN, etc.)
- [ ] Concevoir le chantier UI Reporting/KPI de conversion dans AI Studio (une fois le tracking étendu)

### 🟡 LOW
- [ ] Tester l'endpoint webhook Brevo manuellement depuis le Hub
- [ ] Construire la vue planning campagnes (`hub/modules/leads/planning.php`)
- [ ] Ajouter une signature HMAC au webhook Brevo (sécurité renforcée)
- [ ] Générer une démo personnalisée Cotton pour les leads avec `client_style_musical`
- [ ] Développer les pages Features #6 Options de jeux, #7 Lots, #8 Espace joueur & statistiques (+ MAJ #5 Design) — cascade page → newsletter → réseaux sociaux
- [ ] Revoir le bandeau cookies (tarteaucitron) + GTM + retargeting
- [ ] Connecter le Hub aux workflows d'exécution n8n pour le suivi des données de playlists (CRON data)

---

## 📅 Fait, livré en PROD

### Août 2026

*   **[DEV : 21-28/08/2026] [PROD : —, à déployer] ai_studio + www > Campagne Rentrée "Coup d'Envoi" — correctif tarif, liens, et refonte de l'email Lancement + LP**
    *   *Fichiers créés :*
        - `www/lp/includes/widget/lp_widget_bloc_offre_photos.php`
        - `www/lp/includes/lp_functions.php`
        - `global/ai_studio/automatisations/writing/newsletters/2026-09/02-lancement/2026-09-01--coup-denvoi-offre/newsletter_V0.md`, `newsletter_V1.md`, `PRET-A-ENVOYER_V0.md`, `PRET-A-ENVOYER_V1.md`, `PRET-A-ENVOYER_V2.md`, `PRET-A-ENVOYER_V3.md`
    *   *Fichiers modifiés :*
        - `www/lp/lp.php` — bug corrigé sur le lien `tel:` (codé en dur, indépendant de la variable de téléphone)
        - `global/ai_studio/automatisations/writing/newsletters/2026-09/PLAN-RENTREE-2026-2027.md`
        - `global/ai_studio/automatisations/writing/newsletters/2026-09/RESUME-CAMPAGNE.md`
        - `global/ai_studio/automatisations/writing/newsletters/2026-09/02-lancement/2026-09-01--coup-denvoi-offre/newsletter.md`, `PRET-A-ENVOYER.md`, `gmb_post.md` — CSO/P0/ABN pas encore harmonisés avec la nouvelle structure INS
        - `global/ai_studio/automatisations/writing/newsletters/2026-09/03-preuve-sociale/2026-09-10--preuve-sociale/PRET-A-ENVOYER.md`, `newsletter.md`, `blog_article.md`
        - `global/ai_studio/automatisations/writing/newsletters/2026-09/04-urgence/2026-09-17--urgence-j5/PRET-A-ENVOYER.md`, `newsletter.md`
        - `global/ai_studio/automatisations/writing/newsletters/2026-09/04-urgence/2026-09-22--urgence-dernier-jour/PRET-A-ENVOYER.md`, `newsletter.md`, `gmb_post.md`
        - `global/ai_studio/documentation/general/0_ROADMAP.md`, `1_SOP_Methodologie_Cascade.md`, `2_PRD_cotton_quiz_presentation_generale.md`, `global/ai_studio/documentation/client/modulo_ai_studio_points_a_reprendre.md`
        - `global/ai_studio/hub/modules/dashboard/index.php`, `global/ai_studio/hub/includes/footer.php`, `global/ai_studio/hub/api/public_reader.php`
    *   *Description :*
        Tarif corrigé à 49€ (était 49,90€) sur l'ensemble des newsletters et la LP, avec précision "HT" et "Jeux illimités". Tarif réel non configurable en admin/BDD : codé en dur dans `global/app/modules/ecommerce/widget/app_ecommerce_bloc_offre_tarifaire_abn.php` (non modifié — à faire par un développeur, cf. TODO). LP restructurée (bullets section 2, mention version papier, CTA final personnalisable, widget photos, note de prix sous le CTA hero, fonctions extraites). Revue externe (Claude Design) de l'email Lancement le 26/08 : structure jugée trop "lettre d'info" — email INS restructuré sur plusieurs itérations (CTA au-dessus de la ligne de flottaison, bénéfice concret en titre, bullets, prix net). Point ouvert non résolu : la preuve sociale a disparu des dernières versions de l'email INS sans décision explicite.
        ⚠️ Aucun de ces fichiers n'est en PROD à ce stade (Régis a signalé avoir écrasé `lp.php` avec la version PROD le 26/08, qui affichait encore 49,90€ à ce moment).

---

*   **[DEV : 17-20/08/2026] [PROD : 18-19/08/2026] ai_studio + www > Campagne Rentrée "Coup d'Envoi" — Phase 1 Teasing (article blog + post GMB)**
    *   *Fichiers créés :*
        - `global/ai_studio/automatisations/writing/newsletters/2026-09/01-teasing/2026-08-18--teasing-public/blog_article.md` (+ historique `blog_article_V0.md` à `V4.md`)
        - `global/ai_studio/automatisations/writing/newsletters/2026-09/01-teasing/2026-08-18--teasing-public/gmb_post.md` (+ `gmb_post_V0.md`)
    *   *Description :*
        Article evergreen "En septembre, coup d'envoi de la nouvelle saison dans votre bar" (5 itérations : fil "saison sportive" → mode Championnat de Cotton comme argument central + version intemporelle + bloc metas → ton retravaillé, moins publireportage → relecture manuelle finale de Régis → FAQ 5 questions avec données structurées `FAQPage`) + post GMB/réseaux aligné sur le même fil narratif, sans offre commerciale.
        ✅ Publié : article sur [`/fr/actualites/conseils/coup-envoi-nouvelle-saison-bar`](https://www.cotton-quiz.com/fr/actualites/conseils/coup-envoi-nouvelle-saison-bar), post GMB publié.

---

### Juillet 2026

*   **[DEV : 14-16/07/2026] [PROD : partiel — LP en ligne, envois pas encore déclenchés] ai_studio + www > Campagne Rentrée "Coup d'Envoi Saison 2026-2027" — Stratégie, séquence newsletters (4 phases), landing page dédiée**
    *   *Fichiers créés :*
        - `global/ai_studio/automatisations/writing/newsletters/2026-09/PLAN-RENTREE-2026-2027.md`, `RESUME-CAMPAGNE.md`
        - `global/ai_studio/automatisations/writing/newsletters/2026-09/02-lancement/2026-09-01--coup-denvoi-offre/` (`newsletter.md`, `PRET-A-ENVOYER.md`, `gmb_post.md`)
        - `global/ai_studio/automatisations/writing/newsletters/2026-09/03-preuve-sociale/2026-09-10--preuve-sociale/` (`newsletter.md`, `PRET-A-ENVOYER.md`, `blog_article.md` — article ROI)
        - `global/ai_studio/automatisations/writing/newsletters/2026-09/04-urgence/2026-09-17--urgence-j5/` et `2026-09-22--urgence-dernier-jour/` (`newsletter.md`, `PRET-A-ENVOYER.md`, `gmb_post.md`)
        - `global/ai_studio/automatisations/writing/ETAT-DES-LIEUX-AUTOMATISATION-CONTENU.md`
        - `www/lp/images/campaign/coup-denvoi-saison/section-01.jpg`
    *   *Fichiers modifiés :*
        - `www/lp/lp.php` — nouveau `case 'coup-denvoi-saison'`
        - `www/.htaccess` — règle de réécriture `/lp/fr/coup-denvoi-saison`
        - `global/ai_studio/automatisations/writing/newsletters/auto_profile.json` — widget groupé "Rentrée 2026-2027"
        - `global/ai_studio/hub/modules/automatisations/index.php` — support des groupes dans le widget `content_browser` (rétrocompatible)
    *   *Description :*
        Plan de communication pour la période de plus haute saison (sept.-janv.), 4 segments (80 ABN, 297 INS, 251 CSO, 1500 P0) soit 2128 contacts. Offre "Coup d'Envoi" : 49,90€/mois au lieu de 69,90€, sans engagement, du 1er au 22 septembre — tarif public, pas de code promo.
        Fil narratif : la rentrée comme coup d'envoi d'une "saison", avec le mode Championnat de Cotton (déjà commercialisé en avril sous un autre angle) comme preuve produit de l'argument fidélisation, et la personnalisation des contenus comme différenciateur concurrentiel.
        4 phases, cadence différenciée par segment (P0 : 3 touches max avec un email dédié en Preuve Sociale ; ABN : aucune offre). Convention revue : un seul `newsletter.md` par campagne avec sections par segment (au lieu de fichiers "bloc additionnel"), plus un `PRET-A-ENVOYER.md` par campagne prêt à copier-coller dans Brevo.
        Décision (16/08) : envoi **manuel dans Brevo**, pas via le pipeline `webhook.php` → n8n existant (jamais déclenché, format incompatible avec la structure multi-segment) — état des lieux du chantier d'automatisation posé dans `ETAT-DES-LIEUX-AUTOMATISATION-CONTENU.md` pour reprise ultérieure hors deadline.
        Landing page `coup-denvoi-saison` : déclinaison unique, réutilise ~90% de la LP evergreen `saison-hiver`, couleur différenciée (`#FF0040`) du violet `#582AFF` de toutes les autres LP — pour ne pas ressembler à `offre-essai`, déjà vue 3× par les P0 au printemps.

---

### Juin 2026

*   **[DEV : 18/06/2026] [PROD : 29/06/2026] www > Création des 3 pages portail jeux (Blind Test, Bingo Musical, Cotton Quiz) + refonte menu "Les jeux" + mise en avant calendrier annuel**
    *   *Fichiers créés :*
        - `www/fo/modules/jeux/blind_test/fr/fo_blind_test_portail_index.php`
        - `www/fo/modules/jeux/bingo_musical/fr/fo_bingo_musical_portail_index.php`
        - `www/fo/modules/jeux/cotton_quiz/fr/fo_cotton_quiz_portail_index.php`
    *   *Fichiers modifiés :*
        - `www/fo/modules/jeux/portail/fr/fo_portail_seo.php`
        - `www/fo/includes/header/fo_header_main.php` (refonte dropdown "Les jeux")
        - `www/fo/modules/widget/fr/fo_widget_cotton_agenda.php`
    *   *Description :*
        3 pages portail jeux (`/fr/jeux/cotton-blind-test`, `/fr/jeux/bingo-musical`, `/fr/jeux/cotton-quiz`), structure commune en 5 sections (Hero, Concept, Aperçu catalogue, Widget agenda, CTA final). Menu "Les jeux" simplifié à 3 entrées + entrée séparée "Calendrier des jeux de l'année" (`/fr/jeux/animation-annee`).
        Pages restantes à finaliser : portail Joueurs, portail À propos.

---

*   **[DEV : 11/06/2026] [PROD : 11/06/2026] ai_studio > Newsletter Anniversaire Juin (3.1) — Refonte complète, envoyée aux segments INS/CSO/P0**
    *   *Fichiers modifiés :*
        - `global/ai_studio/automatisations/writing/newsletters/2026-06-09--anniversaire-juin/newsletter.md`
        - `global/ai_studio/automatisations/writing/newsletters/2026-06-09--anniversaire-juin/newsletter_INS_CSO_P0_bloc_offre.md`
        - `global/ai_studio/automatisations/writing/newsletters/2026-06-09--anniversaire-juin/newsletter_ABN_bloc_retour_experience.md`
    *   *Description :*
        Envoyée le 11/06 à 15h à INS/CSO/P0 (ABN non inclus). Angle "communauté" (photos de soirées Cotton) plutôt qu'un calendrier froid. Corps commun autour de 3 dates : 11 juin (Journée du Jeu + coup d'envoi Coupe du Monde), 21 juin (Fête de la Musique, nouvelles playlists été), 28 juin (5 ans de Cotton).
        Offre INS/CSO/P0 : **49€/mois au lieu de 69€**, valable jusqu'au 30 juin. Bloc ABN (retour d'expérience) mis à jour mais non envoyé à cette date.

---

*   **[DEV : 04/06/2026] [PROD : 10/06/2026] ai_studio > Leads — Refonte anti-OOM scraping (v2.5), enrichissement email auto, UI 3 niveaux**
    *   *Fichiers créés :*
        - `global/ai_studio/automatisations/leads_acquisition/scrapping_google_maps/ai_studio_scrapping_google_maps_workflow_n8n__v2.5.json`
    *   *Fichiers modifiés :*
        - `.../ai_studio_scrapping_google_maps_workflow_n8n__v2.3.json` (renommé v2.3.0_PROD_20260608), `__v2.4.json` (renommé v2.4.0, archivé)
        - `global/ai_studio/hub/api/api_gouv_fr_geo_import_communes.php`, `scraping_google_maps_queue_process.php`, `leads_email_enrichment.php`
        - `global/ai_studio/hub/modules/leads/index.php`, `strategie.php`
        - `global/ai_studio/automatisations/leads_acquisition/README.md` (fusion 2 README en 1) + `scrapping_google_maps/README.md`
    *   *Description :*
        **Diagnostic OOM grandes villes :** scraping Toulouse (474 résultats) plantait sur le HTTP GET de récupération HTML (n8n garde tout en RAM). Cause : email scraping fait *dans* n8n + nœuds Split/Merge incompatibles.
        **Workflow v2.5 (PROD) :** suppression complète du scraping HTTP et des nœuds Merge/Split côté n8n (13 nœuds supprimés) — n8n ne fait plus que Apify → filtres → dédoublonnage → email GMB natif → scoring → webhook PHP. Exécution 2-4 min, sans OOM. Enrichissement email délégué au Hub PHP par batches contrôlés.
        **Hub Leads :** cellule email à 3 niveaux (enrichir / Facebook / Instagram / recherche Google), bouton "Enrichir tout" (batches de 10, anti-cycle infini).

---

### Mai 2026

*   **[DEV : 21/05/2026] [PROD : 26/05/2026] ai_studio > Newsletter Coupe du Monde 2026 — Version unique toute base + Article blog + Post GMB**
    *   *Fichiers créés :*
        - `global/ai_studio/automatisations/writing/newsletters/2026-05-19--nos-bars-imagination/newsletter_V1.3.md`, `blog_article.md`, `gmb_post.md`
    *   *Description :*
        Version unique pour toute la base (INS, CSO, ABN + particuliers, entreprises). Angle principal : Coupe du Monde 2026 (coup d'envoi 11 juin) — 3 formats Cotton. Angle secondaire "contre-programme" pour les bars ne diffusant pas les matchs.
        Article blog : [Coupe du Monde 2026 : 3 façons d'animer vos soirées](https://www.cotton-quiz.com/fr/actualites/evenementiel/coupe-du-monde-3-facons-d-animer-vos-soirees-meme-pour-ceux-qui-n-aiment-pas-le-foot).

---

*   **[DEV : 04/05/2026] [PROD : —] ai_studio > Amélioration Hub Leads (formulaire, tableau, filtres) & Fix Tags Tracking Brevo**
    *   *Fichiers modifiés :*
        - `global/ai_studio/hub/modules/leads/index.php`
        - `global/ai_studio/automatisations/crm/emails_transactional/ai_studio_emails_transactional_cron_routine.php`, `ai_studio_emails_transactional_webhook.php`, `ai_studio_emails_transactional_workflow_n8n.json`
        - `global/global_librairies.php`
    *   *Description :*
        **Formulaire Hub Leads :** champs manquants ajoutés (adresse, commune, téléphone, site web, contact, campaign_id, date_envoi_J0, priorité, lead_score, dirigeant), organisé en sections.
        **Tableau :** colonnes Ville/Score/Priorité/Statut inline modifiables (AJAX, CSRF), Date J0, lien Maps, filtres, doc "Règles de gestion".
        **CRON P0 :** suppression du patch temporaire, remplacé par `$TEST_OVERRIDE_EMAIL` propre (aucun log en mode test).
        **Fix tags Brevo :** tags `lead_{ID}` absents du payload → ajoutés (`webhook.php` + `workflow_n8n.json`, ré-import n8n requis) — sans ça, aucune remontée opens/clicks possible.

---

### Avril 2026

*   **[DEV : 29/04/2026] [PROD : —] ai_studio > Finalisation automatisation leads A-Z (scraping → BDD → CRON → Brevo)**
    *   *Fichiers créés :*
        - `global/ai_studio/hub/modules/leads/scraping.php`
        - `global/ai_studio/automatisations/leads_acquisition/scrapping_google_maps/ai_studio_scrapping_google_maps_workflow_n8n.json`
        - `global/ai_studio/automatisations/leads_acquisition/SCRAPING_DOCUMENTATION.md`
    *   *Fichiers modifiés :*
        - `global/ai_studio/automatisations/crm/emails_transactional/ai_studio_emails_transactional_cron_routine.php`
        - `global/ai_studio/automatisations/leads_acquisition/ai_studio_leads_acquisition_webhook.php`
        - `global/ai_studio/hub/core/config.php` + `config.local_DEV.php` + `config.local_PROD.php`
        - `global/ai_studio/hub/modules/leads/index.php`, `hub_engine.php`
    *   *Description :*
        Scraping par département (1 campagne = 1 `campaign_id`), Apify seul pour Google Maps (pas de Serper en Phase 1), réponse n8n immédiate, `date_envoi_J0` préservée sur upsert, blacklist réseaux/PMU/tabac, filtrage catégorie + score ≥ 3.5.

---

*   **[DEV : 18/04/2026] [PROD : 18/04/2026] ai_studio > Intégration du Suivi Brevo (Webhooks) & Protection Anti-Doublons P0**
    *   *Fichiers modifiés :*
        - `global/ai_studio/workflows/crm/emails_transactional/ai_studio_emails_transactional_brevo_webhook.php` (nouveau)
        - `global/ai_studio/workflows/crm/emails_transactional/ai_studio_emails_transactional_cron_routine.php`
        - `global/ai_studio/workflows/leads_acquisition/ai_studio_leads_acquisition_create_table.sql`
    *   *Description :* Webhook sécurisé Bearer Token pour intercepter lecture/clic/bounces Brevo. Colonnes `opened_at`/`clicked_at`/`bounced_at` ajoutées. CRON : rejet automatique (`status='rejected'`) des leads P0 déjà présents dans `clients_contacts`.

---

*   **[DEV : 15/04/2026] [PROD : —] ai_studio > Humanisation & Finalisation des Newsletters "Espace Joueur & Stats" (Avril)**
    *   *Fichiers modifiés :*
        - `global/ai_studio/workflows/writing/newsletters/2026-04-22--espace-joueur-stats/newsletter_INS.md`, `newsletter_CSO.md`, `newsletter_ABN.md`
    *   *Description :* Re-lecture critique pour supprimer le ton "IA" et les clichés. Focus fidélisation, championnats par trimestre, données Espace Joueur comme levier de conversion.

---

*   **[DEV : 07/04/2026] [PROD : 07/04/2026] www > Test baseline A/B/C homepage & optimisation tracking GTM/Matomo**
    *   *Fichiers modifiés :* `web/fo/fo.php`, `web/fo/modules/communication/home/fr/fo_home_index.php`
    *   *Description :* Ajout baseline C, persistance cookie 30 jours, variable `version_AB` dans le `dataLayer` GTM (segmentation GA4), tracking Matomo centralisé sur tous les CTAs home.

---

*   **[DEV : 03/04/2026] [PROD : 11/04/2026] ai_studio > Stratégie & Rédaction de la Campagne de Communication Q2 2026**
    *   *Description :* Plan multicanal jusqu'à fin juin 2026. 11 fichiers de newsletters (variantes INS/CSO/ABN, envois d'avril). Focus gain de temps, Espace Joueur, communauté, Anniversaire 5 ans (offre été -50%). Rédaction terminée le 09/04/2026.

*   **[DEV : 03/04/2026] [PROD : —] ai_studio > Travail de réécriture des 3 emails P0**
    *   *Fichiers modifiés :*
        - `global/ai_studio/workflows/crm/emails_transactional/ai_studio_emails_transactional_templates.php`
        - `web/lp/lp.php`, `web/lp/includes/css/lp_custom.css`
        - `web/fo/modules/communication/home/fr/fo_home_index.php`
        - `web/fo/modules/communication/statique/fr/fo_statique_features_presentation_generale.php`

---

### Mars 2026

*   **[DEV : 30/03/2026] [PROD : 02/04/2026] www > Déploiement et Interconnexion des Pages Features (5 pages)**
    *   *Fichiers modifiés :*
        - `web/fo/modules/communication/statique/fr/fo_statique_features_{bibliotheque_themes,programmation_automatisation,experience_joueur,scores_classements,design_branding,presentation_generale}.php`
        - `web/fo/modules/communication/statique/fr/fo_statique_seo.php`, `fo_statique_cible_reseaux_franchises.php`, `fo_statique_cible_bars.php`, `fo_statique_joueurs_portal.php`, `fo_statique_about_portal.php`
        - `web/.htaccess`, `web/fo/fo_sitemap.php`, `web/fo/includes/header/fo_header_main.php`, `web/fo/modules/jeux/sessions/fr/fo_sessions_view.php`, `fo_sessions_list_bloc.php`
    *   *Description :* Création des 4 pages features suivantes (après #1 Bibliothèque) : #2 Programmation, #3 Expérience Joueur, #4 Scores & classements, #5 Design/Branding. Navigation séquentielle "Suivant/Précédent". Page "Réseaux" enrichie de blocs vers ces features.

---

*   **[DEV : 25/03/2026] [PROD : 25/03/2026] ai_studio + pro + global ecommerce > Professionnalisation & Intégration des Emails Transactionnels**
    *   *Fichiers modifiés :*
        - `global/ai_studio/workflows/crm/emails_transactional/ai_studio_emails_transactional_templates.php`, `ai_studio_emails_transactional_functions.php`
        - `pro/ec/modules/compte/authentification/ec_authentification_script.php`, `pro/ec/modules/compte/client_contacts/ec_client_contacts_script.php`
        - `global/app/modules/ecommerce/app_ecommerce_functions.php`
    *   *Description :* Architecture de génération des codes (`PIPELINE_TYPOLOGIE_ACTION`) pour les cas génériques. Migration des appels Brevo vers le système centralisé.

*   **[DEV : 25/03/2026] [PROD : 25/03/2026] ai_studio > Harmonisation Documentation & Mode RAW pour IA**
    *   *Fichiers modifiés :*
        - `global/ai_studio/documentation/ai_studio_documentation_view.php`, `1_SOP_Methodologie_Cascade.md`
        - `global/ai_studio/hub/hub_engine.php`, `js/hub_core.js`
    *   *Description :* Visionneuse en mode RAW filtré pour les agents IA. Standardisation des footers de date.

---

*   **[DEV : 18/03/2026] [PROD : —] ai_studio > Initialisation du module Scrapping & Acquisition de Leads**
    *   *Fichiers modifiés :*
        - `global/ai_studio/workflows/leads_acquisition/ai_studio_leads_acquisition_webhook.php`, `ai_studio_leads_acquisition_create_table.sql`
    *   *Description :* Plan d'architecture publié, base de données de stockage des leads mise en place.

---

*   **[DEV : 15/03/2026] [PROD : 17/03/2026] www > Déploiement de la communication sur la feature #1 "Bibliothèque de thèmes"**
    *   *Fichiers modifiés :* `web/fo/modules/communication/statique/fr/fo_statique_features_bibliotheque_themes.php`
    *   *Description :* Page de vente feature #1 + newsletter + communication réseaux sociaux (FB, Instagram, LinkedIn, GMB).

---

*   **[DEV : 10/03/2026] [PROD : 25/03/2026] ai_studio > Création du Hub & centralisation de la documentation**
    *   *Fichiers modifiés :* `global/ai_studio/hub/`, `global/ai_studio/documentation/`, `ai_studio_documentation_view.php`
    *   *Description :* Interface centralisée de la connaissance stratégique (SOP, PRD, Ton, Roadmap).

*   **[DEV : 10/03/2026] [PROD : 12/03/2026] www > Mise à jour des pages de présentation générale**
    *   *Fichiers modifiés :* `web/fo/modules/communication/statique/fr/fo_statique_features_presentation_generale.php`, `fo_statique_seo.php`

---

### Février 2026

*   **[DEV : 15/02/2026] [PROD : 01/03/2026] www > Création des 5 pages "Cibles"**
    *   *Fichiers modifiés :*
        - `web/fo/modules/communication/statique/fr/fo_statique_cible_{bars,entreprises_evenementiel,etablissements_saisonniers,particuliers,reseaux_franchises}.php`

---

## 🧩 Divers

### Brique 1 — Stockage leads ✅ COMPLÈTE

| Composant | Fichier | État |
|---|---|---|
| Schema SQL | `automatisations/leads_acquisition/scrapping_google_maps/` (table SQL dans V1) | ✅ |
| Table leads | `ai_studio_tenant_leads_acquisition` (117 champs) | ✅ |
| Table logs emails | `ai_studio_tenant_leads_acquisition_emails_transactionnels_logs` | ✅ |
| Hub CRUD UI | `global/ai_studio/hub/modules/leads/index.php` | ✅ |
| Webhook ingestion n8n → BDD | `global/ai_studio/automatisations/leads_acquisition/ai_studio_leads_acquisition_webhook.php` | ✅ |
| Hub formulaire scraping | `global/ai_studio/hub/modules/leads/scraping.php` | ✅ Créé 29/04 |

### Brique 2 — Envoi emails P0 ✅ COMPLÈTE

| Composant | Fichier | État |
|---|---|---|
| Templates P0 J0 / J+7 / J+14 | `global/ai_studio/automatisations/crm/emails_transactional/ai_studio_emails_transactional_templates.php` | ✅ |
| Personnalisation 3 niveaux | `global/ai_studio/automatisations/crm/emails_transactional/ai_studio_emails_transactional_functions.php` | ✅ |
| CRON quotidien | `global/ai_studio/automatisations/crm/emails_transactional/ai_studio_emails_transactional_cron_routine.php` | ✅ |
| Exclusion leads déjà en cycle P0 | idem CRON — `AND id NOT IN (SELECT ... LIKE 'P0%J0')` | ✅ Ajouté 29/04 |
| UPDATE status='contacted' après J+14 | idem CRON | ✅ Ajouté 29/04 |
| Webhook Hub → n8n → Brevo | `global/ai_studio/automatisations/crm/emails_transactional/ai_studio_emails_transactional_webhook.php` | ✅ |

### Brique 3 — Tracking Brevo ✅ COMPLÈTE

| Composant | Fichier | État |
|---|---|---|
| Récepteur webhook Brevo | `global/ai_studio/automatisations/crm/emails_transactional/ai_studio_emails_transactional_brevo_webhook.php` | ✅ |
| Mise à jour `opened_at` / `clicked_at` / `bounced_at` | idem | ✅ |
| Affichage diodes J0/J+7/J+14 dans Hub | `global/ai_studio/hub/modules/leads/index.php` | ✅ |
| Tags Brevo `lead_{ID}` dans le payload webhook | `global/ai_studio/automatisations/crm/emails_transactional/ai_studio_emails_transactional_webhook.php` | ✅ Ajouté 04/05 |
| Paramètre `tags` dans le node n8n "Brevo HTTP API" | `global/ai_studio/automatisations/crm/emails_transactional/ai_studio_emails_transactional_workflow_n8n.json` | ✅ Codé 04/05 + ré-import n8n |
| Dashboard métriques (taux ouv., clics, rebonds) | — | ❌ Futur |
| Test webhook manuel depuis Hub | — | ❌ Futur |

### Brique 4 — Scraping leads ✅ COMPLÈTE (côté code)

| Composant | Fichier | État |
|---|---|---|
| Formulaire Hub de lancement | `global/ai_studio/hub/modules/leads/scraping.php` | ✅ Créé 29/04 |
| Constantes URLs n8n | `global/ai_studio/hub/core/config.local_DEV.php` + `config.local_PROD.php` | ✅ Ajouté 29/04 |
| Fallbacks config.php | `global/ai_studio/hub/core/config.php` | ✅ Ajouté 29/04 |
| Correction COALESCE date_envoi_J0 | `global/ai_studio/automatisations/leads_acquisition/ai_studio_leads_acquisition_webhook.php` | ✅ Corrigé 29/04 |
| Workflow n8n Google Maps | `global/ai_studio/automatisations/leads_acquisition/scrapping_google_maps/ai_studio_scrapping_google_maps_workflow_n8n.json` | ✅ Créé 29/04 |
| Workflow n8n Open Data Gouv | — | ❌ Futur (Phase 2) |

**Étapes manuelles restantes côté n8n :**
1. Importer le JSON dans n8n → copier l'URL webhook → renseigner `N8N_WEBHOOK_LEADS_GOOGLE_MAPS` dans `config.local.php`
2. Rebinder la credential Apify dans le nœud "Merci Google Maps (Apify)"
3. Remplacer `VOTRE_DOMAINE` dans le nœud "Envoyer vers Hub" par l'URL réelle

### Architecture A-Z — Rappel schéma

```
[Hub scraping.php]
       │ POST (secteur, lieu, max_leads, campaign_code, date_envoi_j0)
       ▼
[n8n Webhook Trigger] → Réponse immédiate au Hub
       │
       ▼
[Apify Google Maps Scraper]
       │ Résultats bruts (title, website, phone, address, score, reviews, rank)
       ▼
[Filtrage Persona] — Exclut : réseaux, PMU/tabac, catégorie hors cible, score < 3.5
       ▼
[Un ptit site ?] — Filtre : website non vide
       ▼
[Doublette ?] — Déduplique par website
       ▼
[Silence ca tourne !] — Traitement par batch
       ▼
[Mauvais site ?] — Filtre 48 domaines blacklistés (réseaux sociaux, livraison, etc.)
       ▼
[Analyse de la vitrine] — HTTP GET website + Pause 1s
       ▼
[Extraction des Emails] — Regex + anti-obfuscation + filtres génériques
       ▼
[Score du Lead] — 0-100 : note (35) + avis (30) + rang (20) + email (15)
       ▼
[A un email ?] — Filtre : garder uniquement les leads avec email
       ▼
[Préparer Payload] — Formatte le JSON + injecte campaign_code + date_envoi_j0
       ▼
[HTTP POST → ai_studio_leads_acquisition_webhook.php]
       │ Upsert BDD (INSERT ON DUPLICATE KEY UPDATE)
       ▼
[hub/modules/leads/index.php] — Leads visibles dans Hub
       │
       ▼
[CRON quotidien] — Sélectionne leads status='active' + date_envoi_J0=TODAY
       │         — Exclut leads déjà en cycle P0 (logs) + déjà dans clients_contacts
       ▼
[Brevo] — Envoi J0 / J+7 / J+14 via n8n
       │
       ▼
[Brevo webhook] — Tracking opens/clicks/bounces → BDD
       │
       ▼
[Hub leads/index.php] — Diodes J0/J+7/J+14 par lead
```

**Stratégie de prospection (référence) :** → Voir `automatisations/leads_acquisition/SCRAPING_DOCUMENTATION.md`

### Planning Campagne Rentrée "Coup d'Envoi" (Q3 2026)
| Phase | Thématique & Impact | Date |
| :--- | :--- | :--- |
| [2026-09/01-teasing] | **Article blog + post GMB — sans offre** ✅ Publié 18-19/08 | 18 Août |
| [2026-09/02-lancement] | **Lancement offre 49€/69,90€ — tous segments** | 1er Septembre |
| [2026-09/03-preuve-sociale] | **Championnat/fidélisation + rappel offre — email dédié P0** | 10 Septembre |
| [2026-09/04-urgence] | **Relance J-5 (INS/CSO) puis dernier jour (tous segments)** | 17 et 22 Septembre |

### Planning Newsletters Q2 2026 (référence, rythme ~3 semaines)
| Campagne | Date d'envoi |
| :--- | :--- |
| [2026-06-09--anniversaire-juin] | 11 Juin |
| [2026-05-19--nos-bars-imagination] | 26 Mai |
| [2026-04-22--espace-joueur-stats] | 22 Avril |
| [2026-04-14--pilotage-automatique] | 14 Avril |
| [2026-03-17--bibliotheque-themes] | 17 Mars |

---
*Dernière mise à jour : 28/08/2026*
