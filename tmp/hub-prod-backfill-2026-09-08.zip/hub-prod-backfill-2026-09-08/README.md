# Backfill Hub PROD — pack de revue du 08/09/2026

**BACKFILL SQL READY FOR REVIEW — aucun SQL exécuté, aucune autorisation PROD.**

Cohorte figée : **59 Hubs, 70 memberships**, sessions officielles datées du **08/09/2026 ou après** dans le snapshot validé. Le cutoff ne devient pas automatiquement la date d'exécution. Les 57 soirées regroupent 66 sessions ; les événements601/618 regroupent quatre sessions. Dix-neuf comptes clients. Les quatre sessions de la veille, les historiques, anomalies et démos sont exclus ; aucune suppression ni modification legacy.

## Fichiers à examiner

| Fichier | Usage futur |
| --- | --- |
| [ATTRIBUTS.md](ATTRIBUTS.md) | Les 34 colonnes Hub, provenance, défauts et risques ; contexte des deux événements |
| [20-hub-backfill-precheck.sql](20-hub-backfill-precheck.sql) | Conformité du schéma, cohorte exacte, manifeste et empreintes PRE |
| [21-hub-backfill.sql](21-hub-backfill.sql) | Deux INSERT métier seulement, sous transaction et assertions |
| [22-hub-backfill-postcheck.sql](22-hub-backfill-postcheck.sql) | Correspondance exhaustive, attributs, empreintes et IDs réellement créés |
| [23-hub-backfill-rollback.sql](23-hub-backfill-rollback.sql) | Suppression du seul lot, avant tout usage et sous conditions strictes |
| [manifest.csv](manifest.csv), [cohort.json](cohort.json) | 70 IDs et 59 regroupements explicites ; photographie source |
| [compare-snapshots.py](compare-snapshots.py) | Comparaison locale des exports d'empreintes PRE/POST |
| [VERIFICATION.md](VERIFICATION.md) | Vérification statique et limites ; aucune qualification SQL par exécution |

`build-pack.py` produit les quatre SQL depuis la cohorte, le contrat de schéma et les tokens fixes. Ne pas modifier manuellement les VALUES, le cutoff ou les signatures pour contourner un échec. Les seuls paramètres opérateur modifiables sont décrits ci-dessous. Les fichiers SQL et `hub-tokens.private.json` contiennent les futurs tokens Hub : pack local, exclu du versionnement par son `.gitignore`. Conserver l'ensemble du dossier pour le rollback ; ne pas régénérer les tokens après écriture.

## Décisions retenues

Le regroupement est celui du snapshot B01/R01, jamais une nouvelle inférence à partir de l'offre ou du profil actuel du client. PRE recompte toutes les officielles du cutoff, exige exactement les 70 IDs et compare les 30 champs disponibles dans R01, dont date/client/opération/configuration/produit/lot_ids/publication. Un ajout, retrait, remplacement d'ID ou changement de ces champs impose un nouveau snapshot et une nouvelle validation. Les autres colonnes legacy, notamment les tokens, sont capturées intégralement dans le PRE actualisé puis comparées à l'écriture et au POST.

**Un Hub ne porte pas le caractère privé.** Selon la précision utilisateur, le compte client détermine la publication sur les pages publiques hors lien. `flag_active=1` rend la racine utilisable, `hub_status=''` reste neutre ; aucune conversion de `flag_evenement_prive` ou `online` vers un statut Hub. Les comptes et événements sont conservés et empreintés toutes colonnes. Aucune ligne de `games_hubs_publication` n'est créée. L'accès par lien est distinct de la présence dans les pages publiques. Ce pack ne modifie ni ne certifie le code de publication déployé.

Les lots restent exclusivement dans leurs données legacy : aucune ligne `games_hubs_prizes`, `prizes_initialized_at=NULL`. Les divergences connues (940/08-09, 1958/24-09, 1959/25-09) sont conservées. Aucun choix première/dernière session et aucun bootstrap. Le lecteur applicatif pourra projeter les lots legacy selon sa logique existante ; le SQL ne matérialise aucune sélection.

L'état des sessions sera lu par le code après migration. Il ne sert pas ici à classifier ou exclure des sessions : aucun état runtime artificiel n'est inscrit dans les Hubs. Les lectures runtime du pack servent uniquement à constater l'absence de changement PRE/POST. Elles utilisent des listes fixes et des SELECT sur une seule table, sans la jointure historique BNL de R02.

## Préservation et portée des preuves

Chaque capture utilise **toutes les colonnes présentes**, empreinte le schéma de la table (colonnes/index/engine/collation), les lignes avec SHA-256, leur multiplicité et un pli ordonné de leurs empreintes. NULL et chaîne vide sont distincts ; les doublons ne s'annulent pas. Les 21 objets capturés couvrent :

- les 70 sessions, leurs comptes et le réseau concerné, les deux événements ;
- lots normalisés et attributions, participations probables ;
- branding session/événement/réseau/client, branding Hub existant (type5), ancien branding client ;
- résultats, équipes liées, réponses, participations Games connectées ;
- playlists Bingo concernées et composition ;
- runtimes Blind Test/Quiz par tokens legacy, leurs joueurs par IDs runtime, joueurs et vainqueurs Bingo par tokens ;
- `game_events` par tokens legacy et futurs tokens Hub.

Les cinq tables joueurs/Bingo/events non confirmées dans les métadonnées reçues sont optionnelles : leur absence est enregistrée comme **ABSENT_TABLE**, différente d'une table vide. Si elles existent, leur colonne de filtrage doit être présente ; une vue à leur place est refusée. Une erreur de lecture, colonne requise absente ou avertissement SQL annule la validation. L'opérateur doit avoir la visibilité et le droit SELECT sur les sources ; une table cachée par les permissions ne peut pas être certifiée absente.

La comparaison porte sur ces périmètres, pas sur chaque ligne de toute la base ni sur les fichiers externes. La preuve complémentaire est la liste fermée des écritures persistantes : deux INSERT dans21, deux DELETE dans23, aucune écriture legacy ni appel PHP ni trigger autorisé par le contrôle de schéma. Les colonnes hors R01 sont protégées à partir du PRE actualisé, pas prétendument comparées à un export antérieur qui ne les contenait pas.

## Procédure future — à suivre après autorisation distincte

1. **Préparer la fenêtre opérateur et le client SQL.** Faire confirmer le schéma initial : les treize tables attendues conformes et vides. Le pack refuse toute table Hub/Quick déjà remplie. Utiliser une connexion dédiée neuve pour chaque fichier entier, avec un client reconnaissant `DELIMITER` et les blocs anonymes MariaDB `BEGIN NOT ATOMIC`. Les requêtes visent explicitement `prod_cotton_global_0`. Ne pas importer les quatre fichiers ensemble. Valider séparément le fonctionnement de l'importeur lors de la qualification autorisée ; aucune qualification par exécution n'a été faite ici.
2. **Suspendre les écritures applicatives et CRON**, y compris anciens parcours et organisateurs, avant PRE et jusqu'au POST et à la décision de rollback. Pas de déploiement ni usage Hub dans cette fenêtre. Les sources MyISAM ne sont pas figées par la transaction InnoDB. Le verrou nommé ne bloque que les autres exécutions de ce pack. Si la pause globale n'est pas possible, STOP : ce protocole ne fournit pas une photographie atomique des sources actives.
3. **PRECHECK : importer20 seul.** Toute erreur ou absence du verdict final est un STOP. Exiger `PRECHECK_OK_REQUIRES_HUMAN_VALIDATION_AND_QUIESCENCE`, 59/70, puis conserver tous les résultats : manifeste70 lignes et attributs, tableau21 lignes `object_key,row_count,schema_hash,data_hash`, digest `legacy_pre_post_digest`, batch et heure UTC. Exporter séparément le tableau21 lignes en CSV avec en-têtes sous `PRE.csv` dans ce dossier. Un message générique phpMyAdmin « exécutée avec succès » ne remplace pas le verdict.
4. **Validation humaine explicite.** Examiner le manifeste, les deux événements, les attributs, les empreintes et la pause d'écriture. Toute dérive impose une nouvelle génération/validation ; ne pas remplacer une signature attendue pour passer. Conserver le digest PRE validé hors de la connexion. Une validation de préparation du pack ne vaut pas autorisation d'import.
5. **BACKFILL : préparer une copie de21**, y mettre le digest64 caractères dans `@hb_approved_pre_digest`, mettre `@hb_operator_writes_paused=1` après pause effective et `@hb_explicit_approval='prod_hb_20260908_v1'` après autorisation. Conserver l'original et la copie. Importer cette copie seule dans une connexion neuve. Par défaut les paramètres empêchent toute écriture.21 refait les contrôles et la capture, compare au PRE approuvé, insère59 racines puis70 memberships, contrôle tout et recapture avant COMMIT. Exiger `BACKFILL_COMMITTED_REQUIRES_POSTCHECK` ; conserver impérativement `created_at_utc`, reçu de provenance pour rollback.
6. **POSTCHECK immédiat : préparer une copie de22** avec le même digest PRE, importer seule et conserver tous les résultats. Exiger `POSTCHECK_OK_59_70_LEGACY_UNCHANGED`, le mapping70 lignes avec IDs Hub/membership et date de création. Exporter le tableau21 empreintes en `POST.csv`. Vérification locale supplémentaire : `python3 compare-snapshots.py PRE.csv POST.csv` doit afficher `UNCHANGED`. Une différence ou une erreur est un STOP, jamais une validation partielle.
7. **Décider avant reprise.** Si POST est conforme et accepté, archiver PRE/POST/reçu/pack et terminer la fenêtre selon la décision opérateur. Le déploiement et la recette du code restent des étapes distinctes. Si POST échoue, conserver la pause et diagnostiquer ; ne pas supprimer ni restaurer les données legacy pour rendre les empreintes égales.
8. **Rollback éventuel avant usage seulement.** Dans une copie de23, renseigner le même digest PRE, l'approbation et la pause, plus `@hb_expected_created_at='YYYY-MM-DD HH:MM:SS'` copié exactement du reçu21 UTC. Autorisation de rollback distincte.23 exige les59/70 exacts, tokens/contexte/attributs neutres/source du lot/date d'origine, tables auxiliaires vides et toutes les empreintes égales au PRE ; il refuse après activité observable ou changement source. Il supprime d'abord les70 memberships puis les59 racines, recapture et vérifie avant COMMIT. Exiger `ROLLBACK_OK_ONLY_59_HUBS_70_MEMBERSHIPS_REMOVED`. Aucun reset des AUTO_INCREMENT, aucune restauration legacy. Après usage, timestamp inconnu, données divergentes ou refus : pas de rollback automatique, audit dédié.

Après une erreur, fermer la connexion : des tables temporaires/préparations peuvent y subsister. Les handlers exécutent ROLLBACK et relâchent le verrou avant de remonter l'erreur ; ne jamais poursuivre manuellement au milieu du fichier. Si la connexion est perdue autour de COMMIT et que son résultat est inconnu, ne pas relancer21 : examiner la cible avec22 et récupérer la preuve d'engagement avant toute décision destructive. Les auto-increments peuvent avoir des trous après un échec ; aucun calcul d'ID ne repose sur leur continuité.

## Réexécution et limites restantes

Une seconde exécution de21 **échoue avant INSERT** si les Hubs/memberships existent ; elle ne devient pas NOOP et ne répare rien. Les uniques token et clé logique protègent les racines ; l'unique `(id_hub,id_session)` protège la paire. Le schéma n'a pas d'unique global `id_session` : le manifeste PK, la vacuité initiale, les vérifications exhaustives et l'arrêt des écritures concurrentes assurent ici le rattachement unique, sans ajouter de contrainte à la base.

Pas de décision d'attribut Hub restante après la clarification sur la publication. Restent à obtenir **avant exécution** : conformité réelle du schéma PROD, PRE frais strictement conforme, pause effective, qualification de l'importeur/bloc MariaDB, validation humaine et autorisation explicite. Les résultats runtime détaillés R13 ne bloquent plus la préparation structurelle. Aucun appel au bootstrap applicatif n'est requis.

Références SQL : MariaDB documente les [blocs composés hors routine](https://mariadb.com/kb/en/using-compound-statements-outside-of-stored-programs/) et les [transactions](https://mariadb.com/docs/server/reference/sql-statements/transactions/start-transaction). Compatibilité visée10.3 ; revue statique, aucun test SQL serveur dans cette passe.
